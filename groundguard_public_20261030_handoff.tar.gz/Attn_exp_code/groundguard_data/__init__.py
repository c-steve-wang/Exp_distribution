"""Unified, image-coordinate data access for GroundGuard experiments."""
from .dataset import Dataset, decode_rle

__all__ = ["Dataset", "decode_rle"]
