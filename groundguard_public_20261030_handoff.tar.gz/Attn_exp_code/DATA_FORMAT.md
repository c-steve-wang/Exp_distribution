# 统一数据接口

本运行目录直接使用 Hugging Face 上已整理的 `SteveWCG/Attn_exp_data`：先执行 `python -m experiments fetch-data`，随后 `prepare` 只建立公开数据动作审计。下文原始预处理脚本描述保留为数据来源说明；对应构建脚本位于上层数据准备项目。

四个公开数据集共用 `groundguard_data.Dataset`。图片、问题、参考区域和配对关系已经转换成同一套字段；后续 attention、定位、问答及反事实实验直接读取冻结的清单。

## 目录与使用范围

```text
raw_data/                    官方完整快照
prepared_data/
  images/<dataset>/          独立复制／解包的原始图片，不改变分辨率
  masks/<dataset>/           PNG mask；RLE mask 内嵌在索引中
  manifests/<dataset>.jsonl  统一格式的样本索引
  selections/<dataset>.json 入选与测试 ID（二者一致）；seed=42
  build_report.json          实际数量、上游版本、校验和及格式检查
groundguard_data/            所有实验共用的 Python 读取接口
data_config.json             当前抽样配额与规则
scripts/prepare_data.py      可重复执行的预处理脚本
```

`manifests/` 保存可供筛选的完整索引，包含未入选记录；HalluSegBench 只整理 test.zip 中的 referring、reasoning test 和 reasoning val。**实验按 `selections/` 读取，不按图片目录中的文件数决定样本量。** GroundingME 的 Small 仍在完整索引内，但不在实验清单内。

`subset="selected"` 与 `test` 返回相同的全部入选样本。没有独立开发集；为兼容读取接口，`development_unit_ids` 保留为空列表。`all` 仅用于检查完整候选索引。小规模试跑通过运行时数量限制完成，试跑样本仍属于全量测试。

## 直接调用

在项目根目录安装依赖并生成数据：

```bash
python -m pip install -r requirements-data.txt
python scripts/prepare_data.py
python -m unittest discover -s tests -v
```

四套数据使用相同调用方式：

```python
from groundguard_data import Dataset
from experiments.data_source import resolve_data_root

data = Dataset(resolve_data_root())
for sample in data.iter_samples("vistaqa", subset="test"):
    inputs = data.model_input(sample)  # {image: PIL RGB, question: str}
    target = data.region_mask(sample)  # 原图尺寸的 bool mask；bbox 会栅格化
    reference = data.reference(sample)
    # inputs 交给模型；target / reference 只供测量与评分。
```

HalluSegBench 默认每对返回 `factual_original` 一条主记录；展开四格：

```python
for sample in data.iter_samples("hallusegbench", subset="test"):
    pair = data.get_pair(sample)
    for condition, view in pair.items():
        inputs = data.model_input(view)
        target_mask = data.mask(view)
        # 用 view["sample_id"] 保存当前条件的 attention 和预测。

# 或一次迭代全部 2,600 个图像—查询条件：
views = data.iter_samples("hallusegbench", subset="test", condition="all")
```

四种条件为 `factual_original`、`factual_replacement`、`counterfactual_original`、`counterfactual_replacement`。两张图分别与两个原始查询组合；referring 保留完整表达，reasoning 保留 question / counterfactual_question。

## 字段约定

| 字段 | 含义 |
|---|---|
| `sample_id` | 一张图与一个查询条件的唯一 ID；实验结果按它关联 |
| `unit_id` | 原始问答／表达 ID；HalluSegBench 为配对 ID |
| `source_group_id` | 基础原图的解码 RGB 哈希；同源问题、配对及后续分辨率变体共用分组 |
| `pair_id`, `condition` | 配对及四格条件；普通样本 pair_id 为 null |
| `official_split`, `task_type`, `domain` | 作者原始分区与类别；不改变全部入选样本用于测试的规则 |
| `question`, `image` | 原始文本、图片相对路径、实际宽高及文件／像素哈希 |
| `reference` | 参考答案、目标状态、标注类型、区域列表 |
| `intervention_regions` | HalluSegBench 当前图上被替换对象的区域；缺席查询时也保留，不能当成该查询的正目标 |
| `provenance` | 上游版本、原始文件／行号、原始标注、必要的坐标变换 |

图片和标注都以**当前这张原图的像素坐标**为准。bbox 统一为 `[x1,y1,x2,y2]`，右／下边界不包含在框内；mask 为 `[height,width]`。不把原图的 mask 直接套到编辑图上。实际模型输入的 resize、padding、裁剪、动态切块及 token 映射由模型适配器另存，并据此将 attention 回投到此坐标系。

`reference.region_kind` 区分 `mask`、`bbox`、`none`、`unavailable`。`data.mask()` 只返回真实分割标注，bbox 样本返回 None；`data.region_mask()` 可以把已有 bbox 栅格化，但统计时仍按 bbox 标注报告。空区域返回全零数组；必须结合 `target_status` 区分 absent、no_match 与 no_annotated_target。标注缺失返回 None，不按无目标评分。

参考区域始终解释为作者标注的目标／目标集合。关系题和 reasoning 的目标 mask 不扩充成“全部推理证据”。VistaQA 保留原始答案；GroundingME 的 NO_MATCH 表示完整描述没有匹配目标。

## 抽样与复现

- 全部随机步骤固定 **seed=42**，先对候选 ID 排序，再按数据集独立初始化 Python `random.Random`。
- VistaQA：全部 1,157 条与原文件名保留；相同图片只共用来源分组，不合并记录。
- GSEval：四类各 250 张不同源图，共 1,000 张。随机顺序匹配满足类别配额，避免一张图占两个类别名额；再随机选对应表达。
- GroundingME：保留全部 855 条非 Small 描述，对应 820 张源图。
- HalluSegBench：reasoning test 全部 325 对；referring 先随机抽 325 张基础图，再随机选每图一对。两类合计 650 对、1,300 个两端图片输入、2,600 个四格条件。无效正目标 mask 的配对在抽样前排除并记录原因。
- 全部入选样本用于测试；同源问题、配对与变体按基础图归组统计。HalluSegBench 不再额外选取 reasoning val 与 referring 配对作为开发数据。

确切样本数量、不同图片数、各类数量及清单 SHA-256 见 `prepared_data/build_report.json`。精确像素归组不能识别所有经过裁剪或重编码的近重复图片；后续已知来源关系应继续沿用同一 source_group_id。

| 数据集 | 全部正式测试 |
|---|---|
| VistaQA | 1,157 条，1,152 张不同图片 |
| GSEval | 1,000 条／不同图片 |
| GroundingME | 855 条，820 张不同图片 |
| HalluSegBench | 650 对，1,279 张不同图片，2,600 个四格条件 |

上传版由 `scripts/export_experiment_data.py` 从当前清单导出，只保留上述入选记录及其图片、mask；上传版的 `all` 只包含这些记录。原始候选索引用于复查抽样，不属于实际实验输入。

## 已处理的原始格式差异

- VistaQA `1079.png` 的标注文件名实际对应 `1079.jpg`，按 image_id 读取。
- VistaQA 138、496 的标注画布大于已发布图片：按两个方向的实际比例缩放框，mask 用最近邻缩放；记录原始与目标尺寸，不改变图片。
- VistaQA 有 10 个区域的 area 字段与已发布 mask 不一致：统一 area 从 mask 重新计算；原始值仍保留。这不改写 mask 或人工修订目标标签。
- HalluSegBench 统一两种 counterfactual mask 路径字段；referring 的 1,340 张编辑图 mask 按各自图片尺寸最近邻缩放，记录变换。
- HalluSegBench referring 的 `ann_id=298954` 发布了空的正目标编辑 mask：完整索引保留并标记 unavailable，该配对不进入抽样候选；不影响 reasoning 全量 325 对。

这一步完成公共数据的整理、抽样和读取。模型 attention 导出、分辨率变体与 500 场景动作审计子集在相应实验步骤生成，沿用这里冻结的来源分组与样本 ID。
