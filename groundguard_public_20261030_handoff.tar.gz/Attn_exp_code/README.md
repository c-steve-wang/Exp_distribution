# GroundGuard 公共实验交付版

2026-10-30 公共 E1–E4 程序，默认生成上限 1024，使用按任务定义的框数约束。支持 VistaQA、GSEval、GroundingME、HalluSegBench。

分发包仅含程序、配置、依赖清单、测试和使用说明。运行结果、验证报告、日志、数据、模型权重、虚拟环境和缓存单独保存在运行服务器。新环境按下文重新执行 `prepare` 和 `gpu-preflight`，不沿用旧机器的 manifest 或 GPU gate。

## 交接必读：完整结果需要 OpenRouter 评分

**合作者需要自行提供可用的 OpenRouter API key，通过环境变量 `OPENROUTER_API_KEY` 配置，并完成 LLM-as-judge 评分，才能得到包含 VistaQA 答案正确率与联合指标的完整公共实验结果。仅完成模型推理或生成汇总文件，不代表完整结果已经产出。** 执行评分的计算节点需要能够访问 OpenRouter，API 账户需有可用额度。

本轮 LLM-as-judge 固定选择 **DeepSeek V4.1 Flash（1017 版本）**，OpenRouter 请求 model ID 为 **`deepseek/deepseek-v4.1-flash-1017`**，canonical slug 为 `deepseek/deepseek-v4.1-flash-20261017`，以 `configs/semantic_judge.lock.json` 为准。交接运行时沿用该版本，避免不同 run 混用 judge。

OpenRouter 用于 **VistaQA 自由文本答案的语义评分**；GSEval、GroundingME、HalluSegBench 使用已有标注和原生 status/定位评分。API key 不随包分发，不填写到配置文件或代码中。具体操作见下文“评分、汇总、导出”。

所有计算通过 Slurm 在计算节点执行；登录节点仅用于文件编辑、提交作业和查看状态。新模型或新环境先取每个数据集 **5–10 个源样本**做 smoke；Hallu 在 E3/E4 自动展开四格。smoke 用于检查程序和模型接口，10% pilot 与全量实验使用独立的 manifest 和输出目录。

## 环境和资源准备

建议 Python 3.11。完整固定依赖版本见 `requirements-lock.txt`，Transformers 固定到 `b7e80d25c8a758224980b2f6d0b993850ef7b595`，xgrammar 固定到 0.2.8。GPU 驱动需支持所安装的 PyTorch CUDA wheel；在目标环境执行 GPU preflight 核对兼容性。

以下安装、Python、测试、数据处理、分析和打包命令均须在分配到的计算节点执行。CPU 工作也需要 CPU 作业，不能直接在登录节点运行；数据和模型传输按所在集群的数据传输规范执行。代理控制端宜运行在个人电脑，不在登录节点展开多个代理工作流。

```bash
python3.11 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements-lock.txt
export HF_HOME="$PWD/.cache/huggingface"
export MPLCONFIGDIR="$PWD/.cache/matplotlib"
export OMP_NUM_THREADS=4
mkdir -p logs work outputs "$MPLCONFIGDIR"
python -m unittest discover -s tests -v
python -m experiments fetch-data
python -m experiments --config configs/public_e1.json --lock configs/models.public.lock.json download-models --models qwen35_9b gemma4_e4b internvl35_8b
```

数据集链接：**[SteveWCG/Attn_exp_data（Hugging Face）](https://huggingface.co/datasets/SteveWCG/Attn_exp_data)**。代码包不包含数据；上面的 `python -m experiments fetch-data` 会下载项目固定版本的数据并校验，合作者可通过该链接查看数据集说明。

数据固定为 `SteveWCG/Attn_exp_data@758421f5614e91ac06da9fce11c4c89deac59eec`，可设置 `GG_DATA_ROOT=/absolute/path/prepared_data` 或向 `prepare` 传入 `--data-root`。模型 checkpoint lock 已包含三个实际使用的小型号。使用本地模型时在准备命令中传入 `--model-path /absolute/checkpoint`，该目录必须对应 lock 中的 revision；路径、processor 输出和环境版本均记入 manifest。

## CPU 准备、GPU 检查和运行

唯一推荐入口是 `scripts/project.py`。以下以 E1/Qwen 为例；其他实验替换实验号及 `configs/public_eN.json`，其他模型替换 model key 和 manifest 文件名。

旧的 `python -m experiments run/propose/smoke/judge` 已关闭并提示使用统一入口；该模块的模型下载、数据准备和历史结果可视化工具仍可使用。

```bash
python scripts/project.py prepare --experiment 1 --config configs/public_e1.json \
  --model qwen35_9b --lock configs/models.public.lock.json \
  --samples-per-dataset 5 --work-root work/shared \
  --output-root outputs/smoke/e1 --manifest work/smoke/qwen35_9b_e1.json

# 在已分配 GPU 的终端执行：
python scripts/project.py gpu-preflight --manifest work/smoke/qwen35_9b_e1.json
python scripts/project.py run --manifest work/smoke/qwen35_9b_e1.json
```

`prepare` 检查固定数据、实际 native processor、问题 token、每个 view 的视觉 token 顺序和空间映射，输出 `.processor.json`、`.expected.json` 和主 manifest。GPU preflight 检查采集开关前后的输出 token、logits、显存和耗时，输出 `.gpu.json`。没有匹配的成功 GPU gate，不能运行推理。输出格式失败作为模型失败保留；技术错误必须修复或重试。

公共 E1–E4 现统一使用生成时 JSON 约束并允许正常空白，字段、任务 status、归一化坐标和至多三条 facts 由公共 schema 定义。E1 的原图、无图、错图控制也使用相同入口；无图输出只能给空 boxes。各实验既有的定位视图保留。严格坐标顺序及截断检查仍在生成后执行，不裁剪或自动缩放非法框。字符串不加 `maxLength`，因为固定 xgrammar 0.2.8 的该约束会拒绝合法转义字符。

2026-10-30 起，新任务默认 `max_new_tokens=1024`。E1/E2 的任务输出新增与 E3/E4 相同的按任务框数量预算：GSEval、GroundingME、HalluSegBench 最多一个包含请求目标或目标集合的框；VistaQA 最多 64 个实例框。预算同时写入提示词和生成 schema，对基线、crop、各策略及控制条件一致，按数据集任务定义决定，不读取参考答案或标注框数。E2 仍允许在任一合法输入视图定位；独立的 8 区域 proposal 和 32 候选池保持原协议。多实例任务的“不重复”仍为提示词要求，固定 xgrammar 0.2.8 实测不执行 `uniqueItems`，不宣称硬性去重、不对模型输出事后删框。这是新的生成协议，须新建 manifest、GPU gate 和输出目录；不得混用此前无框数上限/4096-token pilot 的结果。

10% pilot 使用 `prepare --pilot-fraction 0.1`，与 `--samples-per-dataset` 互斥。沿用按数据集、任务/status 分层的源组抽样，每个数据集取 `ceil(0.1 * 源组总数)` 并保留选中源组的全部主记录；E2 从固定 audit 池抽取，E1/E3/E4 从公共测试池抽取。manifest 保存总体与选中源组数；pilot 控制样本也只从选中组中取。四个实验需分别生成新 manifest 和 GPU gate，不沿用旧协议的 gate 或缓存身份。

逐头注意力缓存可能明显大于普通生成结果，需按 smoke 的实际磁盘占用规划全量运行。NPZ 使用低级别无损压缩，所有数组值和 dtype 保留；既有缓存不重写，不通过减少测量层或降低精度来节省空间。

E2 保持 **32 个固定候选、K=8/16/32、B=1/2/4**。先使用 `qwen35_9b` 的 E2 manifest 执行 `gpu-preflight` 和 `propose`，随后所有被测模型共享同一个 `--work-root` 下的候选池：

确定性生成时，每个 E2 源样本展开 79 个条件（2 个基线/参考条件、32 个候选、45 个策略组合），相同请求可复用缓存。10 个源样本不是 10 次推理；完整配置的小样本也可能超过 30 分钟。按实际缓存调用耗时申请资源或按源组分片，不为缩短预检而改动正式候选池和策略定义。

```bash
python scripts/project.py prepare --experiment 2 --config configs/public_e2.json \
  --model qwen35_9b --samples-per-dataset 5 --work-root work/shared \
  --output-root outputs/smoke/e2 --manifest work/smoke/qwen35_9b_e2.json
python scripts/project.py gpu-preflight --manifest work/smoke/qwen35_9b_e2.json
python scripts/project.py propose --manifest work/smoke/qwen35_9b_e2.json
python scripts/project.py run --manifest work/smoke/qwen35_9b_e2.json
```

Gemma/InternVL 使用同一份 E2 配置、共享 work root 和相同候选池，不更换 proposer。InternVL 原生 12 tiles 的五图输入实际可达 17,276 tokens；交付配置显式将输入长度保护上限设为 24,576，未减少 tile、分辨率或输出上限。此配置需要单独检查显存，不能静默缩小输入。正式资源建议以 `.gpu.json` 和 `summary/inference_costs.csv` 为准；尚无实测的型号不能标为适配完成。

正式实验去掉 `--samples-per-dataset`，使用新 manifest 与正式 output root，重新执行对应 GPU preflight。数据保留原有 test 身份；历史样本不追认为独立开发集。条件 CPC 的 tau/head 选择若尚未有独立开发来源，报告明确标为探索性；不能据此声称已完成论文的确认性阈值冻结。

## Slurm 和恢复

先创建 `logs`，账户、分区、QoS、GPU、显存和时限由运行者传入。不要在 GPU 任务中下载数据或模型。

`run_public.slurm` 会检查 Slurm 作业身份及实际执行节点，并按申请的 CPU 数限制线程。CPU 的 `prepare`、`summarize`、`export` 也可以通过此入口提交到 CPU 分区：设置 `GG_STAGE`，在脚本名之后传入对应命令参数；无需申请 GPU。直接在已分配节点使用 Python 时也应先确认当前终端位于作业节点。

```bash
mkdir -p logs
export GG_PYTHON="$PWD/.venv/bin/python"
export GG_MANIFEST="$PWD/work/smoke/qwen35_9b_e1.json"
GG_STAGE=gpu-preflight sbatch --account=YOUR_ACCOUNT --partition=YOUR_GPU_PARTITION \
  --gres=gpu:1 --cpus-per-task=8 --mem=128G --time=01:00:00 scripts/run_public.slurm
# 上述 gate 完成后：
GG_STAGE=run sbatch --account=YOUR_ACCOUNT --partition=YOUR_GPU_PARTITION \
  --gres=gpu:1 --cpus-per-task=8 --mem=128G --time=04:00:00 scripts/run_public.slurm
# 全量分片：设置 GG_SHARDS=4，并传入 --array=0-3。
```

中断后重跑相同 `run` 命令，已完成的记录复用缓存；定向重试失败记录使用 `--retry-errors`。`--shards N --shard-index I` 按源组分片，不拆开反事实源组。模型、配置和代码身份决定各自输出目录，禁止混写。修改模型、分辨率、tile 或协议后必须准备新 manifest 和 GPU gate。

完整性汇总以 `delivery_manifest.json` 的完整样本清单为准；未启动的分片也计入漏跑。`summary/completeness.json` 分别报告全局 `inference_complete` 和 `shard_completion`，单个 `.run_shardN.json` 另有 `shard_inference_complete`。单个分片完成不代表全量完成，全部分片结束后再执行一次 `summarize` 获取最新全局状态。没有完整 manifest 的历史目录仅能报告已观察到的范围，不能据此认定全量完成。控制条件和缺失条件单独核对，导出时保留进度和源错误记录。

## 评分、汇总、导出

`manifest.run_shard0.json` 记录实际 `run_dir`。每个被测模型、每个实验的实际 run 目录都需要完成以下流程。**先完成全部分片，再执行 judge，随后重新 summarize，最后 export。** VistaQA 语义 judge 使用上文锁定的 DeepSeek V4.1 Flash；凭据只从 `OPENROUTER_API_KEY` 读取，不写包或日志。先查看计划，再执行：

```bash
RUN_DIR=/absolute/path/outputs/smoke/e1/runs/qwen35_9b/RUN_ID
python scripts/project.py judge --run-dir "$RUN_DIR"
# 在执行评分的计算节点/作业环境中安全设置 OPENROUTER_API_KEY 后执行：
# 注意：上面的命令只生成评分计划；下面的 --execute 才会实际执行评分。
python scripts/project.py judge --run-dir "$RUN_DIR" --execute
python scripts/project.py summarize --run-dir "$RUN_DIR"
python scripts/attention_detail.py --run-dir "$RUN_DIR"
python scripts/project.py export --run-dir "$RUN_DIR" --destination exports/qwen_e1
python scripts/package_experiments.py --output groundguard_public.tar.gz
```

judge 可以独立续跑，会复用已完成请求。未评分的答案为 null；不能用 exact match 冒充语义 judge。**API key 未配置或评分请求失败时，VistaQA 语义评分及相关联合指标尚未完成；修复后重新执行 judge，再 summarize。**

交付完整结果前检查重新生成的 `summary/completeness.json`：全局 `inference_complete` 必须为 `true`，`vistaqa_judgments_pending` 必须为 `0`，并确认 judge 命令成功结束。格式失败和不支持条件按既定协议保留并报告，不要求为了通过验收把模型失败样本删掉。每个 run 应一并保留 judge 身份、评分记录和完整性汇总。

旧结果可直接重新 summarize：已有注意力权重、token 坐标和固定数据时离线重算新基线，推理及原 judge 证据不重写。`attention_revision_audit` 记录旧新值。请保留原始 run 的 `cache/` 以便离线重算；默认导出是配置、明细、汇总和失败清单，完整研究归档另保留 cache。

整体及逐实例 top-area 覆盖率统一采用注意力截止值处的并列像素按比例计入。`all_instances_covered_at90` 由修正后的逐实例覆盖率计算；缺少实例或有效注意力时不伪造覆盖成功。旧缓存即使已使用面积修正 enrichment，也会检查实例覆盖规则并按需重算，无需再次运行模型。修正值写入汇总和重算审计，原始推理记录保持不变。

每个 run 中：

- `run.json` / `delivery_manifest.json`：实际模型、checkpoint、processor 配置、代码、数据、样本与源组身份。
- `adaptation_validation.json`：GPU、采集开关对照、输入 token、峰值显存、耗时和可测层。
- `records/` / `expected/` / `summary/completeness.json`：完成、格式失败、技术错误、未启动、跳过及待 judge 数量。
- `summary/paper_records.*`：逐条答案、严格定位、召回和联合效用，主表分母可重建。
- `summary/conditional_cpc_pairs.*` / `conditional_cpc.*`：固定原问题的事实 CPC、联合 pair 分数、条件分母、覆盖率及源组 bootstrap。
- `cache/*.npz`：layer 均值和紧凑 head/query→visual 子矩阵，decode 单独标为探索性。

`预检通过`、`推理完成`、`评分完成`、`报告写出`是不同状态。报告存在不表示前两阶段已完整。主表称 **attention × localization/detection × answer**；未独立标注事实识别，不把“框对答案错”归因为识别后的推理失败。定位使用已有框或 mask 提取框，attention 使用已有 mask，不增加分割输出任务。

E1 中固定公共子集包含原图、无图和错图控制。错图 donor ID/seed 已冻结且排除同源图，空间指标不适用；无图接口不支持则记 unsupported，不用黑图替代。`scripts/audit_public_pairs.py` 导出全部 Hallu 配对的原标签、问题一致性、描述重叠和人工复核空字段，绝不根据模型成败筛样本。
