"""One resumable judge entrypoint; model labels come from the actual manifest."""
from pathlib import Path
import argparse
import fcntl
import os
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from experiments.common import read_json,write_json,file_hash
from experiments.metrics import nonanswer_guard
from experiments.openrouter_judge import judge_identity,prepare_tasks,request_judgment,apply_result


def judge(root,execute=False):
    root=Path(root)
    manifest=read_json(root/'delivery_manifest.json') if (root/'delivery_manifest.json').exists() else {}
    records=list((root/'records').glob('*.json'))
    labels={read_json(p).get('model') for p in records} - {None}
    model=manifest.get('model') or (next(iter(labels)) if len(labels)==1 else None)
    if not model:raise ValueError('Cannot determine an unambiguous model from run records')
    identity,template=judge_identity()
    identity.update(evaluator_version='public_v3_nonanswer_guard',
        nonanswer_policy='Unicode alphanumeric content required for non-punctuation textual references; numeric zero and native status preserved')
    tasks,scope=prepare_tasks([(model,root)],identity,template)
    write_json(root/'semantic_judge_plan.json',dict(judge_id=identity,scope=scope,tasks=len(tasks)))
    if not execute:
        print(f'Judge plan prepared: {len(tasks)} unique requests; use --execute with OPENROUTER_API_KEY');return
    key=os.environ.get('OPENROUTER_API_KEY')
    if not key:raise ValueError('OPENROUTER_API_KEY must be set; never place it in config or logs')
    with (root/'semantic_judge.lock').open('w') as mutex:
        fcntl.flock(mutex,fcntl.LOCK_EX|fcntl.LOCK_NB)
        write_json(root/'judge.json',identity)
        errors=0
        for task in tasks:
            path=root/'semantic_judge_cache'/(task['key']+'.json')
            result=read_json(path) if path.exists() else {}
            if result.get('status')!='ok' or result.get('judge_id')!=identity:
                flags=[]
                for target in task['targets']:
                    record=read_json(root/'records'/target['record_file'])
                    flags.append(record['prediction']['status']!='UNKNOWN' and nonanswer_guard(
                        record['prediction'].get('answer',''),record['reference']['answer']))
                if flags and all(flags):
                    result=dict(status='ok',correct=False,reason='Empty or punctuation-only nonanswer',
                        judge_id=identity,prediction_text=task['prediction_text'],nonanswer_guard_applied=True)
                else:result=request_judgment(task,key,identity)
                write_json(path,result)
            for target in task['targets']:
                if file_hash(root/'records'/target['record_file'])!=target['record_sha256']:
                    raise ValueError('Record changed while judging')
            apply_result(task,result);errors+=result.get('status')!='ok'
            if result.get('fatal'):break
        print(f'Judge requests: {len(tasks)}; errors: {errors}')
        if errors:raise SystemExit(1)


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--run-dir',required=True);p.add_argument('--execute',action='store_true')
    args=p.parse_args();judge(args.run_dir,args.execute)
