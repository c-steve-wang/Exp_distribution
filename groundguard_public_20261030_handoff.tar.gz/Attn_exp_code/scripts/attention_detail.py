from pathlib import Path
import argparse,sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from experiments.attention_detail import summarize_attention_detail
from experiments.data import ExperimentData
from experiments.data_source import resolve_data_root
p=argparse.ArgumentParser();p.add_argument('--run-dir',required=True);p.add_argument('--data-root');args=p.parse_args()
print(summarize_attention_detail(args.run_dir,ExperimentData(resolve_data_root(args.data_root),'work/shared')))
