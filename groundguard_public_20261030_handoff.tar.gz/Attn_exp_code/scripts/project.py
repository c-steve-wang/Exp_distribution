#!/usr/bin/env python3
"""Public project: prepare → gpu-preflight → run → judge → summarize/export."""
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from experiments.delivery import main
if __name__=='__main__':main()
