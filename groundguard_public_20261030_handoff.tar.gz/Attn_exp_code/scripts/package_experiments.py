"""Create a portable code bundle; verification reports and run artifacts are excluded."""
from pathlib import Path
import argparse
import hashlib
import json
import tarfile
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from experiments.data_source import resolve_data_root


def main():
    cli = argparse.ArgumentParser()
    cli.add_argument('--output', default='groundguard_server.tar.gz')
    cli.add_argument('--include-prepared-data', action='store_true')
    cli.add_argument('--data-root', help='Optional existing dataset for an offline bundle')
    args = cli.parse_args()
    root = ROOT
    names = ['experiments', 'groundguard_data', 'configs', 'scripts', 'tests', 'third_party',
             'README.md', 'DATA_FORMAT.md', 'requirements-lock.txt',
             'requirements-experiments-cpu.txt', 'requirements-experiments-server.txt', 'data_config.json']
    files = []
    for name in names:
        path = root / name
        items = [p for p in path.rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix not in {'.gz', '.zip'}] if path.is_dir() else ([path] if path.exists() else [])
        files += [(p, p.relative_to(root)) for p in items]
    if args.include_prepared_data:
        data_root = resolve_data_root(args.data_root)
        files += [(p, Path('prepared_data') / p.relative_to(data_root)) for p in data_root.rglob('*')
                  if p.is_file() and '.cache' not in p.parts]
    output = Path(args.output).resolve()
    if output.exists():
        raise FileExistsError(output)
    if any(p.is_symlink() for p, _ in files):
        raise ValueError('Bundle contains symbolic links; make portable copies first')
    with tarfile.open(output, 'w:gz') as archive:
        for path, relative in sorted(files):
            archive.add(path, arcname=str(Path('Attn_exp_code') / relative), recursive=False)
    h = hashlib.sha256()
    with output.open('rb') as file:
        for chunk in iter(lambda: file.read(1024 * 1024), b''):
            h.update(chunk)
    output.with_suffix(output.suffix + '.json').write_text(json.dumps(dict(file=output.name, files=len(files),
        bytes=output.stat().st_size, sha256=h.hexdigest(), includes_prepared_data=args.include_prepared_data), indent=2))
    print(output)


if __name__ == '__main__':
    main()
