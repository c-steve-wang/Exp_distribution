#!/usr/bin/env bash
# Source from Slurm batch scripts before starting Python or other computation.
if [[ -z "${SLURM_JOB_ID:-}" || -z "${SLURMD_NODENAME:-}" ]]; then
  echo 'Refusing computation: submit this script with sbatch or run inside an allocated srun step.' >&2
  exit 2
fi
gg_execution_host=$(hostname -s)
if [[ "$gg_execution_host" != "${SLURMD_NODENAME%%.*}" ]]; then
  echo "Refusing computation: host $gg_execution_host is not the allocated execution node $SLURMD_NODENAME." >&2
  exit 2
fi
export OMP_NUM_THREADS="${SLURM_CPUS_PER_TASK:-1}"
export MKL_NUM_THREADS="$OMP_NUM_THREADS" OPENBLAS_NUM_THREADS="$OMP_NUM_THREADS"
export NUMEXPR_NUM_THREADS="$OMP_NUM_THREADS" TOKENIZERS_PARALLELISM=false
printf 'Compute node: %s; Slurm job: %s; CPUs: %s\n' "$gg_execution_host" "$SLURM_JOB_ID" "$OMP_NUM_THREADS"
