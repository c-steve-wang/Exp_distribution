#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
python -m pip install -r requirements-lock.txt
python -c 'import torch, torchvision; print("torch", torch.__version__, "torchvision", torchvision.__version__, "CUDA", torch.version.cuda)'
mkdir -p logs work outputs
python -m pip freeze > outputs/environment.freeze.txt
python scripts/project.py --help
