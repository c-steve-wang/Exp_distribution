"""Audit every public Hallu pair using annotations only; semantic review stays unlabelled."""
from pathlib import Path
import argparse
import re
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from experiments.common import write_json,fingerprint
from experiments.data import ExperimentData
from experiments.data_source import resolve_data_root
from experiments.analysis import dump_csv


def audit(data):
    rows=[]
    for sample in data.primary('test',['hallusegbench']):
        pair=data.pair(sample)
        a,b=pair['factual_original'],pair['counterfactual_original']
        c,d=pair['factual_replacement'],pair['counterfactual_replacement']
        native=a.get('provenance',{}).get('native_annotation',{})
        labels=[native.get('factual_label',''),native.get('counterfactual_label','')]
        tokens=[set(re.findall(r'\w+',label.casefold())) for label in labels]
        overlap=len(tokens[0]&tokens[1])/len(tokens[0]|tokens[1]) if tokens[0]|tokens[1] else None
        rows.append(dict(pair_id=a['pair_id'],source_group_id=a['source_group_id'],task_type=a['task_type'],
            original_question=a['question'],replacement_question=d['question'],original_description=labels[0],replacement_description=labels[1],
            original_query_fixed=a['question']==b['question'],replacement_query_fixed=c['question']==d['question'],
            native_truth={k:w['reference']['answer'] for k,w in pair.items()},
            native_truth_changes=a['reference']['answer']!=b['reference']['answer'],description_token_jaccard=overlap,
            image_pixels_changed=a['image'].get('pixel_sha256')!=b['image'].get('pixel_sha256'),
            semantic_question_validity=None,edit_credibility=None,review_status='requires_independent_semantic_review',
            selection_policy='all_public_pairs_no_model_output_filter',native_annotation=native))
    return rows


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--data-root');p.add_argument('--output',default='verification/delivery_20261029/pair_review.json')
    args=p.parse_args();data=ExperimentData(resolve_data_root(args.data_root),'work/shared');rows=audit(data)
    write_json(args.output,dict(data_fingerprint=data.fingerprint(),pairs=len(rows),source_groups=len({r['source_group_id'] for r in rows}),
        rows=rows,structural_errors=sum(not r['original_query_fixed'] or not r['replacement_query_fixed'] or not r['native_truth_changes'] for r in rows)))
    dump_csv(Path(args.output).with_suffix('.csv'),rows)
    print(f'{len(rows)} pairs; independent semantic validity/edit review remains unlabelled')
