import unittest
from experiments.metrics import nonanswer_guard as guard_applies


class AnswerContentGuardTests(unittest.TestCase):
    def test_missing_answer_is_not_zero_but_real_answers_are_preserved(self):
        self.assertTrue(guard_applies(',', 'There are no items.'))
        self.assertTrue(guard_applies(':{', '2'))
        self.assertTrue(guard_applies('', 'a tree'))
        self.assertTrue(guard_applies('  ', '-'))
        for answer in ['0', '-3', 'none', '没有', 'Black Spruce']:
            self.assertFalse(guard_applies(answer, 'A concrete answer'))
        self.assertFalse(guard_applies('-', '-'))


if __name__=='__main__':
    unittest.main()
