"""Checks for E3 post-inference scoring and clustered analysis edge cases."""
import sys
from pathlib import Path
import unittest
from unittest.mock import patch

sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'scripts'))
from experiments.experiment4_analysis import estimate as _estimate
def estimate(values): return _estimate(values,1000)
from experiments.metrics import nonanswer_guard
def nonanswer(value): return nonanswer_guard(value,'reference')
from experiments.judge import prediction_text


class Experiment3ReportingTests(unittest.TestCase):
    def test_shared_scene_is_one_cluster_but_rows_keep_their_weight(self):
        result=estimate([('scene_a',1),('scene_a',1),('scene_b',0)])
        self.assertEqual((result['n'],result['source_groups']),(3,2))
        self.assertAlmostEqual(result['mean'],2/3)
        self.assertEqual((result['low'],result['high']),(0,1))

    def test_missing_and_single_source_do_not_invent_precision(self):
        self.assertIsNone(estimate([('a',None)])['mean'])
        result=estimate([('a',1),('a',0)])
        self.assertEqual(result['mean'],.5)
        self.assertIsNone(result['low'])
        self.assertIsNone(result['high'])

    def test_paired_differences_allow_negative_effects(self):
        result=estimate([('a',-1),('b',-1)])
        self.assertEqual((result['mean'],result['low'],result['high']),(-1,-1,-1))

    def test_nonanswers_are_not_negations_or_zero_counts(self):
        for text in ('',',',':{',':[','  '):
            self.assertTrue(nonanswer(text))
        for text in ('0','none','No target exists.','否',', 0'):
            self.assertFalse(nonanswer(text))
        row={'prediction':{'status':'UNKNOWN','answer':''}}
        self.assertFalse(nonanswer(prediction_text(row)))


if __name__=='__main__':
    unittest.main()
