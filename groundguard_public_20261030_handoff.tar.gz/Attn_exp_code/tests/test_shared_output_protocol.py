"""Cross-experiment generation contracts, control paths and public pilot selection."""
from copy import deepcopy
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
import json
import tempfile
import unittest
from experiments.common import read_json, load_config
from experiments.protocol import prediction_request, prediction_contract, parse_task_prediction
from experiments.delivery import observations, select_public, select_controls
from experiments.engine import Engine
from experiments.controls import run_controls
from experiments.geometry import view
from test_experiments import FixtureData, FakeBackend
from test_pilot import rows_for

ROOT = Path(__file__).resolve().parents[1]


class SchemaBackend(FakeBackend):
    def __init__(self):
        super().__init__()
        self.spec['structured_output'] = 'xgrammar'

    def infer(self, *args, output_schema=None, **kwargs):
        if output_schema is None:
            raise AssertionError('Task inference bypassed the shared schema')
        return super().infer(*args, **kwargs)


class SharedProtocolTest(unittest.TestCase):
    def test_e12_budgets_are_reference_blind_and_preserve_view_frames(self):
        from experiments.experiment2_protocol import prediction_schema as e2_schema, proposal_schema
        overview = dict(label='overview', source_box=[0, 0, 100, 100], source_size=[100, 100])
        crop = dict(label='crop', source_box=[10, 10, 50, 50], source_size=[100, 100])
        for experiment in (1, 2):
            cfg = load_config(ROOT / f'configs/public_e{experiment}.json')
            for dataset, limit in [('gseval', 1), ('groundingme', 1), ('hallusegbench', 1), ('vistaqa', 64)]:
                sample = dict(dataset=dataset, question='Locate the requested target.')
                for views in ([overview], [crop], [overview, crop], [overview, crop, crop, crop, crop]):
                    request = prediction_request(sample, views, cfg, experiment, structured=True)
                    changed = dict(sample, reference=dict(answer='SECRET', regions=[{}]*91), condition='different')
                    self.assertEqual(request, prediction_request(changed, views, cfg, experiment, structured=True))
                    boxes = request['output_schema']['properties']['boxes']
                    self.assertEqual(boxes['maxItems'], limit)
                    self.assertIn('at most one' if limit == 1 else 'at most 64', request['prompt'])
                    self.assertEqual(boxes['items']['properties']['view']['enum'],
                                     [0] if experiment == 1 else list(range(len(views))))
                    if experiment == 2:
                        self.assertEqual(request['output_schema'], e2_schema(dataset, len(views)))
        regions = proposal_schema()['properties']['regions']
        self.assertEqual((regions['minItems'], regions['maxItems']), (8, 8))

    def test_e12_real_grammar_enforces_budgets_and_parser_rejects_excess(self):
        import xgrammar as xgr
        compiler = xgr.GrammarCompiler(xgr.TokenizerInfo(
            [bytes([i]) for i in range(256)] + [b'<eos>'], stop_token_ids=[256]), max_threads=2)
        views = [dict(label='overview', source_box=[0, 0, 100, 100], source_size=[100, 100])]
        for experiment in (1, 2):
            cfg = load_config(ROOT / f'configs/public_e{experiment}.json')
            for dataset, status, limit in [('gseval', 'MATCH', 1), ('groundingme', 'MATCH', 1),
                                            ('hallusegbench', 'PRESENT', 1), ('vistaqa', 'ANSWERED', 64)]:
                sample = dict(dataset=dataset, question='Locate the target.')
                schema = prediction_request(sample, views, cfg, experiment, structured=True)['output_schema']
                grammar = compiler.compile_json_schema(schema, max_whitespace_cnt=2, any_order=False)
                contract = prediction_contract(cfg, views, experiment)
                # Distinct boxes: the limit must preserve multi-instance output, not just reject duplicates.
                boxes = [dict(view=0, bbox=[i/100, 0.1, (i+1)/100, 0.9]) for i in range(65)]
                for count in (0, limit, limit+1):
                    payload = json.dumps(dict(answer='target', status=status, boxes=boxes[:count], facts=[]))
                    matcher = xgr.GrammarMatcher(grammar)
                    accepted = bool(matcher.accept_string(payload) and matcher.is_completed())
                    self.assertEqual(accepted, count <= limit)
                    parsed = parse_task_prediction(payload, 1, dataset, contract, schema=schema)
                    self.assertEqual(parsed['parse_error'] is None, count <= limit)

    def test_e12_decoder_blocks_an_extra_box_and_stops_at_eos(self):
        import torch
        import xgrammar as xgr
        from xgrammar.contrib.hf import LogitsProcessor
        compiler = xgr.GrammarCompiler(xgr.TokenizerInfo(
            [bytes([i]) for i in range(256)] + [b'<eos>'], stop_token_ids=[256]), max_threads=2)
        views = [dict(label='overview', source_box=[0, 0, 100, 100], source_size=[100, 100])]
        target = json.dumps(dict(answer='target', status='MATCH',
            boxes=[dict(view=0, bbox=[.1,.2,.5,.7])], facts=[]), separators=(',', ':'))
        for experiment in (1, 2):
            cfg = load_config(ROOT / f'configs/public_e{experiment}.json')
            schema = prediction_request(dict(dataset='gseval', question='Target?'), views,
                cfg, experiment, structured=True)['output_schema']
            grammar = compiler.compile_json_schema(schema, any_whitespace=False, separators=(',', ':'), any_order=False)
            for _ in range(2):
                processor = LogitsProcessor(grammar)
                ids = [256]
                for i in range(len(target)+1):
                    expected = ord(target[i]) if i<len(target) else 256
                    logits = torch.full((1,257), -float('inf'))
                    logits[0,expected] = 0
                    if i == target.index('],"facts"'):
                        logits[0,ord(',')] = 100  # Prefer extending boxes beyond its task budget.
                    if i == len(target):
                        logits[0,ord('{')] = 100  # Prefer starting another object over EOS.
                    chosen = processor(torch.tensor([ids]), logits).argmax(-1).item()
                    self.assertEqual(chosen, expected)
                    ids.append(chosen)
                self.assertEqual(ids[-1], 256)

    def test_preflight_and_inference_use_same_schema_and_original_question(self):
        with tempfile.TemporaryDirectory() as tmp:
            data = FixtureData(tmp)
            sample = data.records['I_plus']
            image = data.image(sample)
            for experiment in range(1, 5):
                cfg = load_config(ROOT / f'configs/public_e{experiment}.json')
                cfg.update(overview_edge=32, crop_edge=32)
                self.assertEqual(cfg['model_defaults']['structured_output'], 'xgrammar')
                self.assertFalse(cfg['model_defaults']['structured_compact_json'])
                views = [view(image, edge=32, label='overview')]
                # E4 rejects synthetic worlds when planning, but its request is task-independent.
                request = prediction_request(sample, views, cfg, experiment, structured=True)
                self.assertIn(sample['question'], request['prompt'])
                backend = SchemaBackend()
                engine = Engine(backend, data, Path(tmp) / str(experiment), cfg, 'fixture')
                result = engine.evaluate(sample, views, 42, experiment=experiment)
                cached = read_json(engine.run_dir / 'cache' / (result['request_id'] + '.json'))
                self.assertEqual(cached['request']['output_schema'], request['output_schema'])
                self.assertEqual(cached['request']['prompt'], request['prompt'])
                if experiment in (1, 2):
                    preflight = observations(data, sample, cfg, experiment)[0][2]
                    self.assertEqual(preflight, request)

    def test_control_paths_including_no_image_cannot_bypass_constraints(self):
        with tempfile.TemporaryDirectory() as tmp:
            data = FixtureData(tmp)
            cfg = load_config(ROOT / 'configs/public_e1.json')
            cfg.update(overview_edge=32, crop_edge=32)
            engine = Engine(SchemaBackend(), data, tmp, cfg, 'fixture')
            sample = data.records['I_plus']
            donors = {sample['sample_id']: dict(donor_id=data.records['I_minus']['sample_id'],
                donor_source_group_id='donor', seed=42)}
            run_controls(engine, [sample], donors, dict(supported=True))
            rows = [read_json(p) for p in (engine.run_dir / 'records').glob('*.json')]
            self.assertEqual(len(rows), 3)
            for row in rows:
                self.assertEqual(row['status'], 'ok', row.get('traceback'))
                raw = read_json(engine.run_dir / 'cache' / (row['request_id'] + '.json'))
                schema = raw['request']['output_schema']
                if row['condition'] == 'control_no_image':
                    self.assertEqual(schema['properties']['boxes']['maxItems'], 0)
                    self.assertIn('Return an empty boxes list', raw['request']['prompt'])
                else:
                    self.assertEqual(schema['properties']['boxes']['items']['properties']['view']['enum'], [0])
                    self.assertEqual(schema['properties']['boxes']['maxItems'], 64)

    def test_actual_grammar_allows_whitespace_and_escapes_but_rejects_bad_structure(self):
        import xgrammar as xgr
        compiler = xgr.GrammarCompiler(xgr.TokenizerInfo(
            [bytes([i]) for i in range(256)] + [b'<eos>'], stop_token_ids=[256]), max_threads=2)
        sample = dict(dataset='vistaqa', question='What is visible?')
        views = [dict(label='overview', source_box=[0, 0, 100, 100], source_size=[100, 100])]
        for experiment in range(1, 5):
            cfg = load_config(ROOT / f'configs/public_e{experiment}.json')
            schema = prediction_request(sample, views, cfg, experiment, structured=True)['output_schema']
            grammar = compiler.compile_json_schema(schema, max_whitespace_cnt=2, any_order=False)
            def accepts(payload):
                matcher = xgr.GrammarMatcher(grammar)
                return matcher.accept_string(json.dumps(payload)) and matcher.is_completed()
            payload = dict(answer='红色 "label" \\ \n', status='ANSWERED', boxes=[], facts=['short'])
            self.assertTrue(accepts(payload))
            bad = deepcopy(payload); bad['status'] = 'MATCH'
            self.assertFalse(accepts(bad))
            bad = deepcopy(payload); bad['facts'] *= 4
            self.assertFalse(accepts(bad))
            bad = deepcopy(payload); bad['boxes'] = [dict(view=0, bbox=[1, 2, 500, 700])]
            self.assertFalse(accepts(bad))
            contract = prediction_contract(cfg, views, experiment)
            bad['boxes'][0]['bbox'] = [.5, .1, .2, .7]
            self.assertTrue(accepts(bad))
            self.assertIsNotNone(parse_task_prediction(json.dumps(bad), 1, sample['dataset'], contract, schema=schema)['parse_error'])
            self.assertIsNotNone(parse_task_prediction(json.dumps(payload), 1, sample['dataset'], contract,
                schema=schema, finish_reason='length')['parse_error'])


class PublicPilotTest(unittest.TestCase):
    def test_manifest_selection_reuses_stratified_source_group_pilot(self):
        rows = rows_for(dict(vistaqa=21, gseval=20, groundingme=10, hallusegbench=10))
        rows.append(dict(rows[0], sample_id=rows[0]['sample_id'] + '/extra'))
        data = SimpleNamespace(primary=lambda *args: list(rows))
        cfg = dict(seed=42)
        selected = select_public(data, cfg, 1, pilot_fraction=.1)
        for experiment in (3, 4):
            self.assertEqual(selected, select_public(data, cfg, experiment, pilot_fraction=.1))
        for name, count in dict(vistaqa=3, gseval=2, groundingme=1, hallusegbench=1).items():
            self.assertEqual(len({r['source_group_id'] for r in selected if r['dataset']==name}), count)
        controls = select_controls(selected, 5, 42)
        self.assertTrue({r['sample_id'] for r in controls} <= {r['sample_id'] for r in selected})
        with self.assertRaises(ValueError):
            select_public(data, cfg, 1, count=5, pilot_fraction=.1)

    def test_e2_ten_percent_uses_fixed_audit_population(self):
        rows = rows_for(dict(vistaqa=250, gseval=50, groundingme=50, hallusegbench=150))
        with patch('experiments.data.prepare_audit'), patch('experiments.runner.audit_samples', return_value=rows):
            selected = select_public(None, dict(seed=42), 2, pilot_fraction=.1)
        self.assertEqual(len(selected), 50)


if __name__ == '__main__':
    unittest.main()
