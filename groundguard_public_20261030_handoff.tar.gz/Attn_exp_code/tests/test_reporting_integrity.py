"""Regressions for tie-invariant instance coverage and unstarted shard accounting."""
from copy import deepcopy
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
import numpy as np
from PIL import Image

from experiments.common import read_json, write_json, load_config
from experiments.completeness import source_completeness, write_shard_plan
from experiments.engine import Engine
from experiments.geometry import view
from experiments.metrics import attention_metrics, instance_attention_metrics
from experiments.paper_analysis import refresh_attention
from experiments.analysis import load_records, summarize
from test_experiments import FixtureData, FakeBackend

ROOT = Path(__file__).resolve().parents[1]


class UniformData(FixtureData):
    def __init__(self, root):
        super().__init__(root)
        self.mask = np.zeros((10,10), bool)
        self.mask[0,:] = self.mask[-1,:] = True
        for sample in self.records.values():
            sample['image'].update(width=10,height=10)
            sample['reference']['regions'] = [dict(bbox_xyxy=[0,y,10,y+1],area=10,mask={}) for y in (0,9)]

    def image(self, sample):
        return Image.new('RGB',(10,10),'white')

    def region_mask(self, sample, region_index=None):
        if region_index is None:
            return self.mask.copy()
        result = np.zeros_like(self.mask)
        result[0 if region_index == 0 else -1,:] = True
        return result


class InstanceCoverageTests(unittest.TestCase):
    def test_uniform_top_and_bottom_single_and_joint_coverage(self):
        heat = np.ones((10,10))/100
        top, bottom = np.zeros((10,10),bool), np.zeros((10,10),bool)
        top[0] = bottom[-1] = True
        for masks in ([top],[bottom],[top,bottom]):
            result = instance_attention_metrics(heat,masks,coverages=(.1,.9))
            self.assertEqual(result['instance_coverage']['0.1'],[.1]*len(masks))
            self.assertEqual(result['instance_coverage'],result['instance_coverage_tie_averaged'])
            self.assertFalse(result['all_instances_covered_at90']['0.1'])
            self.assertTrue(result['all_instances_covered_at90']['0.9'])

    def test_non_tied_and_missing_attention_do_not_fabricate_coverage(self):
        heat = np.arange(100,dtype=float).reshape(10,10)
        top = np.zeros((10,10),bool); top[-1] = True
        low = np.zeros_like(top);low[0] = True
        result = instance_attention_metrics(heat,[top,low],coverages=(.1,))
        self.assertEqual(result['instance_coverage']['0.1'],[1.,0.])
        for heatmap, masks in ((heat,[np.zeros_like(top)]),(np.zeros_like(heat),[top]),(heat,[])):
            self.assertIsNone(instance_attention_metrics(heatmap,masks)['all_instances_covered_at90']['0.1'])

    def test_engine_and_cache_reanalysis_use_same_rule_without_model_rerun(self):
        with tempfile.TemporaryDirectory() as tmp:
            data = UniformData(tmp)
            cfg = load_config(ROOT/'configs/experiments.json')
            cfg.update(overview_edge=10,crop_edge=10,bootstrap_repeats=2)
            backend = FakeBackend();engine = Engine(backend,data,tmp,cfg,'fixture')
            sample = data.records['I_plus']
            row = engine.evaluate(sample,[view(data.image(sample),edge=10,label='overview')],42,experiment=1)
            self.assertEqual(row['attention']['instance_coverage']['0.1'],[.1,.1])
            self.assertEqual(row['attention']['coverage']['0.1'],.1)
            row.update(status='ok',record_file='old.json',condition='control_original',extra=dict(axis='visual_control'))
            old = deepcopy(row)
            old['attention'].pop('instance_coverage_policy')
            old['attention']['instance_coverage'] = {'0.1':[1.,0.]}
            before = {p:p.read_bytes() for p in (engine.run_dir/'cache').iterdir()}
            with patch.object(backend,'infer',side_effect=AssertionError('Must not run model')):
                audit = refresh_attention(engine.run_dir,[old],data=data)
            self.assertEqual(audit[0]['status'],'recomputed_from_cache')
            self.assertEqual(old['attention']['instance_coverage']['0.1'],[.1,.1])
            self.assertFalse(old['attention']['all_instances_covered_at90']['0.1'])
            self.assertEqual(refresh_attention(engine.run_dir,[old],data=data),[])
            self.assertEqual(before,{p:p.read_bytes() for p in (engine.run_dir/'cache').iterdir()})
            inference = read_json(engine.run_dir/'cache'/(row['request_id']+'.json'))
            (engine.run_dir/'cache'/inference['attention_file']).unlink()
            audit = refresh_attention(engine.run_dir,[dict(row,attention={})],data=data)
            self.assertEqual(audit[0]['status'],'missing_attention_cache')


class CompletenessTests(unittest.TestCase):
    def setup_run(self, root):
        manifest = dict(experiment=2,sample_ids=['a','b'],controls=[],config=dict(seed=42))
        write_json(root/'delivery_manifest.json',manifest)
        write_json(root/'selection_e2_test_shard0of2.json',dict(experiment=2,subset='test',shards=2,shard_index=0,sample_ids=['a']))
        write_json(root/'progress/a.json',dict(experiment=2,subset='test',sample_id='a',completed=True))
        return manifest

    def test_manifest_detects_shard_that_never_started(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp);self.setup_run(root)
            result = source_completeness(root,[],[])
            self.assertEqual(result['selected_sources_not_completed'],[(2,'test','b')])
            self.assertEqual(result['sources_never_started'],[(2,'test','b')])
            self.assertFalse(result['inference_complete'])
            shards = result['shard_completion']
            self.assertTrue(shards[0]['inference_complete'])
            self.assertEqual(shards[1]['state'],'not_started')
            write_json(root/'progress/b.json',dict(experiment=2,subset='test',sample_id='b',completed=True))
            self.assertTrue(source_completeness(root,[],[])['inference_complete'])

    def test_controls_and_incomplete_conditions_override_progress_markers(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp);m=self.setup_run(root)
            m.update(sample_ids=['a'],controls=['a']);write_json(root/'delivery_manifest.json',m)
            result = source_completeness(root,[],[])
            self.assertFalse(result['inference_complete'])
            self.assertEqual(len(result['control_records_not_completed']),3)
            rows = [dict(experiment=1,subset='test',sample_id='a',source_group_id='g',seed=42,
                         extra=dict(axis='visual_control'),condition=c,status='skipped',record_file=c)
                    for c in ('control_original','control_no_image','control_wrong_image')]
            self.assertTrue(source_completeness(root,rows,[])['inference_complete'])
            rows[0]['status'] = 'not_run'
            self.assertFalse(source_completeness(root,rows,[])['inference_complete'])

    def test_no_manifest_cannot_certify_global_completion(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp);self.setup_run(root)
            (root/'delivery_manifest.json').unlink()
            result = source_completeness(root,[],[])
            self.assertEqual(result['completeness_scope'],'observed_selections_only')
            self.assertIsNone(result['inference_complete'])

    def test_all_shards_are_planned_with_controls_and_source_groups(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            samples = [dict(sample_id=str(i),source_group_id='group'+str(i//2)) for i in range(8)]
            plan = write_shard_plan(root,dict(experiment=3),samples,[samples[0]],4)
            self.assertEqual(sorted(s for a in plan['assignments'] for s in a['sample_ids']),[str(i) for i in range(8)])
            for assignment in plan['assignments']:
                for sid in assignment['sample_ids']:
                    self.assertIn(str(int(sid)^1),assignment['sample_ids'])
            self.assertEqual(len(source_completeness(root,[],[])['shard_completion']),4)

    def test_real_summary_exposes_manifest_missing_sources(self):
        with tempfile.TemporaryDirectory() as tmp:
            data = FixtureData(tmp);cfg=load_config(ROOT/'configs/experiments.json');cfg['bootstrap_repeats']=2
            engine = Engine(FakeBackend(),data,tmp,cfg,'fixture')
            self.setup_run(engine.run_dir)
            output = summarize(engine.run_dir,cfg)
            complete = read_json(output/'completeness.json')
            self.assertFalse(complete['inference_complete'])
            self.assertEqual(complete['selected_sources_not_completed'],[[2,'test','b']])

    def test_export_retains_completion_evidence_for_offline_summary(self):
        from experiments.runner import Runner
        from experiments.delivery import main
        with tempfile.TemporaryDirectory() as tmp:
            data=FixtureData(tmp);cfg=load_config(ROOT/'configs/experiments.json');cfg['bootstrap_repeats']=2
            engine=Engine(FakeBackend(),data,tmp,cfg,'fixture')
            sample=data.records['I_plus']
            write_json(engine.run_dir/'delivery_manifest.json',dict(experiment=1,sample_ids=[sample['sample_id']],controls=[]))
            Runner(engine).run(1,[sample])
            destination=Path(tmp)/'export'
            with patch('sys.argv',['project.py','export','--run-dir',str(engine.run_dir),'--destination',str(destination)]):
                main()
            self.assertTrue(list((destination/'progress').glob('*.json')))
            output=summarize(destination,cfg)
            self.assertTrue(read_json(output/'completeness.json')['inference_complete'])

    def test_delivery_shard_records_global_missing_main_and_control_conditions(self):
        from types import SimpleNamespace
        from experiments.common import shard_contains
        from experiments.delivery import run
        from experiments.runner import experiment1_expected
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);data=FixtureData(tmp)
            samples=[data.records['I_plus'],data.records['I_minus']]
            for index,sample in enumerate(samples):
                sample['source_group_id']=next('group'+str(i) for i in range(100)
                    if shard_contains('group'+str(i),index,2))
            cfg=load_config(ROOT/'configs/experiments.json');cfg['bootstrap_repeats']=2
            donor=dict(donor_id=samples[0]['sample_id'],donor_source_group_id=samples[0]['source_group_id'],seed=42)
            m=dict(experiment=1,model='qwen35_9b',config=cfg,lock={'qwen35_9b':{}},output_root=str(root/'output'),
                   sample_ids=[s['sample_id'] for s in samples],controls=[samples[1]['sample_id']],
                   donors={samples[1]['sample_id']:donor},no_image_interface=dict(supported=True))
            manifest=root/'manifest.json';write_json(manifest,m);write_json(manifest.with_suffix('.gpu.json'),{})
            write_json(manifest.with_suffix('.expected.json'),dict(records=[r for s in samples for r in experiment1_expected(s,'test',42)]))
            args=SimpleNamespace(command='run',manifest=str(manifest),shards=2,shard_index=0,retry_errors=False)
            with patch('experiments.delivery.verify',return_value=(m,data,samples)), \
                 patch('experiments.delivery.require_gpu_gate',return_value=dict(passed=True)), \
                 patch('experiments.backends.VisionBackend',return_value=FakeBackend()):
                run(args)
            pointer=read_json(manifest.with_suffix('.run_shard0.json'))
            self.assertTrue(pointer['shard_inference_complete'])
            self.assertFalse(pointer['inference_complete'])
            complete=read_json(Path(pointer['run_dir'])/'summary/completeness.json')
            self.assertEqual(complete['shard_completion'][1]['state'],'not_started')
            self.assertEqual(len(complete['expected_records_not_run']),7)
            self.assertEqual(len(complete['control_records_not_completed']),3)


if __name__ == '__main__':
    unittest.main()
