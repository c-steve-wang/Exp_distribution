"""Unified public launch replaces the retired E3 pilot/frozen-dir wrapper."""
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
from types import SimpleNamespace
from experiments.common import write_json
from experiments.delivery import verify,require_gpu_gate,backend_matches


class PublicLaunchTest(unittest.TestCase):
    def test_code_change_rejected_before_data_or_gpu_load(self):
        with tempfile.TemporaryDirectory() as folder:
            path=Path(folder)/'manifest.json';write_json(path,dict(code='old'))
            with self.assertRaisesRegex(ValueError,'Code changed'):verify(path)

    def test_missing_preflight_is_not_permission_to_launch(self):
        with tempfile.TemporaryDirectory() as folder:
            with self.assertRaisesRegex(ValueError,'gpu-preflight'):
                require_gpu_gate(Path(folder)/'manifest.json',SimpleNamespace(metadata=lambda:{}))

    def test_normalized_backend_identity_still_rejects_changes(self):
        self.assertTrue(backend_matches({'a':{0:1}},{'a':{'0':1}}))
        self.assertFalse(backend_matches({'revision':'a'},{'revision':'b'}))


if __name__=='__main__':unittest.main()
