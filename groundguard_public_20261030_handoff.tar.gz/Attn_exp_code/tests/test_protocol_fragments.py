"""Regressions for actual repetition/truncation and nested-box parser failures."""
import json
import unittest
from experiments.protocol import final_json, parse_prediction, json_object_strings


class ProtocolFragmentsTest(unittest.TestCase):
    def setUp(self):
        self.answer = dict(answer='yes', status='MATCH',
                           boxes=[dict(view=0, bbox=[.48, .33, .61, .42])], facts=[])
        self.text = json.dumps(self.answer)

    def test_truncated_repetition_cannot_replace_complete_answer_with_nested_box(self):
        trailing = '{"answer":"yes","status":"MATCH","boxes":[{"view":0,"bbox":[0,0,1,1]}],"facts":["cut'
        text = self.text + '\n' + self.text + '\n' + trailing
        self.assertEqual(final_json(text), self.answer)
        self.assertIsNone(parse_prediction(text, 1)['parse_error'])
        objects, truncated = json_object_strings(text)
        self.assertEqual(len(objects), 2)
        self.assertTrue(truncated)

    def test_nested_box_without_complete_answer_is_not_an_answer(self):
        text = '{"answer":"yes","boxes":[{"view":0,"bbox":[0,0,1,1]}],"facts":['
        self.assertIsNotNone(parse_prediction(text, 1)['parse_error'])
        self.assertEqual(json_object_strings(text), ([], True))

    def test_complete_invalid_last_answer_is_not_replaced_by_earlier_valid_one(self):
        self.assertIsNotNone(parse_prediction(self.text + '\n{"answer":1}', 1)['parse_error'])
        self.assertIsNotNone(parse_prediction(self.text + '\n{"answer": }', 1)['parse_error'])

    def test_duplicate_keys_are_rejected_instead_of_silently_overwritten(self):
        text = '{"answer":"yes","status":"MATCH","boxes":[{"view":0,"bbox":[0,0,1,1],"bbox":[0,0,0.5,0.5]}]}'
        self.assertIn('Duplicate JSON key', parse_prediction(text, 1)['parse_error'])

    def test_braces_and_escaped_quotes_inside_strings_do_not_change_boundaries(self):
        self.answer['answer'] = 'A {label} and an escaped "quote"'
        text = '<think>{"irrelevant":1}</think>```json\n' + json.dumps(self.answer) + '\n```'
        self.assertEqual(final_json(text), self.answer)

    def test_coordinate_validation_is_unchanged(self):
        for box in [[0, 0, 1000, 1000], [.2, 100, .4, 900], [0, 0, 0, 1]]:
            self.answer['boxes'][0]['bbox'] = box
            self.assertIsNotNone(parse_prediction(json.dumps(self.answer), 1)['parse_error'])


if __name__ == '__main__':
    unittest.main()
