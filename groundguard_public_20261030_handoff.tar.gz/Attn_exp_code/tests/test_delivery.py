"""Checklist regressions on estimands, real hook tensors, controls and delivery selection."""
import json
from pathlib import Path
import tempfile
import unittest
import numpy as np
from experiments.metrics import attention_metrics, finalize_answer_scores, box_matches, rank_correlation
from experiments.action_analysis import policy_scores
from experiments.paper_analysis import conditional_cpc
from experiments.controls import donor_plan
from experiments.common import read_json,write_json
from experiments.backends import AttentionCapture


class DeliveryTests(unittest.TestCase):
    def test_legacy_execution_cannot_bypass_project_gate(self):
        from unittest.mock import patch
        from experiments.__main__ import main
        for command in [['run','--experiment','1','--model','qwen35_9b'],
                        ['propose'],['smoke','--model','qwen35_9b'],['judge','--run-dir','unused']]:
            with self.subTest(command=command), patch('sys.argv',['experiments',*command]):
                with self.assertRaisesRegex(SystemExit,'scripts/project.py'):
                    main()

    def test_lossless_cache_and_atomic_failure(self):
        from experiments.engine import save_npz
        with tempfile.TemporaryDirectory() as tmp:
            path=Path(tmp)/'cache.npz'
            values={'heads':np.arange(120,dtype=np.float32).reshape(3,4,10)[:,:,::2],
                    'mask':np.array([[True,False]],dtype=bool)}
            save_npz(path,values)
            with np.load(path,allow_pickle=False) as saved:
                for key,value in values.items():
                    self.assertEqual(saved[key].dtype,value.dtype)
                    np.testing.assert_array_equal(saved[key],value)
            before=path.read_bytes()
            with self.assertRaises(ValueError):
                save_npz(path,{'unsupported':np.array([object()],dtype=object)})
            self.assertEqual(path.read_bytes(),before)
            self.assertEqual(list(Path(tmp).iterdir()),[path])

    def test_area_one_three_and_equal_area(self):
        mask=np.array([[True,False,False,False]])
        boxes=[dict(bbox=[0,0,1,1]),dict(bbox=[1,0,4,1])]
        metric,heat=attention_metrics([[.5,.5]],boxes,mask,(4,1))
        self.assertEqual(metric['uniform_evidence_mass'],.25);self.assertEqual(metric['enrichment'],2.)
        self.assertAlmostEqual(heat.sum(),1.)
        equal=[dict(bbox=[0,0,2,1]),dict(bbox=[2,0,4,1])]
        metric,_=attention_metrics([[.5,.5]],equal,mask,(4,1))
        self.assertEqual(metric['enrichment'],1.)
        empty,_=attention_metrics([[.5,.5]],boxes,np.zeros_like(mask),(4,1))
        self.assertIsNone(empty['enrichment'])

    def test_answers_and_strict_localization(self):
        for answer,expected in [('',False),('...',False),('0',True),('没有',True)]:
            row=dict(status='ok',prediction=dict(answer=answer,status='ANSWERED'),reference=dict(answer='0',answer_type='text',regions=[{}]),
                     scores=dict(format_valid=True,answer_correct=True,all_boxes_correct=True,concrete_answer=True))
            finalize_answer_scores(row)
            self.assertEqual(row['scores']['answer_correct'],expected)
            self.assertEqual(row['scores']['joint_answer_localization'],expected)
        status=dict(status='ok',prediction=dict(answer='',status='ABSENT'),reference=dict(answer='ABSENT',answer_type='grounding_presence',regions=[]),scores=dict(answer_correct=True,concrete_answer=True))
        self.assertTrue(finalize_answer_scores(status)['scores']['answer_correct'])
        punctuation=dict(status='ok',prediction=dict(answer='!',status='ANSWERED'),reference=dict(answer='!',regions=[]),scores=dict(answer_correct=True,concrete_answer=True))
        self.assertTrue(finalize_answer_scores(punctuation)['scores']['answer_correct'])
        score=box_matches([[0,0,1,1],[2,2,3,3]],[[0,0,1,1]])
        self.assertTrue(score['all_instances_hit']);self.assertFalse(score['all_boxes_correct'])
        self.assertFalse(box_matches([],[[0,0,1,1]])['all_instances_hit'])
        self.assertIsNone(box_matches([],[])['all_boxes_correct'])

    def test_actual_policy_scores_and_fixed_gap_identity(self):
        audit=dict(sample_id='a',attention_scores=[0,1,2],candidates=[dict(source='question',scheduled_source='question',saliency_score=s) for s in [2,1,0]])
        utility=[0,1,2]
        attention,_=policy_scores(audit,'attention',3);saliency,_=policy_scores(audit,'saliency',3)
        self.assertEqual(rank_correlation(attention,utility),1);self.assertEqual(rank_correlation(saliency,utility),-1)
        question,kind=policy_scores(audit,'question',3)
        self.assertEqual(kind,'proposal_order');self.assertEqual(rank_correlation(question,utility),-1)
        self.assertIsNone(policy_scores(audit,'random',3)[0]);self.assertIsNone(rank_correlation(attention,[1,1,1]))
        reference=np.array([0.,.5,1.]);chosen=0
        proposal=reference.max()-reference[:2].max();selection=reference[:2].max()-reference[chosen]
        self.assertEqual(proposal+selection,reference.max()-reference[chosen])

    def test_cpc_is_status_and_condition_denominators_rebuild(self):
        def row(cell,status,enrichment,loc):
            return dict(experiment=4,dataset='hallusegbench',subset='test',condition='fact_baseline',pair_id='pair',seed=42,
                source_group_id='source',native_condition=cell,status='ok',question='same query',
                reference=dict(answer=status,answer_type='grounding_presence',regions=[{}] if status=='PRESENT' else []),
                prediction=dict(status=status),scores=dict(format_valid=True,status_correct=True,answer_correct=True,
                concrete_answer=True,localization_correct=loc,no_target_boxes=True),
                attention=dict(intervention_region=dict(enrichment=enrichment)))
        rows=[row('factual_original','PRESENT',2,False),row('counterfactual_original','ABSENT',3,None)]
        rule=dict(tau=1,aggregation='min_endpoints',region='author_target_or_replacement')
        details,summary=conditional_cpc(rows,rule,3)
        self.assertTrue(details[0]['factual_cpc']);self.assertFalse(details[0]['joint_pair_correct'])
        self.assertEqual(summary[0]['conditional_pairs'],1);self.assertEqual(summary[0]['conditional_cpc'],1)
        _,empty=conditional_cpc(rows,dict(rule,tau=4),3)
        self.assertIsNone(empty[0]['conditional_cpc']);self.assertEqual(empty[0]['conditional_pairs'],0)
        rows[1]['attention']={};_,missing=conditional_cpc(rows,rule,3)
        self.assertEqual(missing[0]['attention_missing'],1)

    def test_head_query_decode_submatrices_reproduce_mean(self):
        import torch
        class Attention(torch.nn.Module):
            def __init__(self):
                super().__init__();self.q_proj=torch.nn.Linear(2,2)
            def forward(self,x):return x+1,x
        class Layer(torch.nn.Module):
            def __init__(self):super().__init__();self.self_attn=Attention()
        decoder=torch.nn.Module();decoder.layers=torch.nn.ModuleList([Layer()])
        x=torch.arange(2*5*5,dtype=torch.float32).reshape(1,2,5,5)/100
        with AttentionCapture(decoder,[3,4],[0,1],5,retain_head_query=True,decode_steps=1) as capture:
            output=decoder.layers[0].self_attn(x)
            decoder.layers[0].self_attn(torch.ones(1,2,1,6)/6)
        result=capture.result();detail=result['attention_arrays']['attention_prefill_000']
        self.assertEqual(detail.shape,(2,2,2));np.testing.assert_allclose(detail.mean((0,1)),result['layer_weights'][0])
        self.assertEqual(result['attention_indices']['attention_decode_000_0001']['queries'],[5])
        self.assertTrue(torch.equal(output[0],x+1));self.assertIsNone(output[1])
        self.assertFalse(decoder.layers[0].self_attn._forward_hooks)

    def test_wrong_images_are_reproducible_cross_source(self):
        samples=[dict(sample_id=str(i),source_group_id=str(i//2),dataset='vistaqa',image=dict(path=str(i))) for i in range(6)]
        a=donor_plan(samples,samples,42);self.assertEqual(a,donor_plan(samples,list(reversed(samples)),42))
        for sample in samples:self.assertNotEqual(a[sample['sample_id']]['donor_source_group_id'],sample['source_group_id'])


if __name__=='__main__':unittest.main()
