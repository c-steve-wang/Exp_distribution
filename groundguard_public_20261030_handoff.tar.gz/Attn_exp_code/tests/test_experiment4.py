"""E4 public four-cell design, failure denominators and independent measurements."""
from copy import deepcopy
import json
from pathlib import Path
import tempfile
from types import SimpleNamespace
import unittest
import numpy as np
from PIL import Image
from test_experiments import FixtureData, ROOT, DATA_ROOT
from test_experiment3 import Backend
from experiments.common import load_config, read_json, write_json
from experiments.engine import Engine
from experiments.runner import Runner, record_identity
from experiments.geometry import view
from experiments.analysis import load_records, summarize
from experiments.experiment4 import expected, observation_set, worlds, request
from experiments.experiment4_analysis import metric, pair_metrics


class HalluFixture(FixtureData):
    def __init__(self,root):
        super().__init__(root)
        template=deepcopy(self.records['I_plus'])
        self.records={}
        for condition in ('factual_original','factual_replacement','counterfactual_original','counterfactual_replacement'):
            s=deepcopy(template)
            original=condition.startswith('factual_')
            width=20 if original else 96
            present=condition in {'factual_original','counterfactual_replacement'}
            region=dict(bbox_xyxy=[width*.375,8,width*.625,16],area=width*.25*8,mask={})
            s.update(dataset='hallusegbench',task_type='referring',condition=condition,
                sample_id='hallu/pair/'+condition,source_group_id='hallu/source',pair_id='hallu/pair',
                question='Locate the original target?' if condition.endswith('_original') else 'Locate the replacement target?',
                image=dict(width=width,height=24 if not original else 20,path='original.png' if original else 'edited.png'),
                intervention_regions=[region])
            s['reference'].update(answer_type='grounding_presence',answer='PRESENT' if present else 'ABSENT',
                target_status='present' if present else 'absent',regions=[region] if present else [])
            self.records[condition]=s

    def image(self,sample):
        return Image.new('RGB',(sample['image']['width'],sample['image']['height']),'white')

    def region_mask(self,sample,region_index=None):
        mask=np.zeros((sample['image']['height'],sample['image']['width']),dtype=bool)
        regions=sample['reference']['regions']
        for r in regions if region_index is None else [regions[region_index]]:
            a,b,c,d=[round(v) for v in r['bbox_xyxy']]
            mask[b:d,a:c]=True
        return mask


class Experiment4Test(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup)
        self.data=HalluFixture(self.tmp.name)
        self.cfg=load_config(ROOT/'configs/public_e4.json')
        self.cfg.update(overview_edge=32,crop_edge=32,resolutions=[32,64,96],bootstrap_repeats=5)
        self.backend=Backend()
        self.backend.response=json.dumps(dict(answer='yes',status='PRESENT',boxes=[],facts=[]))
        self.engine=Engine(self.backend,self.data,self.tmp.name,self.cfg,'e4_cpu_fixture')
        self.sample=self.data.records['factual_original']

    def run_fixture(self):
        Runner(self.engine).run(4,[self.sample])
        return load_records(self.engine.run_dir)

    def test_common_resolution_recovers_small_original_four_cells_without_upsampling(self):
        planned=expected(self.data,self.sample,'test',42,self.cfg)
        facts=[r for r in planned if r['condition']=='fact_baseline']
        self.assertEqual(len(facts),4)
        self.assertEqual({r['extra']['resolution'] for r in facts},{20})
        for world in worlds(self.data,self.sample):
            obs=observation_set(self.data,world,self.cfg)
            self.assertEqual(max(obs['fact_baseline']['views'][0]['input_size']),20)
            for name,item in obs.items():
                if name.startswith('resolution_'):
                    self.assertLessEqual(max(item['views'][0]['input_size']),max(world['image']['width'],world['image']['height']))
        self.assertEqual(len({json.dumps(record_identity(r),sort_keys=True) for r in planned}),len(planned))

    def test_crop_geometry_same_for_both_queries_and_negative_uses_replacement_region(self):
        for a,b in [('factual_original','factual_replacement'),('counterfactual_original','counterfactual_replacement')]:
            left=observation_set(self.data,self.data.records[a],self.cfg)
            right=observation_set(self.data,self.data.records[b],self.cfg)
            for name in ('fact_region','fact_control'):
                self.assertEqual(left[name]['metadata'],right[name]['metadata'])
                self.assertEqual([v['source_box'] for v in left[name]['views']],[v['source_box'] for v in right[name]['views']])
            self.assertEqual(len(right['fact_region']['views']),2)

    def test_expected_missing_rows_failure_identity_and_resume(self):
        rows=self.run_fixture()
        self.assertEqual(len(rows),len(expected(self.data,self.sample,'test',42,self.cfg)))
        path=next(p for p in (self.engine.run_dir/'records').glob('*.json') if read_json(p)['condition']=='fact_baseline')
        path.unlink()
        missing=[r for r in load_records(self.engine.run_dir) if r['status']=='not_run']
        self.assertEqual(len(missing),1)
        self.assertEqual(missing[0]['pair_id'],self.sample['pair_id'])
        self.run_fixture()
        self.assertFalse(any(r['status']=='not_run' for r in load_records(self.engine.run_dir)))
        # An actual inference exception retains the four-cell identity before evaluation.
        self.backend.infer=lambda *a,**k: (_ for _ in ()).throw(RuntimeError('CPU fixture inference failure'))
        request_id=read_json(path)['request_id']
        (self.engine.run_dir/'cache'/(request_id+'.json')).unlink()
        path.unlink()
        self.run_fixture()
        failed=read_json(path)
        self.assertEqual(failed['status'],'error')
        self.assertIn('pair_id',failed);self.assertIn('native_condition',failed)
        output=summarize(self.engine.run_dir,self.cfg)
        fact=read_json(output/'e4_fact_pairs.json')
        self.assertTrue(any(r['left_execution']=='error' or r['right_execution']=='error' for r in fact))

    def test_source_failure_materializes_all_conditions(self):
        self.data.image=lambda s: (_ for _ in ()).throw(OSError('fixture missing image'))
        result=Runner(self.engine).run(4,[self.sample])
        rows=load_records(self.engine.run_dir)
        self.assertEqual(result['source_errors'],1)
        self.assertEqual(len(rows),len(expected(self.data,self.sample,'test',42,self.cfg)))
        self.assertTrue(all(r['status']=='error' and r['pair_id']==self.sample['pair_id'] for r in rows))
        output=summarize(self.engine.run_dir,self.cfg)
        facts=read_json(output/'e4_fact_pairs.json')
        self.assertEqual(len([r for r in facts if r['condition']=='fact_baseline']),4)
        self.assertTrue(all(r['all_attempts']['both_correct'] is False for r in facts))

    def test_strict_output_schema_original_coordinates_and_attention_ties(self):
        views=observation_set(self.data,self.sample,self.cfg)['fact_region']['views']
        payload=dict(answer='yes',status='PRESENT',boxes=[],facts=[])
        variants=[(json.dumps(payload)*2,'eos'),(json.dumps(payload),'length'),
            (json.dumps(dict(payload,boxes=[dict(view=1,bbox=[0,0,1,1])])),'eos')]
        for i,(text,finish) in enumerate(variants):
            self.backend.response=text;self.backend.finish_reason=finish
            result=self.engine.evaluate(self.sample,views,42+i,experiment=4)
            self.assertFalse(result['scores']['format_valid'])
            self.assertIn('coverage_tie_averaged',result['attention'])
            self.assertIn('coverage_tie_averaged',result['attention']['intervention_region'])
            self.assertIsNotNone(metric(dict(result,status='ok'),'attention_coverage10'))
        self.assertEqual(self.backend.schema['properties']['boxes']['items']['properties']['view']['enum'],[0])
        altered=dict(self.sample,reference={'answer':'SECRET'},intervention_regions=['SECRET'])
        self.assertEqual(request(self.sample,views),request(altered,views))

    def test_localization_status_and_false_positive_are_separate(self):
        self.backend.response=json.dumps(dict(answer='',status='UNKNOWN',facts=[],
            boxes=[dict(view=0,bbox=[.375,.4,.625,.8])]))
        result=self.engine.evaluate(self.sample,[view(self.data.image(self.sample),edge=20)],42,experiment=4)
        self.assertTrue(result['scores']['localization_correct'])
        self.assertFalse(result['scores']['status_correct'])
        negative=self.data.records['factual_replacement']
        self.backend.response=json.dumps(dict(answer='yes',status='PRESENT',facts=[],boxes=[]))
        result=self.engine.evaluate(negative,[view(self.data.image(negative),edge=20)],42,experiment=4)
        self.assertFalse(result['scores']['false_positive'])
        self.assertTrue(result['scores']['false_existence_assertion'])

    def test_gpu_format_revision_caps_repeated_boxes_without_reference_count(self):
        views=[view(self.data.image(self.sample),edge=20)]
        schema=request(self.sample,views)['output_schema']
        self.assertEqual(schema['properties']['boxes']['maxItems'],1)
        vista=request(dict(dataset='vistaqa',question='Count the targets.'),views)['output_schema']
        self.assertEqual(vista['properties']['boxes']['maxItems'],64)
        self.assertFalse(self.cfg['model_defaults']['structured_compact_json'])
        box=dict(view=0,bbox=[.375,.4,.625,.8])
        self.backend.response=json.dumps(dict(answer='yes',status='PRESENT',boxes=[box,box],facts=[]))
        result=self.engine.evaluate(self.sample,views,42,experiment=4)
        self.assertFalse(result['scores']['format_valid'])

    def test_missing_and_invalid_pairs_not_conflated_with_valid_behavior(self):
        rows=self.run_fixture()
        a=next(r for r in rows if r['condition']=='fact_baseline')
        b=deepcopy(a);b['status']='not_run'
        self.assertIsNone(pair_metrics(a,b,'valid_outputs')['both_correct'])
        self.assertFalse(pair_metrics(a,b,'all_attempts')['both_correct'])
        b=deepcopy(a);b['scores']['format_valid']=False
        self.assertIsNone(pair_metrics(a,b,'valid_outputs')['same_status'])

    def test_summary_has_four_fact_contrasts_all_resolution_pairs_and_crop_rescue(self):
        self.run_fixture()
        output=summarize(self.engine.run_dir,self.cfg)
        fact=read_json(output/'e4_fact_pairs.json')
        self.assertEqual(len([r for r in fact if r['condition']=='fact_baseline']),4)
        pairs=read_json(output/'e4_paired_changes.json')
        self.assertTrue(any(r['left']=='resolution_64' and r['right']=='resolution_96' for r in pairs))
        self.assertTrue(any(r['left']=='fact_control' and r['right']=='fact_region' for r in pairs))
        self.assertTrue(all('task_type' in r and 'planned_pairs' in r for r in pairs))
        transitions=read_json(output/'e4_transitions.json')
        spatial=[r['attention_spatial_js'] for r in transitions if r['axis']=='resolution']
        self.assertTrue(spatial);self.assertTrue(all(v is not None and abs(v)<1e-10 for v in spatial))

    def test_missing_control_is_explicit_and_does_not_drop_region_rescue(self):
        from unittest.mock import patch
        with patch('experiments.experiment4.matched_control_box',return_value=None):
            rows=self.run_fixture()
        control=[r for r in rows if r['condition']=='fact_control']
        self.assertEqual(len(control),4)
        self.assertTrue(all(r['status']=='skipped' for r in control))
        self.assertTrue(all(r['status']=='ok' for r in rows if r['condition']=='fact_region'))
        output=summarize(self.engine.run_dir,self.cfg)
        changes=[r for r in read_json(output/'e4_paired_changes.json') if r['left']=='fact_control']
        self.assertTrue(changes)
        self.assertTrue(all(r['n']==0 and r['planned_pairs']>0 for r in changes))

    def test_stale_rate_conditions_on_correct_source_and_invalid_is_not_stability(self):
        rows=self.run_fixture()
        a=deepcopy(next(r for r in rows if r['condition']=='fact_baseline'))
        b=deepcopy(a)
        a['scores'].update(status_correct=True,answer_correct=True)
        b['scores'].update(status_correct=False,answer_correct=False)
        result=pair_metrics(a,b,'valid_outputs')
        self.assertTrue(result['stale_given_left_correct'])
        a['scores']['status_correct']=False
        self.assertIsNone(pair_metrics(a,b,'valid_outputs')['stale_given_left_correct'])
        a['scores']['format_valid']=False;b['scores']['format_valid']=False
        self.assertIsNone(pair_metrics(a,b,'valid_outputs')['same_status'])

    def test_task_macro_uses_equal_task_weights_and_keeps_unscored_tasks_missing(self):
        from experiments.experiment4_analysis import task_macro
        result=task_macro([('a','common',1),('b','common',1),('c','rare',0)],20)
        self.assertEqual(result['mean'],.5)
        self.assertEqual(result['task_types'],2)
        missing=task_macro([('a','common',1),('b','rare',None)],20)
        self.assertIsNone(missing['mean'])
        self.assertEqual(missing['scored_task_types'],1)

    @unittest.skipIf(DATA_ROOT is None,'Prepared public data is not installed')
    def test_every_real_hallu_pair_has_four_common_baselines_and_unchanged_pilot(self):
        from experiments.data import ExperimentData
        from experiments.runner import select_samples,interleave_samples
        data=ExperimentData(DATA_ROOT,self.tmp.name)
        cfg=load_config(ROOT/'configs/public_e4.json')
        samples=list(data.primary('test',['hallusegbench']))
        self.assertEqual(len(samples),650)
        for sample in samples:
            planned=expected(data,sample,'test',42,cfg)
            baseline=[r for r in planned if r['condition']=='fact_baseline']
            self.assertEqual(len(baseline),4)
            self.assertEqual(len({r['extra']['resolution'] for r in baseline}),1)
        e1=interleave_samples(select_samples(data,cfg,1,'test',pilot_fraction=.1))
        e4=interleave_samples(select_samples(data,cfg,4,'test',pilot_fraction=.1))
        self.assertEqual([s['sample_id'] for s in e1],[s['sample_id'] for s in e4])
        self.assertEqual(sum(len(expected(data,s,'test',42,cfg)) for s in e4),2176)

    def test_figures_are_generated_from_saved_measurements(self):
        from experiments.experiment4_figures import render_figures
        self.run_fixture();summarize(self.engine.run_dir,self.cfg)
        output=render_figures(self.engine.run_dir,self.data,self.sample['pair_id'])
        manifest=read_json(output/'manifest.json')
        self.assertEqual(manifest['pair_ids'],[self.sample['pair_id']])
        self.assertEqual(len(manifest['figures']),3)
        self.assertTrue(all(Path(p).stat().st_size>0 for p in manifest['figures']))

    def test_gpu_validator_uses_e4_conditions_and_schema(self):
        from experiments.validation import validate_backend
        original=self.backend.infer
        def infer(**kwargs):
            r=original(**kwargs)
            r.update(output_ids=[1],preprocessing={},query_mode='fixture',query_indices=[10])
            r.setdefault('layer_names',['layer0']);r.setdefault('local_layer_names',[])
            return r
        self.backend.infer=infer
        self.backend.prefill_logits=lambda **kwargs:np.array([1.,2.])
        self.backend.decoder=SimpleNamespace(set_attn_implementation=lambda _:None)
        path=validate_backend(self.backend,self.data,[self.sample],self.cfg,Path(self.tmp.name)/'validation',experiment=4)
        report=read_json(path)
        names={r['condition'] for r in report['checks']}
        self.assertIn('fact_baseline',names);self.assertIn('fact_region',names);self.assertIn('resolution_20',names)
        self.assertEqual(report['identity']['experiment'],4)
        self.backend.response='{"answer":"yes","status":"MATCH","boxes":[],"facts":[]}'
        with self.assertRaisesRegex(ValueError,'Experiment 4 protocol preflight failed'):
            validate_backend(self.backend,self.data,[self.sample],self.cfg,Path(self.tmp.name)/'validation',experiment=4)


if __name__=='__main__':
    unittest.main()
