"""E3 scientific contracts and failure accounting, using CPU fixtures only."""
from copy import deepcopy
import json
from pathlib import Path
import tempfile
import unittest
from types import SimpleNamespace
import numpy as np
from test_experiments import FixtureData, FakeBackend, ROOT
from experiments.common import load_config, read_json, write_json, file_hash
from experiments.engine import Engine
from experiments.geometry import view
from experiments.runner import Runner
from experiments.analysis import summarize, load_records
from experiments.experiment3 import request, expected, attention_occlusion, observation_set
from experiments.experiment3_analysis import metric


class Backend(FakeBackend):
    def infer(self, views, *args, output_schema=None, **kwargs):
        self.schema = output_schema
        result = super().infer(views, *args, **kwargs)
        if hasattr(self, 'response'):
            result['text'] = self.response
        if getattr(self, 'zero_attention', False):
            result['layer_weights'] *= 0
        result['finish_reason'] = getattr(self, 'finish_reason', 'eos')
        return result


class Experiment3Test(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.data = FixtureData(self.tmp.name)
        self.cfg = load_config(ROOT/'configs/public_e3.json')
        self.cfg.update(overview_edge=32, crop_edge=32, bootstrap_repeats=5)
        self.backend = Backend()
        self.engine = Engine(self.backend, self.data, self.tmp.name, self.cfg, 'e3_fixture')
        self.sample = self.data.records['I_plus']

    def evaluate(self, sample=None, views=None):
        sample = sample or self.sample
        views = views or [view(self.data.image(sample), edge=32, label='overview')]
        return self.engine.evaluate(sample, views, 42, experiment=3)

    def test_crop_relative_shortcut_rejected_and_geometry_retained(self):
        self.backend.response = json.dumps(dict(answer='2', status='ANSWERED', facts=[],
            boxes=[dict(view=1, bbox=[0,0,1,1])]))
        image = self.data.image(self.sample)
        result = self.evaluate(views=[view(image, edge=32, label='hidden_evidence'),
                                    view(image, [24,24,40,40],32,label='evidence_crop')])
        self.assertFalse(result['scores']['format_valid'])
        self.assertTrue(result['geometry_baseline']['scores']['all_instances_hit'])
        self.assertEqual(result['prediction_contract']['allowed_box_views'], [0])
        self.assertIn('coverage_tie_averaged', result['attention'])

    def test_localization_is_independent_of_answer_status(self):
        sample = deepcopy(self.sample)
        sample['dataset'] = 'groundingme'
        sample['reference'].update(answer_type='grounding_presence', answer='MATCH', region_kind='bbox')
        self.backend.response = json.dumps(dict(answer='',status='UNKNOWN',facts=[],
            boxes=[dict(view=0,bbox=[.375,.375,.625,.625])]))
        result = self.evaluate(sample)
        self.assertTrue(result['scores']['localization_correct'])
        self.assertFalse(result['scores']['answer_correct'])
        self.assertFalse(result['scores']['detection_correct'])

    def test_extra_boxes_fail_strict_localization_but_recall_is_preserved(self):
        self.backend.response = json.dumps(dict(answer='2',status='ANSWERED',facts=[],
            boxes=[dict(view=0,bbox=[.375,.375,.625,.625]),dict(view=0,bbox=[0,0,.1,.1])]))
        scores = self.evaluate()['scores']
        self.assertFalse(scores['localization_correct'])
        self.assertTrue(scores['localization_recall_correct'])

    def test_negative_vista_boxes_have_scoped_false_positive_not_invented_existence_label(self):
        sample = deepcopy(self.sample)
        sample['dataset'] = 'vistaqa'
        sample['reference'].update(regions=[],target_status='no_annotated_target',region_kind='none')
        scores = self.evaluate(sample)['scores']
        self.assertTrue(scores['false_positive'])
        self.assertIsNone(scores['false_existence_assertion'])
        self.assertIsNone(scores['localization_correct'])
        self.assertIsNone(scores['support_available'])

    def test_repeated_and_length_limited_output_are_invalid(self):
        payload = json.dumps(dict(answer='2',status='ANSWERED',boxes=[],facts=[]))
        for response, finish in [(payload+'\n'+payload,'eos'),(payload,'length')]:
            with self.subTest(finish=finish):
                self.backend.response, self.backend.finish_reason = response, finish
                # A separate seed represents a separate inference request.
                self.engine = Engine(self.backend,self.data,self.tmp.name,dict(self.cfg,case=finish),'e3_fixture')
                self.assertFalse(self.evaluate()['scores']['format_valid'])

    def test_schema_is_reference_blind_and_limits_all_boxes_to_original_frame(self):
        a = request(self.sample, [None,None])
        b = request(dict(self.sample,reference={'answer':'SECRET'},image={'path':'SECRET'}),[None,None])
        self.assertEqual(a,b)
        self.assertNotIn('SECRET',str(a))
        self.assertEqual(a['output_schema']['properties']['boxes']['items']['properties']['view']['enum'],[0])
        self.evaluate()
        cached = read_json(next((self.engine.run_dir/'cache').glob('*.json')))
        self.assertIn('output_schema',cached['request'])

    def test_cutoff_ties_exact_area_seeded_and_zero_attention_skips(self):
        heat = np.ones((16,16)); heat[8,8] = 10
        a, info = attention_occlusion(heat,32,42,'test')
        b, _ = attention_occlusion(heat,32,42,'test')
        c, _ = attention_occlusion(heat,32,43,'test')
        np.testing.assert_array_equal(a,b)
        self.assertFalse(np.array_equal(a,c))
        self.assertEqual(int(a.sum()),32)
        self.assertTrue(a[8,8])
        self.assertEqual(info['cutoff_tied_pixels'],255)
        self.assertIsNone(attention_occlusion(np.zeros((4,4)),3,42,'zero')[0])

    def test_grounding_box_budget_is_enforced_after_parsing(self):
        sample = deepcopy(self.sample)
        sample['dataset'] = 'groundingme'
        self.backend.response = json.dumps(dict(answer='target', status='MATCH', facts=[],
            boxes=[dict(view=0, bbox=[.1,.2,.5,.7])]*2))
        self.assertFalse(self.evaluate(sample)['scores']['format_valid'])

    def test_zero_attention_marks_intervention_skipped_not_top_left(self):
        self.backend.zero_attention = True
        Runner(self.engine).run(3,[self.sample])
        rows = load_records(self.engine.run_dir)
        high = [r for r in rows if r['condition']=='hidden_attention']
        self.assertEqual(len(high),2)
        self.assertTrue(all(r['status']=='skipped' for r in high))

    def test_hidden_world_pixels_equal_and_reveal_returns_original_pixels(self):
        a = observation_set(self.data,self.sample,self.cfg)[2]
        b = observation_set(self.data,self.data.records['I_minus'],self.cfg)[2]
        np.testing.assert_array_equal(np.asarray(a['hidden_evidence'][0][0]['image']),
                                      np.asarray(b['hidden_evidence'][0][0]['image']))
        self.assertIsNone(a['hidden_reveal'][1][1])
        Runner(self.engine).run(3,[self.sample])
        check = read_json(next((self.engine.run_dir/'e3_hidden_checks').glob('*.json')))
        self.assertTrue(check['equal'])

    def test_expected_manifest_missing_condition_and_resumption(self):
        runner = Runner(self.engine)
        runner.run(3,[self.sample])
        files = list((self.engine.run_dir/'records').glob('*.json'))
        self.assertEqual(len(files),len(expected(self.data,self.sample,'test',42)))
        victim = next(p for p in files if read_json(p)['condition']=='hidden_reveal')
        victim.unlink()
        self.assertEqual(sum(r['status']=='not_run' for r in load_records(self.engine.run_dir)),1)
        runner.run(3,[self.sample])
        self.assertFalse(any(r['status']=='not_run' for r in load_records(self.engine.run_dir)))

    def test_dependency_skip_is_retried_when_visible_attention_recovers(self):
        runner=Runner(self.engine,retry_errors=True)
        runner.job(3,self.sample,'hidden_attention',[],skip='Visible attention unavailable',metadata={})
        runner.run(3,[self.sample])
        high=next(r for r in load_records(self.engine.run_dir)
                  if r['sample_id']==self.sample['sample_id'] and r['condition']=='hidden_attention')
        self.assertEqual(high['status'],'ok')

    def test_source_failure_accounts_for_all_expanded_worlds(self):
        for key,s in self.data.records.items():
            s['dataset']='hallusegbench'
            s['reference'].update(answer_type='grounding_presence',answer='PRESENT')
        self.data.records['I_minus']['reference'].update(regions=[],target_status='absent',answer='ABSENT')
        original=self.data.image
        def fail(sample):
            if sample['condition']=='I_minus': raise OSError('fixture missing image')
            return original(sample)
        self.data.image=fail
        result=Runner(self.engine).run(3,[self.sample])
        rows=load_records(self.engine.run_dir)
        self.assertEqual(result['source_errors'],1)
        self.assertEqual(result['inference_errors'],6)
        self.assertEqual(len(rows),11)
        self.assertFalse(any(r['status']=='not_run' for r in rows))

    def test_summary_contains_reveal_contrast_and_keeps_missing_denominators(self):
        Runner(self.engine).run(3,[self.sample])
        output=summarize(self.engine.run_dir,self.cfg)
        pairs=read_json(output/'e3_paired_changes.json')
        self.assertTrue(any(r['left']=='hidden_evidence' and r['right']=='hidden_reveal' for r in pairs))
        control=[r for r in pairs if r['left']=='hidden_control' and r['metric']=='answer_correct']
        self.assertTrue(all(r['n']==0 and r['excluded_pairs']==r['planned_pairs'] for r in control))
        joint=read_json(output/'e3_joint_distribution.json')
        self.assertTrue(joint)
        self.assertTrue(all(r['low'] is None for r in joint))  # One source is not a population interval.

    def test_natural_support_metrics_stay_unlabeled_and_correct_negation_is_concrete(self):
        sample=deepcopy(self.sample);sample['dataset']='groundingme'
        sample['reference'].update(answer_type='grounding_presence',answer='NO_MATCH',target_status='no_match',regions=[])
        self.backend.response=json.dumps(dict(answer='no matching target',status='NO_MATCH',boxes=[],facts=[]))
        result=self.evaluate(sample);result['status']='ok'
        self.assertTrue(metric(result,'coverage'))
        self.assertTrue(metric(result,'joint_localization_answer'))
        self.assertFalse(metric(result,'false_positive'))
        self.assertIsNone(metric(result,'vcc'))
        self.assertIsNone(metric(result,'uar'))

    def test_judgments_are_bound_to_record_hash_and_judge_identity(self):
        sample=deepcopy(self.sample);sample['dataset']='vistaqa'
        row=Runner(self.engine).job(3,sample,'visible',[view(self.data.image(sample),edge=32)],metadata={})
        path=next((self.engine.run_dir/'records').glob('*.json'))
        identity={'version':'test_judge'}
        write_json(self.engine.run_dir/'judge.json',identity)
        judgment=dict(status='ok',correct=True,judge_id=identity,input_record_sha256='stale')
        write_json(self.engine.run_dir/'judgments'/path.name,judgment)
        self.assertIsNone(load_records(self.engine.run_dir)[0]['scores']['answer_correct'])
        judgment['input_record_sha256']=file_hash(path)
        write_json(self.engine.run_dir/'judgments'/path.name,judgment)
        self.assertTrue(load_records(self.engine.run_dir)[0]['scores']['answer_correct'])

    def test_gpu_preflight_uses_actual_e3_conditions_and_records_format_failures(self):
        from experiments.validation import validate_backend
        backend=self.backend
        original=backend.infer
        def infer(**kwargs):
            result=original(**kwargs)
            result.update(output_ids=[1],preprocessing={},query_mode='fixture',query_indices=[10])
            # The noncapturing path still needs architecture metadata for the comparison.
            result.setdefault('layer_names',['layer0','layer1']);result.setdefault('local_layer_names',[])
            return result
        backend.infer=infer
        backend.prefill_logits=lambda **kwargs: np.array([1.,2.])
        backend.decoder=SimpleNamespace(set_attn_implementation=lambda _: None)
        output=Path(self.tmp.name)/'validation'
        path=validate_backend(backend,self.data,[self.sample],self.cfg,output,experiment=3)
        report=read_json(path)
        self.assertEqual({r['condition'] for r in report['checks']},
                         {'visible','hidden_evidence','hidden_reveal','hidden_attention'})
        self.assertTrue(all(r['prediction_contract']['allowed_box_views']==[0] for r in report['checks']))
        cases = [('wrong_status','{"answer":"2","status":"MATCH","boxes":[],"facts":[]}', 'eos'),
                 ('zero_width','{"answer":"2","status":"ANSWERED","boxes":[{"view":0,"bbox":[1,0,1,1]}],"facts":[]}', 'eos'),
                 ('truncated','{"answer":', 'length')]
        for name, text, finish in cases:
            with self.subTest(name=name):
                backend.response, backend.finish_reason = text, finish
                destination = output/name
                report = read_json(validate_backend(backend,self.data,[self.sample],self.cfg,destination,experiment=3))
                self.assertTrue(report['measurement_validation_passed'])
                self.assertFalse(report['protocol_validation_passed'])
                self.assertEqual(report['format_errors'], 4)
                self.assertEqual(report['format_error_rate'], 1.)
                self.assertEqual(report['hooked_format_errors'], 4)
                self.assertEqual(len(list((destination/'diagnostics').glob('*.json'))), 12)
                failures = [read_json(p) for p in (destination/'diagnostics').glob('*.json')]
                self.assertEqual({f['mode'] for f in failures}, {'eager_hooked','eager_plain','sdpa_plain'})
                self.assertTrue(all(f['text']==text and not f['blocks_launch'] for f in failures))
                self.assertEqual(len(list((destination/'progress').glob('*.json'))), 4)

        # Output failures must never hide instrumentation errors.
        backend.infer = lambda **kwargs: dict(infer(**kwargs), output_ids=[1] if kwargs['capture'] else [2])
        with self.assertRaisesRegex(ValueError, 'Attention hook changed'):
            validate_backend(backend,self.data,[self.sample],self.cfg,output/'hook_failure',experiment=3)
        backend.infer = lambda **kwargs: dict(infer(**kwargs), layer_weights=np.full((2,4),np.nan))
        with self.assertRaisesRegex(ValueError, 'attention measurement is invalid'):
            validate_backend(backend,self.data,[self.sample],self.cfg,output/'attention_failure',experiment=3)
        def fail_input(**kwargs):
            raise ValueError('Question alignment failure')
        backend.infer = fail_input
        with self.assertRaisesRegex(ValueError, 'Question alignment failure'):
            validate_backend(backend,self.data,[self.sample],self.cfg,output/'input_failure',experiment=3)

    def test_sdpa_invalid_geometry_is_recorded_without_blocking_valid_eager(self):
        from experiments.validation import validate_backend
        backend = self.backend
        original = backend.infer
        backend.attention_mode = 'eager'
        def infer(**kwargs):
            result = original(**kwargs)
            result.update(output_ids=[1], preprocessing={}, query_mode='fixture', query_indices=[10])
            result.setdefault('layer_names', ['layer0','layer1'])
            result.setdefault('local_layer_names', [])
            if backend.attention_mode == 'sdpa':
                result.update(output_ids=[2], text=json.dumps(dict(answer='2',status='ANSWERED',facts=[],
                    boxes=[dict(view=0,bbox=[1.,.1,.37,1.])])))
            return result
        backend.infer = infer
        backend.prefill_logits = lambda **kwargs: np.array([1.,2.])
        backend.decoder = SimpleNamespace(set_attn_implementation=lambda mode: setattr(backend,'attention_mode',mode))
        output = Path(self.tmp.name)/'sdpa_diagnostics'
        report = read_json(validate_backend(backend,self.data,[self.sample],self.cfg,output,experiment=3))
        self.assertTrue(report['hook_validation_passed'])
        self.assertTrue(report['protocol_validation_passed'])
        self.assertEqual(report['sdpa_format_errors'], len(report['checks']))
        self.assertTrue(all(c['sdpa_prediction']['parse_error'] for c in report['checks']))
        self.assertFalse(read_json(next((output/'diagnostics').glob('*.json')))['blocks_launch'])
        self.assertEqual(backend.attention_mode, 'eager')


class GrammarTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        import xgrammar as xgr
        cls.xgr=xgr
        cls.compiler=xgr.GrammarCompiler(xgr.TokenizerInfo([bytes([i]) for i in range(128)]+[b'<eos>'],
                                         stop_token_ids=[128]),max_threads=2)

    def accepts(self, dataset, payload):
        schema=request(dict(dataset=dataset,question='Locate the target.'),[None,None])['output_schema']
        grammar=self.compiler.compile_json_schema(schema,max_whitespace_cnt=2,any_order=False)
        matcher=self.xgr.GrammarMatcher(grammar)
        return matcher.accept_string(json.dumps(payload)) and matcher.is_completed()

    def test_real_grammar_blocks_wrong_task_status_crop_view_and_pixel_coordinates(self):
        from experiments.protocol import allowed_statuses
        for dataset in ('vistaqa','gseval','groundingme','hallusegbench'):
            for status in allowed_statuses(dataset):
                payload=dict(answer='target',status=status,boxes=[dict(view=0,bbox=[.1,.2,.5,.7])],facts=[])
                self.assertTrue(self.accepts(dataset,payload))
                bad=deepcopy(payload);bad['boxes'][0]['view']=1
                self.assertFalse(self.accepts(dataset,bad))
                bad=deepcopy(payload);bad['boxes'][0]['bbox']=[100,200,500,700]
                self.assertFalse(self.accepts(dataset,bad))
        self.assertFalse(self.accepts('vistaqa',dict(answer='yes',status='MATCH',boxes=[],facts=[])))

    def test_generate_masks_adversarial_view_and_terminates_after_one_object(self):
        import torch
        from transformers import GPT2Config,GPT2LMHeadModel,LogitsProcessorList
        from xgrammar.contrib.hf import LogitsProcessor
        target=json.dumps(dict(answer='target',status='MATCH',boxes=[dict(view=0,bbox=[.1,.2,.5,.7])],facts=[]),separators=(',',':'))
        attacks={target.index('MATCH'):ord('P'),target.index('"view":0')+7:ord('1'),len(target):ord('{')}
        class PreferInvalid:
            def __call__(self,ids,scores):
                i=ids.shape[1]-1;scores.fill_(-float('inf'))
                scores[:,ord(target[i]) if i<len(target) else 128]=0
                if i in attacks:scores[:,attacks[i]]=100
                return scores
        model=GPT2LMHeadModel(GPT2Config(vocab_size=129,n_embd=8,n_layer=1,n_head=1,n_positions=256,bos_token_id=42,
                                       eos_token_id=128,pad_token_id=128)).eval()
        schema=request(dict(dataset='gseval',question='Target?'),[None,None])['output_schema']
        grammar=self.compiler.compile_json_schema(schema,any_whitespace=False,separators=(',', ':'),any_order=False)
        for _ in range(2):
            with torch.inference_mode():
                output=model.generate(input_ids=torch.tensor([[42]]),attention_mask=torch.ones(1,1,dtype=torch.long),
                    do_sample=False,max_new_tokens=len(target)+3,logits_processor=LogitsProcessorList([PreferInvalid(),LogitsProcessor(grammar)]))
            self.assertEqual(output[0,-1].item(),128)
            self.assertEqual(''.join(chr(i) for i in output[0,1:-1]),target)

    def test_real_grammar_caps_boxes_without_reference_count(self):
        box = dict(view=0, bbox=[.1,.2,.5,.7])
        for dataset in ('gseval', 'groundingme', 'hallusegbench'):
            status = 'PRESENT' if dataset == 'hallusegbench' else 'MATCH'
            self.assertTrue(self.accepts(dataset, dict(answer='', status=status, boxes=[box], facts=[])))
            self.assertFalse(self.accepts(dataset, dict(answer='', status=status, boxes=[box]*2, facts=[])))
        self.assertTrue(self.accepts('vistaqa', dict(answer='64', status='ANSWERED', boxes=[box]*64, facts=[])))
        self.assertFalse(self.accepts('vistaqa', dict(answer='65', status='ANSWERED', boxes=[box]*65, facts=[])))


if __name__ == '__main__':
    unittest.main()
