"""CPU-only regression checks for data reuse, test-only selection and public pilot."""
from pathlib import Path
import json
import tempfile
import unittest
from unittest.mock import patch, Mock
from types import SimpleNamespace
from experiments.data_source import resolve_data_root, fetch_data, validate_data_root, SOURCE_CONFIG
from experiments.common import read_json, load_config
from experiments.data import ExperimentData, prepare_audit
from experiments.__main__ import parser
from experiments.runner import select_samples

ROOT = Path(__file__).resolve().parents[1]
try:
    DATA_ROOT = resolve_data_root()
except FileNotFoundError:
    DATA_ROOT = None


class DataSourceTest(unittest.TestCase):
    @unittest.skipIf(DATA_ROOT is None, 'Prepared public dataset is not installed')
    def test_pinned_snapshot_has_full_test_and_complete_pairs(self):
        result = validate_data_root(DATA_ROOT, require_snapshot=True, check_assets=True)
        self.assertTrue(result['matches_pinned_snapshot'])
        self.assertEqual(result['asset_paths'],5559)
        for name, count in read_json(SOURCE_CONFIG)['test_units'].items():
            self.assertEqual(result['datasets'][name]['test_units'],count)
            self.assertEqual(result['datasets'][name]['development_units'],0)
        self.assertEqual(result['datasets']['hallusegbench']['records'],2600)

    @unittest.skipIf(DATA_ROOT is None, 'Prepared public dataset is not installed')
    def test_fetch_reuses_local_data_without_loading_hub(self):
        with patch('experiments.data_source.resolve_data_root',return_value=DATA_ROOT):
            result=fetch_data()
        self.assertFalse(result['downloaded'])
        self.assertEqual(result['revision'],read_json(SOURCE_CONFIG)['revision'])

    def test_first_fetch_uses_pinned_revision_and_regular_local_directory(self):
        with tempfile.TemporaryDirectory() as tmp:
            project=Path(tmp)/'code';(project/'configs').mkdir(parents=True)
            (project/'configs/data_source.json').write_bytes(SOURCE_CONFIG.read_bytes())
            destination=Path(tmp)/'shared_data';download=Mock()
            checked=dict(root=str(destination/'prepared_data'),matches_pinned_snapshot=True)
            with patch.dict('sys.modules',{'huggingface_hub':SimpleNamespace(snapshot_download=download)}), \
                 patch('experiments.data_source.validate_data_root',return_value=checked):
                result=fetch_data(destination,project_root=project)
            kwargs=download.call_args.kwargs
            self.assertEqual(kwargs['revision'],read_json(SOURCE_CONFIG)['revision'])
            self.assertEqual(kwargs['repo_type'],'dataset')
            self.assertEqual(kwargs['local_dir'],str(destination.resolve()))
            self.assertIn('prepared_data/**',kwargs['allow_patterns'])
            self.assertTrue(result['downloaded'])
            self.assertEqual(read_json(project/'data/location.json')['root'],checked['root'])

    @unittest.skipIf(DATA_ROOT is None, 'Prepared public dataset is not installed')
    def test_synthetic_catalog_is_ignored_until_explicitly_enabled(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp)/'synthetic';root.mkdir()
            # A minimal existing catalog is sufficient to check accidental opt-in.
            record=dict(sample_id='synthetic/test/I_plus',source_group_id='synthetic/test',dataset='synthetic',
                condition='I_plus',is_primary=True,analysis_split='test',reference=dict(global_ambiguous=False))
            (root/'catalog.jsonl').write_text(json.dumps(record)+'\n')
            public=ExperimentData(DATA_ROOT,tmp)
            self.assertEqual(public.synthetic,{})
            self.assertTrue(all(s['dataset']!='synthetic' for s in public.primary()))
            later=ExperimentData(DATA_ROOT,tmp,include_synthetic=True)
            self.assertEqual(set(later.synthetic),{record['sample_id']})
            self.assertNotEqual(public.fingerprint(),later.fingerprint())
            audit=prepare_audit(public,load_config(ROOT/'configs/experiments.json'),'test')
            self.assertEqual(audit['synthetic_sample_ids'],[])

    @unittest.skipIf(DATA_ROOT is None, 'Prepared public dataset is not installed')
    def test_pilot_and_shards_only_limit_execution(self):
        with tempfile.TemporaryDirectory() as tmp:
            data=ExperimentData(DATA_ROOT,tmp);config=load_config(ROOT/'configs/experiments.json')
            prepare_audit(data,config,'test')
            for experiment in [1,2,3,4]:
                full=select_samples(data,config,experiment,'test',['vistaqa'])
                limited=select_samples(data,config,experiment,'test',['vistaqa'],limit=5)
                shards=[select_samples(data,config,experiment,'test',['vistaqa'],limit=5,shard_index=i,shards=3) for i in range(3)]
                self.assertEqual({r['sample_id'] for r in limited},{r['sample_id'] for s in shards for r in s})
                self.assertEqual(sum(map(len,shards)),len(limited))
                self.assertTrue({r['sample_id'] for r in limited}<={r['sample_id'] for r in full})
                self.assertTrue(all(r['dataset']!='synthetic' for r in full))

    def test_cli_defaults_are_public_and_test_only(self):
        for command in [['prepare'],['plan','--experiment','1'],['run','--experiment','2','--model','qwen35_9b'],['propose'],['smoke','--model','qwen35_9b']]:
            args=parser().parse_args(command)
            self.assertFalse(getattr(args,'include_synthetic',False))
            self.assertEqual(getattr(args,'subset','test'),'test')


if __name__ == '__main__':unittest.main()
