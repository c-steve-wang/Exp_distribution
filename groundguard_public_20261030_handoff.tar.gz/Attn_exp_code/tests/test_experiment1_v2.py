"""Regressions for query alignment, output eligibility and mechanism estimands."""
import json
from pathlib import Path
import tempfile
import unittest
import numpy as np
from experiments.backends import aligned_question_indices, question_indices
from experiments.common import load_config, read_json, write_json
from experiments.engine import Engine
from experiments.metrics import score_prediction
from experiments.protocol import parse_prediction, task_prompt, SYSTEM
from experiments.runner import Runner
from experiments.analysis import summarize
from test_experiments import FakeBackend, FixtureData

ROOT = Path(__file__).resolve().parents[1]
SNAPSHOT = ROOT/'.cache/huggingface/hub/models--Qwen--Qwen3.5-9B/snapshots/c202236235762e1c871ad0ccb60c8ee5ba337b9a'


class StrictOutputTest(unittest.TestCase):
    def setUp(self):
        self.text = json.dumps(dict(answer='yes', status='PRESENT', boxes=[dict(view=0,bbox=[0,0,1,1])],facts=[]))

    def test_repetition_and_truncation_do_not_salvage_an_earlier_json(self):
        for text, finish in [(self.text+'\n'+self.text,'eos'), (self.text+'\n{"answer":','eos'), (self.text,'length')]:
            self.assertIsNotNone(parse_prediction(text,1,strict=True,finish_reason=finish)['parse_error'])
        self.assertIsNone(parse_prediction(self.text,1,strict=True,finish_reason='eos')['parse_error'])

    def test_task_status_is_explicit_without_rewriting_question(self):
        question='among the suitcases, which is largest? '
        p=task_prompt(dict(dataset='hallusegbench',question=question),strict=True)
        self.assertIn('ABSENT|PRESENT|UNKNOWN',p)
        self.assertIn('Question:\n'+question+'\nOutput requirements:',p)

    def test_valid_grounding_joint_metric_and_invalid_recall_have_consistent_denominators(self):
        s=dict(dataset='hallusegbench',reference=dict(answer='PRESENT',answer_type='grounding_presence',target_status='present',region_kind='mask'))
        pred=parse_prediction(self.text,1,strict=True,finish_reason='eos')
        good=score_prediction(pred,s,[[0,0,1,1]],[[0,0,1,1]])
        self.assertTrue(good['joint_answer_detection'])
        bad=score_prediction(dict(parse_error='truncated',status=None),s,[],[[0,0,1,1]])
        self.assertEqual(bad['recall'],0.)
        self.assertFalse(bad['all_instances_hit'])
        unknown=score_prediction(dict(parse_error=None,status='UNKNOWN',answer=''),s,[],[[0,0,1,1]])
        self.assertTrue(unknown['format_valid'])
        self.assertFalse(unknown['detection_correct'])


@unittest.skipUnless(SNAPSHOT.exists(),'Pinned local 9B tokenizer is not installed')
class QueryAlignmentTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        from transformers import AutoTokenizer
        cls.tokenizer=AutoTokenizer.from_pretrained(SNAPSHOT,local_files_only=True)

    def inputs(self, question):
        t=self.tokenizer
        prompt=task_prompt(dict(dataset='vistaqa',question=question),strict=True)
        text=t.apply_chat_template([dict(role='system',content=SYSTEM),dict(role='user',content=[dict(type='image'),dict(type='text',text=prompt)])],tokenize=False,add_generation_prompt=True,enable_thinking=False)
        ids=t.encode(text,add_special_tokens=False)
        visual=[i for i,k in enumerate(ids) if k==t.convert_tokens_to_ids('<|image_pad|>')]
        return ids,visual

    def test_actual_failed_question_uses_verified_context_offsets(self):
        q='among the suitcases of the people standing in the line, which one is the largest? '
        ids,visual=self.inputs(q)
        with self.assertRaises(ValueError):
            question_indices(ids,self.tokenizer.encode(q,add_special_tokens=False),visual)
        indices,mode=aligned_question_indices(self.tokenizer,ids,q,visual)
        self.assertIn('verified_offsets',mode)
        self.assertEqual(self.tokenizer.decode([ids[i] for i in indices]).strip(),q.strip())
        self.assertGreater(min(indices),max(visual))

    def test_existing_exact_queries_are_unchanged_and_missing_question_is_rejected(self):
        q='What color is the suitcase?'
        ids,visual=self.inputs(q)
        self.assertEqual(aligned_question_indices(self.tokenizer,ids,q,visual),question_indices(ids,self.tokenizer.encode(q,add_special_tokens=False),visual))
        with self.assertRaises(ValueError):
            aligned_question_indices(self.tokenizer,ids,'This question is absent.',visual)


class MechanismSummaryTest(unittest.TestCase):
    def test_invalid_output_is_excluded_from_behavior_but_not_attention_and_pairs(self):
        with tempfile.TemporaryDirectory() as tmp:
            data=FixtureData(tmp)
            cfg=load_config(ROOT/'configs/experiments.json')
            cfg.update(overview_edge=32,crop_edge=32,bootstrap_repeats=10,
                       experiment1_measurement=dict(output_policy='strict_single_json_v2'))
            engine=Engine(FakeBackend(),data,tmp,cfg,'fixture_v2')
            Runner(engine).run(1,[data.records['I_plus']])
            for p in (engine.run_dir/'records').glob('*.json'):
                r=read_json(p)
                if r['condition']=='overview_control':
                    r['prediction']['parse_error']='Multiple final JSON objects; repeated generation'
                    r['scores'].update(format_valid=False,detection_correct=False)
                    write_json(p,r)
            out=summarize(engine.run_dir,cfg)
            primary=next(r for r in read_json(out/'e1_valid_metrics.json') if r['condition']=='overview_control' and r['stratum']=='all' and r['metric']=='detection_correct')
            self.assertEqual(primary['n'],0)
            self.assertIsNone(primary['mean'])
            attn=next(r for r in read_json(out/'e1_attention_alignment.json') if r['condition']=='overview_control' and r['stratum']=='all' and r['metric']=='enrichment')
            self.assertEqual(attn['n'],1)
            pair=next(r for r in read_json(out/'e1_paired_valid_changes.json') if r['baseline']=='overview_control' and r['metric']=='detection_correct')
            self.assertEqual((pair['n'],pair['excluded_pairs']),(0,1))
            self.assertTrue((out/'e1_report.html').exists())
            self.assertTrue((out/'e1_detection.png').exists())


if __name__=='__main__':
    unittest.main()
