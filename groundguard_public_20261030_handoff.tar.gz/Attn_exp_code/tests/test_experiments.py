"""Small CPU contract tests. FakeBackend is a fixture, never an experimental model."""
from copy import deepcopy
from pathlib import Path
import json
import tempfile
import unittest
from unittest.mock import patch
import numpy as np
from PIL import Image
from experiments.common import load_config, read_json, write_json, rng_for, shard_contains
from experiments.geometry import view, grid_boxes, full_box, matched_control, top_area_mask
from experiments.metrics import project_mass, attention_metrics, box_matches, score_prediction, rank_correlation
from experiments.backends import gemma_token_boxes, question_indices
from experiments.protocol import parse_prediction, FACT_SYSTEM, PROPOSAL_SYSTEM
from experiments.candidates import build_candidates, coverage
from experiments.engine import Engine, synthetic_support
from experiments.runner import Runner, generate_proposals, policy_order, select_samples
from experiments.analysis import summarize, interval, load_records
from experiments.synthetic import generate
from experiments.data import ExperimentData, prepare_audit
from experiments.data_source import resolve_data_root

ROOT = Path(__file__).resolve().parents[1]
try:
    DATA_ROOT = resolve_data_root()
except FileNotFoundError:
    DATA_ROOT = None


class FixtureData:
    def __init__(self, root):
        self.work_root = Path(root)
        self.mask = np.zeros((64,64), dtype=bool)
        self.mask[24:40,24:40] = True
        self.support = np.zeros_like(self.mask)
        self.support[20:44,20:44] = True
        self.records = {}
        for condition, answer in [('I_plus','2'),('I_minus','3'),('I_zero','2')]:
            sid = 'synthetic/counting/0000/' + condition
            self.records[condition] = dict(sample_id=sid, dataset='synthetic', task_type='counting', domain='controlled',
                source_group_id='synthetic/counting/0000', pair_id='synthetic/counting/0000', condition=condition,
                is_primary=condition=='I_plus', official_split='generated', question='How many symbols?',
                image=dict(width=64,height=64,path=condition+'.png'),
                reference=dict(answer=answer, answer_type='text', region_kind='mask', target_status='present', global_ambiguous=False,
                    facts=['count='+answer], regions=[dict(bbox_xyxy=[24,24,40,40],area=256,mask={})]))
    def image(self, sample):
        image = Image.new('RGB',(64,64),'white')
        color = (10,20,30) if sample['condition'] != 'I_minus' else (30,20,10)
        image.paste(color,(24,24,40,40))
        return image
    def region_mask(self,sample,region_index=None): return self.mask.copy()
    def support_mask(self,sample): return self.support.copy()
    def fingerprint(self): return 'cpu-fixture'
    def pair(self,sample): return self.records
    def get(self,sid): return next(s for s in self.records.values() if s['sample_id']==sid)


class FakeBackend:
    def __init__(self):
        self.spec = dict(generation=dict(do_sample=False))
        self.lock = dict(repo_id='unit-test-fixture',revision='0'*40)
        self.calls = 0
    def metadata(self): return dict(backend='unit-test-only',spec=self.spec,lock=self.lock)
    def infer(self,views,prompt,question,system,seed,capture=True):
        self.calls += 1
        if system == FACT_SYSTEM:
            text=json.dumps(dict(facts=['count=2']))
        elif system == PROPOSAL_SYSTEM or 'propose exactly 8 distinct regions' in system:
            text=json.dumps(dict(regions=[[.2,.2,.8,.8]]))
        else:
            text=json.dumps(dict(answer='2',status='ANSWERED',boxes=[dict(view=0,bbox=[.375,.375,.625,.625])],facts=[]))
        boxes = [b for i,v in enumerate(views) for b in grid_boxes(2,2,v['source_box'],i)]
        result=dict(text=text, token_boxes=boxes, input_tokens=20,output_tokens=5,spatial_visual_tokens=len(boxes),
                    input_seconds=0.,inference_seconds=0.,peak_allocated_bytes=[0])
        if capture:
            result.update(layer_weights=np.full((2,len(boxes)),.5/len(boxes)),local_layer_weights=np.empty((0,len(boxes))),
                          layer_names=['layer0','layer1'],local_layer_names=[])
        return result


class GeometryTest(unittest.TestCase):
    def test_mass_conservation_with_overlap_and_subpixel_cells(self):
        boxes=grid_boxes(4,4,[0,0,2,2])+grid_boxes(2,2,[0,0,2,2],1)
        weights=np.arange(1,len(boxes)+1,dtype=float)
        self.assertAlmostEqual(project_mass(weights,boxes,(2,2)).sum(),weights.sum())

    def test_enrichment_uses_footprint_area_and_multiview_projection(self):
        mask=np.zeros((8,8),bool); mask[:4,:4]=True
        boxes=grid_boxes(2,2,[0,0,8,8])+grid_boxes(2,2,[0,0,4,4],1)
        metrics,_=attention_metrics(np.ones((2,8))*.01,boxes,mask,(8,8))
        self.assertAlmostEqual(metrics['uniform_evidence_mass'],.4)
        self.assertAlmostEqual(metrics['enrichment'],(5/8)/.4)

    def test_measured_zero_mass_is_not_a_missing_attention_error(self):
        metrics,heat=attention_metrics(np.zeros((2,4)),grid_boxes(2,2,[0,0,8,8]),np.ones((8,8),bool),(8,8))
        self.assertEqual(metrics['spatial_visual_mass'],0.)
        self.assertFalse(metrics['within_visual_normalization_defined']);self.assertEqual(heat.sum(),0.)

    def test_controls_and_stable_topk(self):
        mask=np.zeros((32,32),bool);mask[10:16,10:16]=True
        control=matched_control(mask,rng_for(42,'x'),max_overlap=0)
        self.assertEqual(control.sum(),mask.sum());self.assertFalse((control&mask).any())
        top=top_area_mask(np.ones((4,4)),2)
        self.assertTrue(top[0,0] and top[0,1]);self.assertEqual(top.sum(),2)

    def test_gemma_padding_and_pooling_order(self):
        positions=[(x,y) for y in range(6) for x in range(9)]+[(-1,-1)]*9
        boxes,grids=gemma_token_boxes([positions],3,[dict(source_box=[0,0,90,60])])
        self.assertEqual(grids,[[2,3]]);self.assertEqual(boxes[4]['bbox'],[30.,30.,60.,60.])
        with self.assertRaises(ValueError):gemma_token_boxes([positions[::-1]],3,[dict(source_box=[0,0,90,60])])

    def test_question_query_causal_order(self):
        self.assertEqual(question_indices([9,9,5,6,7],[5,6],[0,1]),([2,3],'question_tokens_after_images'))
        self.assertEqual(question_indices([5,6,9,9,7],[5,6],[2,3])[0],[4])
        with self.assertRaises(ValueError):question_indices([9,5,6],[1,2],[0])

    def test_bipartite_matching_not_greedy(self):
        # First prediction can match either target; second matches only target zero.
        match=box_matches([[1,0,11,10],[0,0,10,10]],[[0,0,10,10],[3,0,13,10]],threshold=.6)
        self.assertEqual(match['matches'],2)

    def test_rank_ties_and_constant_pool(self):
        self.assertEqual(rank_correlation([1,2,3],[2,4,6]),1.)
        self.assertIsNone(rank_correlation([1,2],[0,0]))

    def test_candidates_are_unique_nested_and_deterministic(self):
        image=Image.new('RGB',(128,96),'white')
        candidates=build_candidates(image,[[32,24,64,48]]*8)
        self.assertEqual(len(candidates),32)
        self.assertEqual(len({tuple(c['bbox']) for c in candidates}),32)
        self.assertEqual(candidates,build_candidates(image,[[32,24,64,48]]*8))
        for k in [8,16,32]:
            self.assertEqual(policy_order('attention',candidates[:k],[1]*k,42,'x'),list(range(k)))


class ProtocolTest(unittest.TestCase):
    def test_final_json_and_bad_coordinate(self):
        text='<think>{"bad":1}</think>'+json.dumps(dict(answer='2',status='ANSWERED',boxes=[],facts=[]))
        self.assertIsNone(parse_prediction(text,1)['parse_error'])
        bad=json.dumps(dict(answer='2',status='ANSWERED',boxes=[dict(view=0,bbox=[0,0,2,1])]))
        self.assertIsNotNone(parse_prediction(bad,1)['parse_error'])

    def test_current_support_differs_from_world_truth(self):
        sample=FixtureData('.').records['I_plus']
        p=dict(answer='2',status='ANSWERED',parse_error=None)
        score=score_prediction(p,sample,[[24,24,40,40]],[[24,24,40,40]],support_available=False)
        self.assertTrue(score['answer_correct']);self.assertFalse(score['task_correct'])
        self.assertTrue(score['unsupported_concrete_answer']);self.assertFalse(score['evidence_match'])
        p.update(answer='UNKNOWN',status='UNKNOWN')
        score=score_prediction(p,sample,[],[[24,24,40,40]],support_available=False)
        self.assertTrue(score['task_correct']);self.assertFalse(score['concrete_answer'])

    def test_negative_requires_correct_status_and_empty_boxes(self):
        sample=dict(dataset='groundingme',reference=dict(answer='NO_MATCH',answer_type='grounding_presence',region_kind='none',target_status='no_match'))
        p=dict(status='UNKNOWN',answer='',parse_error=None)
        self.assertFalse(score_prediction(p,sample,[],[])['task_correct'])
        p['status']='NO_MATCH'
        self.assertTrue(score_prediction(p,sample,[],[])['task_correct'])
        self.assertFalse(score_prediction(p,sample,[[0,0,1,1]],[])['task_correct'])

    def test_format_failure_is_counted_not_dropped(self):
        sample=FixtureData('.').records['I_plus']
        score=score_prediction(dict(parse_error='bad json',status=None),sample,[],[],support_available=True)
        self.assertFalse(score['task_correct']);self.assertFalse(score['answer_correct'])
        self.assertFalse(score['supported_concrete_answer']);self.assertEqual(score['utility_w'],-1)

    def test_seeded_shards_partition_sources(self):
        for source in ['a','b','c']:
            self.assertEqual(sum(shard_contains(source,i,4) for i in range(4)),1)

    def test_bootstrap_keeps_cluster_weighting(self):
        result=interval([('a',0),('a',0),('b',1)],repeats=50)
        self.assertAlmostEqual(result['mean'],1/3);self.assertEqual(result['source_groups'],2)


class WorkflowTest(unittest.TestCase):
    @unittest.skipIf(DATA_ROOT is None, 'Prepared public dataset is not installed')
    def test_prepare_defaults_to_four_public_datasets(self):
        from experiments.__main__ import main
        with tempfile.TemporaryDirectory() as tmp:
            argv = ['experiments', '--config', str(ROOT/'configs/experiments.json'),
                    '--data-root', str(DATA_ROOT), '--work-root', tmp, 'prepare']
            with patch('sys.argv', argv):
                main()
            self.assertFalse((Path(tmp)/'synthetic').exists())
            self.assertFalse((Path(tmp)/'smoke_60.json').exists())
            audit = read_json(Path(tmp)/'audit_test.json')
            self.assertEqual(len(audit['sample_ids']), 500)
            self.assertEqual(audit['synthetic_sample_ids'], [])
            (Path(tmp)/'synthetic').mkdir()
            (Path(tmp)/'synthetic/catalog.jsonl').touch()
            with patch('sys.argv', argv), self.assertRaisesRegex(ValueError, 'contains synthetic'):
                main()

    @unittest.skipIf(DATA_ROOT is None, 'Prepared public dataset is not installed')
    def test_real_dataset_records_use_common_attention_scoring(self):
        with tempfile.TemporaryDirectory() as tmp:
            data=ExperimentData(DATA_ROOT,tmp)
            cfg=load_config(ROOT/'configs/experiments.json')
            engine=Engine(FakeBackend(),data,tmp,cfg,'dataset_contract_fixture')
            for name in ['vistaqa','gseval','groundingme','hallusegbench']:
                sample=min((s for s in data.primary('test',[name]) if s['reference']['regions']),
                           key=lambda s:s['image']['width']*s['image']['height'])
                result=engine.evaluate(sample,[view(data.image(sample),edge=32)],42)
                self.assertTrue(result['attention']['annotation_available'])
                if name=='hallusegbench':
                    negative=data.pair(sample)['counterfactual_original']
                    result=engine.evaluate(negative,[view(data.image(negative),edge=32)],42)
                    self.assertFalse(result['attention']['annotation_available'])
                    self.assertIsNotNone(result['attention']['intervention_region']['region_mass'])

    def test_four_experiments_cache_resume_and_summary(self):
        with tempfile.TemporaryDirectory() as tmp:
            data=FixtureData(tmp);backend=FakeBackend();cfg=load_config(ROOT/'configs/experiments.json')
            cfg.update(overview_edge=32,crop_edge=32,resolutions=[32,48,64],bootstrap_repeats=5)
            engine=Engine(backend,data,tmp,cfg,'unit_test_fixture');runner=Runner(engine,'test')
            sample=data.records['I_plus']
            generate_proposals(engine,[sample],'test')
            for experiment in [1,2,3,4]:runner.run(experiment,[sample])
            self.assertFalse(list((engine.run_dir/'source_errors').glob('*.json')))
            records=load_records(engine.run_dir)
            self.assertTrue(records);self.assertFalse(any(r['status']=='error' for r in records))
            calls=backend.calls
            for experiment in [1,2,3,4]:runner.run(experiment,[sample])
            self.assertEqual(backend.calls,calls)
            output=summarize(engine.run_dir,cfg)
            self.assertEqual(read_json(output/'completeness.json')['inference_errors'],0)
            audit=read_json(output/'action_audits.json')
            self.assertTrue(all(a['proposal_gap']==0 for a in audit if a['k']==32 and a['audit_complete']))
            self.assertTrue(any(r['condition']=='resolution_64' for r in records))
            self.assertTrue(any(r['experiment']==4 for r in read_json(output/'paired_changes.json')))
            hidden=next(r for r in records if r['condition']=='hidden_evidence' and r['native_condition']=='I_plus')
            with np.load(engine.run_dir/hidden['views'][0]['occlusion_mask']) as file:
                np.testing.assert_array_equal(file['mask'],data.support)

    def test_stochastic_actions_use_common_and_independent_seeds(self):
        with tempfile.TemporaryDirectory() as tmp:
            data=FixtureData(tmp);backend=FakeBackend();backend.spec['generation']['do_sample']=True
            cfg=load_config(ROOT/'configs/experiments.json')
            cfg.update(overview_edge=32,crop_edge=32,bootstrap_repeats=3)
            engine=Engine(backend,data,tmp,cfg,'stochastic_test_fixture');runner=Runner(engine,'test')
            sample=data.records['I_plus'];generate_proposals(engine,[sample],'test');runner.run(2,[sample])
            records=load_records(engine.run_dir)
            self.assertEqual({r['seed'] for r in records if r['extra'].get('stage')=='candidate'},set(range(42,47)))
            self.assertEqual({r['seed'] for r in records if r['extra'].get('stage')=='confirmation'},set(range(142,147)))
            output=summarize(engine.run_dir,cfg)
            audits=read_json(output/'action_audits.json')
            self.assertTrue(audits)
            self.assertTrue(all(r['confirmation_replicates']==5 for r in audits))

    def test_synthetic_hidden_worlds_and_source_family_splits(self):
        with tempfile.TemporaryDirectory() as tmp:
            generate(tmp,per_task=5)
            root=Path(tmp)
            rows=[json.loads(s) for s in (root/'catalog.jsonl').read_text().splitlines()]
            self.assertEqual(len({r['source_group_id'] for r in rows}),15)
            self.assertEqual({r['analysis_split'] for r in rows}, {'test'})
            for family in {r['source_group_id'] for r in rows}:
                variants={r['condition']:r for r in rows if r['source_group_id']==family}
                self.assertEqual(len({r['analysis_split'] for r in variants.values()}),1)
                if 'I_plus' in variants:
                    arrays={k:np.asarray(Image.open(root/r['image']['path'])) for k,r in variants.items()}
                    support=np.asarray(Image.open(root/variants['I_plus']['support_mask']))>0
                    np.testing.assert_array_equal(arrays['I_plus'][~support],arrays['I_minus'][~support])
                    np.testing.assert_array_equal(arrays['I_plus'][support],arrays['I_zero'][support])

    @unittest.skipIf(DATA_ROOT is None, 'Prepared public dataset is not installed')
    def test_public_audit_quotas_and_trial_is_part_of_full_run(self):
        with tempfile.TemporaryDirectory() as tmp:
            data=ExperimentData(DATA_ROOT,tmp);cfg=load_config(ROOT/'configs/experiments.json')
            audit=prepare_audit(data,cfg,'test')
            self.assertEqual(len(audit['sample_ids']),500)
            sources={data.get(s)['source_group_id'] for s in audit['sample_ids']}
            self.assertEqual(len(sources),500)
            self.assertFalse(sources & {s['source_group_id'] for s in data.primary('development')})
            self.assertEqual(audit,prepare_audit(data,cfg,'test'))
            for experiment in [1, 2, 3, 4]:
                for name in ['vistaqa', 'gseval', 'groundingme', 'hallusegbench']:
                    full = select_samples(data,cfg,experiment,'test',[name])
                    trial = select_samples(data,cfg,experiment,'test',[name],limit=2)
                    self.assertTrue(trial)
                    self.assertEqual(len({s['source_group_id'] for s in trial}), 2)
                    self.assertTrue({s['sample_id'] for s in trial} <= {s['sample_id'] for s in full})
                    self.assertEqual(full,select_samples(data,cfg,experiment,'test',[name]))


if __name__ == '__main__':unittest.main()
