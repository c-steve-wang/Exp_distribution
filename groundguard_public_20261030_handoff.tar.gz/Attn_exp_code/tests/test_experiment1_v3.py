"""E1 measurement regressions: coordinates, tie handling, and uncertainty."""
from pathlib import Path
import json
import tempfile
import unittest
import numpy as np
from experiments.common import load_config, read_json
from experiments.engine import Engine
from experiments.runner import Runner
from experiments.geometry import view, grid_boxes, top_area_mask
from experiments.metrics import attention_metrics, fractional_top_coverage
from experiments.protocol import prediction_contract, task_prompt, parse_prediction
from experiments.attention_association import ranks, partial_rank, association
from experiments.analysis import summarize
from test_experiments import FixtureData, FakeBackend

ROOT = Path(__file__).resolve().parents[1]


class CropBoxBackend(FakeBackend):
    def infer(self, views, *args, **kwargs):
        result = super().infer(views, *args, **kwargs)
        result['text'] = json.dumps(dict(answer='2', status='ANSWERED', facts=[],
            boxes=[dict(view=len(views)-1, bbox=[0.,0.,1.,1.])]))
        return result


class LocalizationContractTest(unittest.TestCase):
    def test_dual_view_crop_box_rejected_but_geometry_diagnostic_retained(self):
        with tempfile.TemporaryDirectory() as tmp:
            data=FixtureData(tmp);sample=data.records['I_plus']
            cfg=load_config(ROOT/'configs/public_e1.json')
            engine=Engine(CropBoxBackend(),data,tmp,cfg,'fixture_v3')
            image=data.image(sample)
            views=[view(image,edge=32,label='overview'),view(image,[24,24,40,40],32,label='evidence_crop')]
            result=engine.evaluate(sample,views,42,experiment=1)
            self.assertFalse(result['scores']['format_valid'])
            self.assertIn('Forbidden box view',result['prediction']['parse_error'])
            self.assertEqual(result['predicted_boxes'],[])
            self.assertTrue(result['geometry_baseline']['scores']['all_instances_hit'])
            self.assertEqual(result['prediction_contract']['allowed_box_views'],[0])
            cached=read_json(engine.run_dir/'cache'/(result['request_id']+'.json'))
            self.assertIn('"view": 1',cached['text'])
            self.assertIn('All boxes MUST use view 0',cached['request']['prompt'])
            # The E1 config must not impose its coordinate contract on E3.
            other=engine.evaluate(sample,views,42,experiment=3)
            self.assertTrue(other['scores']['format_valid'])
            self.assertEqual(other['predicted_boxes'],[[24.,24.,40.,40.]])
            self.assertIsNone(other['geometry_baseline'])
            single=engine.evaluate(sample,[views[1]],42,experiment=1)
            self.assertTrue(single['scores']['format_valid'])
            self.assertEqual(single['prediction_contract']['localization_frame'],'crop_diagnostic')

    def test_overview_and_multiview_prompts_preserve_question_and_coordinate_system(self):
        cfg=load_config(ROOT/'configs/public_e1.json')
        sample=dict(dataset='vistaqa',question='What is behind the person? ')
        a=prediction_contract(cfg,[dict(label='overview')],1)
        b=prediction_contract(cfg,[dict(label='overview'),dict(label='control_crop')],1)
        pa=task_prompt(sample,strict=a['strict'],localization_frame=a['localization_frame'])
        pb=task_prompt(sample,strict=b['strict'],localization_frame=b['localization_frame'])
        self.assertEqual(pa,pb)
        self.assertIn('Question:\n'+sample['question']+'\nOutput requirements:',pa)
        with self.assertRaisesRegex(ValueError,'must start with the overview'):
            prediction_contract(cfg,[dict(label='crop'),dict(label='overview')],1)


class AttentionTieTest(unittest.TestCase):
    def test_uniform_attention_does_not_favor_top_left_target(self):
        heat=np.ones((10,10));first=np.zeros_like(heat,dtype=bool);last=first.copy()
        first[0,:]=True;last[-1,:]=True
        self.assertEqual(fractional_top_coverage(heat,first,10),.1)
        self.assertEqual(fractional_top_coverage(heat,last,10),.1)
        for mask in [first,last]:
            metrics,_=attention_metrics(np.ones((1,1)),grid_boxes(1,1,[0,0,10,10]),mask,(10,10),tie_diagnostics=True)
            self.assertAlmostEqual(metrics['coverage_tie_averaged']['0.1'],.1)
            self.assertAlmostEqual(metrics['peak_plateau_hit_fraction'],.1)
            self.assertEqual(metrics['peak_plateau_pixels'],100)
            self.assertAlmostEqual(metrics['enrichment'],1.)

    def test_fractional_cutoff_and_no_tie_cases(self):
        heat=np.array([[3.,2.,2.,2.,0.]])
        mask=np.array([[False,True,False,False,False]])
        self.assertAlmostEqual(fractional_top_coverage(heat,mask,2),1/3)
        unique=np.arange(25.).reshape(5,5);mask=unique%3==0
        for count in [0,1,7,25]:
            expected=float((top_area_mask(unique,count)&mask).sum()/mask.sum())
            self.assertAlmostEqual(fractional_top_coverage(unique,mask,count),expected)


class AssociationTest(unittest.TestCase):
    def test_adjustment_and_undefined_effects(self):
        np.testing.assert_array_equal(ranks([4,1,3,1]),[3,.5,2,.5])
        rng=np.random.default_rng(42);n=1000;z=rng.normal(size=n)
        x=z+.25*rng.normal(size=n);y=z+.25*rng.normal(size=n)
        cov=np.column_stack([z,rng.normal(size=n),np.ones(n)]);tasks=np.empty((n,0))
        self.assertGreater(partial_rank(x,y,cov,tasks,False),.8)
        self.assertLess(abs(partial_rank(x,y,cov,tasks,True)),.15)
        self.assertIsNone(partial_rank(x,np.ones(n),cov,tasks,True))
        self.assertIsNone(partial_rank(z,y,cov,tasks,True))

    def test_positive_direction_is_retained_when_interval_crosses_zero(self):
        rows=[dict(source_group_id=str(i//2),task_type='single',evidence_area_fraction=.1,
            min_instance_area_fraction=.1,instances=1,enrichment=i+1,hit=hit)
            for i,hit in enumerate([0,1,0,1,0,1,1,0])]
        result=association(rows,'enrichment','hit',False,repeats=200)
        self.assertEqual((result['n'],result['source_groups']),(8,4))
        self.assertEqual(result['direction'],'positive')
        self.assertTrue(result['interval_includes_zero'])
        self.assertGreater(result['effect'],0)


class V3SummaryTest(unittest.TestCase):
    def test_summary_connects_primary_attention_geometry_and_output_validity(self):
        with tempfile.TemporaryDirectory() as tmp:
            data=FixtureData(tmp);cfg=load_config(ROOT/'configs/public_e1.json')
            cfg.update(overview_edge=32,crop_edge=32,bootstrap_repeats=5)
            engine=Engine(CropBoxBackend(),data,tmp,cfg,'fixture_v3')
            Runner(engine).run(1,[data.records['I_plus']])
            out=summarize(engine.run_dir,cfg)
            quality=next(r for r in read_json(out/'e1_output_quality.json') if r['condition']=='overview_evidence')
            self.assertEqual(quality['reasons']['wrong_localization_view'],1)
            primary=next(r for r in read_json(out/'e1_attention_alignment.json') if r['condition']=='overview_evidence'
                         and r['stratum']=='all' and r['metric']=='coverage_10_tie_averaged')
            self.assertEqual((primary['role'],primary['n']),('primary',1))
            baseline=next(r for r in read_json(out/'e1_geometry_baseline.json') if r['condition']=='overview_evidence'
                          and r['metric']=='all_instances_hit' and r['cohort']=='all_measured')
            self.assertEqual((baseline['n'],baseline['mean']),(1,1.))
            conditional=next(r for r in read_json(out/'e1_geometry_baseline.json') if r['condition']=='overview_evidence'
                            and r['metric']=='all_instances_hit' and r['cohort']=='valid_outputs_matched')
            self.assertEqual((conditional['n'],conditional['model_n']),(0,0))
            links=read_json(out/'e1_attention_detection.json')
            self.assertEqual({r['feature'] for r in links},{'enrichment','coverage_10_tie_averaged'})
            self.assertTrue(all(r['effect'] is None for r in links))
            self.assertTrue((out/'e1_attention_association.png').exists())
            self.assertIn('interval crossing zero',(out/'e1_report.html').read_text())


if __name__=='__main__':
    unittest.main()
