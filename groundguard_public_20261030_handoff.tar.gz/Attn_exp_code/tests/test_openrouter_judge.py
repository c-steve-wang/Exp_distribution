import importlib.util
import json
import io
from pathlib import Path
import tempfile
import unittest
from unittest import mock

PATH = Path(__file__).resolve().parents[1]/'experiments/openrouter_judge.py'
spec = importlib.util.spec_from_file_location('openrouter_e1_judge', PATH)
judge = importlib.util.module_from_spec(spec)
spec.loader.exec_module(judge)


class OpenRouterJudgeTests(unittest.TestCase):
    def setUp(self):
        self.identity = dict(model=judge.MODEL, canonical_slug='deepseek/deepseek-v4.1-flash-20261017')

    def response(self, raw='{"correct":1,"reason":"Equivalent answer"}', finish='stop'):
        return dict(model=judge.MODEL, choices=[dict(finish_reason=finish, message=dict(content=raw))])

    def test_identity_loads_from_code_bundle_without_verification_reports(self):
        import shutil
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root/'configs').mkdir()
            shutil.copy2(PATH.parents[1]/'configs/semantic_judge.lock.json', root/'configs/semantic_judge.lock.json')
            with mock.patch.object(judge, 'ROOT', root):
                identity, template = judge.judge_identity()
            self.assertEqual(identity['model'], self.identity['model'])
            self.assertEqual(identity['canonical_slug'], self.identity['canonical_slug'])
            self.assertIn('{gt_answer}', template)
            self.assertFalse((root/'verification').exists())

    def test_explicit_negative_is_a_score_but_invalid_or_truncated_judge_is_not(self):
        self.assertFalse(judge.parse_response(self.response('{"correct":0,"reason":"Different count"}'),self.identity)[0])
        for response in [self.response(finish='length'), self.response('not json'),
                         self.response('{"correct":true,"reason":"x"}'),
                         self.response('{"correct":1,"correct":0,"reason":"x"}')]:
            with self.assertRaises(ValueError):judge.parse_response(response,self.identity)

    def test_unrequested_model_is_rejected(self):
        response=self.response();response['model']='different/model'
        with self.assertRaises(ValueError):judge.parse_response(response,self.identity)

    def test_contradictory_abstention_judgment_remains_an_error(self):
        task=dict(key='test',prompt='A concrete reference and abstention',prediction_text='Cannot determine',requires_negative_abstention=True)
        with mock.patch.object(judge.PACER,'wait'),mock.patch.object(judge.time,'sleep'),mock.patch.object(
                judge.urllib.request,'urlopen',side_effect=lambda *a,**k:io.StringIO(json.dumps(self.response()))):
            result=judge.request_judgment(task,'fake-token',self.identity)
        self.assertEqual(result['status'],'error')
        self.assertNotIn('correct',result)
        self.assertEqual(len(result['attempts']),5)

    def test_valid_only_unknown_policy_and_cross_model_deduplication(self):
        with tempfile.TemporaryDirectory() as tmp:
            runs=[]
            for model in ['9b','27b']:
                root=Path(tmp)/model;runs.append((model,root));(root/'records').mkdir(parents=True)
                row=dict(status='ok',dataset='vistaqa',sample_id='vistaqa/1',condition='overview',
                    scores=dict(format_valid=True),prediction=dict(status='UNKNOWN',answer='A guessed answer'),
                    question='What is it?',reference=dict(answer='A cat'),task_type='identification')
                (root/'records/valid.json').write_text(json.dumps(row))
                row['scores']['format_valid']=False
                (root/'records/invalid.json').write_text(json.dumps(row))
            tasks,scope=judge.prepare_tasks(runs,self.identity,'{question}|{gt_answer}|{pred_answer}|{task_type}|{domain}')
            self.assertEqual(len(tasks),1)
            self.assertEqual(len(tasks[0]['targets']),2)
            self.assertNotIn('A guessed answer',tasks[0]['prompt'])
            self.assertIn('cannot be determined',tasks[0]['prompt'])
            self.assertEqual(sum(x['eligible'] for x in scope),2)
            self.assertEqual(sum(x['excluded_invalid'] for x in scope),2)
            judge.apply_result(tasks[0],dict(status='error',error='Network failure'))
            for _,root in runs:
                result=json.loads((root/'judgments/valid.json').read_text())
                self.assertEqual(result['status'],'error')
                self.assertNotIn('correct',result)
                self.assertFalse((root/'judgments/invalid.json').exists())

    def test_existing_judge_cannot_be_silently_replaced(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);(root/'judge.json').write_text('{"model":"other"}')
            with self.assertRaises(ValueError):judge.prepare_tasks([('9b',root)],self.identity,'unused')


if __name__=='__main__':
    unittest.main()
