"""Pilot selection and report contracts; no dataset or checkpoint downloads."""
from collections import Counter
from contextlib import redirect_stderr
from io import StringIO
from pathlib import Path
from types import SimpleNamespace
import tempfile
import unittest
from unittest.mock import Mock, patch

import numpy as np
from PIL import Image

from experiments.__main__ import parser, model_spec, lock_models
from experiments.common import load_config, read_json
from experiments.runner import select_samples, interleave_samples
from experiments.validation import validate_backend

ROOT = Path(__file__).resolve().parents[1]


def rows_for(quotas):
    rows = []
    for name, count in quotas.items():
        for i in range(count):
            rows.append(dict(dataset=name, source_group_id=f'{name}/{i:04}', sample_id=f'{name}/{i:04}/q0',
                             task_type='a' if i % 2 else 'b', question='Where?',
                             reference=dict(target_status='present')))
    return rows


class PilotTest(unittest.TestCase):
    def setUp(self):
        self.config = load_config(ROOT / 'configs/experiments.json')
        self.rows = rows_for(dict(vistaqa=1152, gseval=1000, groundingme=820, hallusegbench=629))
        duplicate = dict(self.rows[0], sample_id=self.rows[0]['sample_id'] + '_extra')
        self.rows.append(duplicate)
        self.data = SimpleNamespace(primary=lambda subset, datasets: list(self.rows))

    def select(self, experiment=1, **kwargs):
        return select_samples(self.data, self.config, experiment, 'test', **kwargs)

    def test_interleaving_preserves_every_record_and_keeps_source_groups_together(self):
        rows = rows_for(dict(vistaqa=3, gseval=2))
        rows.insert(1, dict(rows[0], sample_id=rows[0]['sample_id'] + '_extra'))
        scheduled = interleave_samples(rows)
        self.assertEqual(Counter(r['sample_id'] for r in scheduled), Counter(r['sample_id'] for r in rows))
        self.assertEqual([r['dataset'] for r in scheduled[:3]], ['gseval', 'vistaqa', 'vistaqa'])
        for group in {r['source_group_id'] for r in rows}:
            positions = [i for i, r in enumerate(scheduled) if r['source_group_id'] == group]
            self.assertEqual(positions, list(range(min(positions), max(positions) + 1)))

    def test_per_dataset_counts_and_whole_source_groups(self):
        selected = self.select(pilot_fraction=.1)
        groups = {(r['dataset'], r['source_group_id']) for r in selected}
        self.assertEqual(Counter(name for name, _ in groups),
                         dict(vistaqa=116, gseval=100, groundingme=82, hallusegbench=63))
        self.assertEqual({r['sample_id'] for r in selected},
                         {r['sample_id'] for r in self.rows if (r['dataset'], r['source_group_id']) in groups})
        vista = [r for r in selected if r['dataset'] == 'vistaqa']
        self.assertEqual(Counter(r['task_type'] for r in {r['source_group_id']: r for r in vista}.values()),
                         dict(a=58, b=58))

    def test_order_dataset_and_experiment_independence(self):
        selected = self.select(pilot_fraction=.1)
        self.rows.reverse()
        self.assertEqual(selected, self.select(pilot_fraction=.1))
        for experiment in [3, 4]:
            self.assertEqual(selected, self.select(experiment, pilot_fraction=.1))
        individually = [r for name in ['vistaqa', 'gseval', 'groundingme', 'hallusegbench']
                        for r in self.select(datasets=[name], pilot_fraction=.1)]
        self.assertEqual({r['sample_id'] for r in selected}, {r['sample_id'] for r in individually})

    def test_shards_partition_pilot_and_full_run_retains_it(self):
        selected = self.select(pilot_fraction=.1)
        shards = [self.select(pilot_fraction=.1, shard_index=i, shards=3) for i in range(3)]
        self.assertEqual(len(selected), sum(map(len, shards)))
        self.assertEqual({r['sample_id'] for r in selected}, {r['sample_id'] for shard in shards for r in shard})
        self.assertTrue({r['sample_id'] for r in selected} < {r['sample_id'] for r in self.select()})
        self.assertEqual(self.select(), self.select(pilot_fraction=1))

    def test_experiment_two_uses_fifty_audit_sources(self):
        audit = rows_for(dict(vistaqa=250, gseval=50, groundingme=50, hallusegbench=150))
        with patch('experiments.runner.audit_samples', return_value=audit):
            selected = self.select(2, pilot_fraction=.1)
        self.assertEqual(len(selected), 50)
        self.assertEqual(Counter(r['dataset'] for r in selected),
                         dict(vistaqa=25, gseval=5, groundingme=5, hallusegbench=15))

    def test_shared_source_ids_do_not_inflate_dataset_quotas(self):
        self.rows = rows_for(dict(vistaqa=100, gseval=100))
        for row in self.rows:
            row['source_group_id'] = row['source_group_id'].split('/')[1]
        self.assertEqual(Counter(r['dataset'] for r in self.select(pilot_fraction=.1)),
                         dict(vistaqa=10, gseval=10))

    def test_invalid_fraction_and_conflicting_limit_are_rejected(self):
        for fraction in [0, -1, 1.1, float('nan'), float('inf')]:
            with self.assertRaises(ValueError):
                self.select(pilot_fraction=fraction)
            with redirect_stderr(StringIO()), self.assertRaises(SystemExit):
                parser().parse_args(['plan', '--experiment', '1', '--pilot-fraction', str(fraction)])
        with self.assertRaises(ValueError):
            self.select(limit=4, pilot_fraction=.1)
        with redirect_stderr(StringIO()), self.assertRaises(SystemExit):
            parser().parse_args(['propose', '--limit', '4', '--pilot-fraction', '.1'])
        self.assertEqual(parser().parse_args(['smoke', '--model', 'qwen35_4b']).limit, 2)

    def test_pilot_model_is_available_but_all_still_means_formal_models(self):
        self.assertEqual(model_spec(self.config, 'qwen35_4b')['repo_id'], 'Qwen/Qwen3.5-4B')
        hub = Mock()
        hub.HfApi.return_value.model_info.return_value.sha = 'a' * 40
        with tempfile.TemporaryDirectory() as tmp, patch.dict('sys.modules', huggingface_hub=hub):
            args = SimpleNamespace(command='lock-models', models=['all'], include_judge=False,
                                   lock=str(Path(tmp) / 'models.json'))
            lock_models(args, self.config)
            self.assertEqual(set(read_json(args.lock)), set(self.config['models']))
            args.models = ['qwen35_4b']
            lock_models(args, self.config)
            self.assertIn('qwen35_4b', read_json(args.lock))

    def test_validation_reports_keep_each_source_and_configuration(self):
        data = SimpleNamespace(image=lambda sample: Image.new('RGB', (16, 16)),
                               region_mask=lambda sample: None, fingerprint=lambda: 'fixture')
        result = dict(output_ids=[1], text='{"answer":"2","status":"ANSWERED","boxes":[]}', spatial_visual_tokens=1, layer_names=['test'],
                      local_layer_names=[], preprocessing={}, token_boxes=[], query_mode='test',
                      query_indices=[1], inference_seconds=0.)
        backend = SimpleNamespace(spec=dict(generation=dict(do_sample=False)),
                                  infer=lambda **kwargs: result,
                                  prefill_logits=lambda **kwargs: np.array([1., 2.]),
                                  decoder=SimpleNamespace(set_attn_implementation=lambda mode: None),
                                  metadata=lambda: dict(backend='fixture'))
        with tempfile.TemporaryDirectory() as tmp:
            first = validate_backend(backend, data, [self.rows[0]], self.config, Path(tmp))
            second = validate_backend(backend, data, [self.rows[1]], self.config, Path(tmp))
            third = validate_backend(backend, data, [self.rows[0]], dict(self.config, overview_edge=32), Path(tmp))
            self.assertEqual(len({first, second, third}), 3)
            self.assertTrue(all(p.exists() for p in [first, second, third]))
            result['text'] = '{}'
            validate_backend(backend, data, [self.rows[0]], self.config, Path(tmp))
            self.assertFalse(read_json(first)['protocol_validation_passed'])
            self.assertEqual(read_json(first)['format_errors'], 1)
            self.assertEqual(read_json(first)['checks'][0]['eager_text'], '{}')
            # A model format error is tolerated; altered model computation is not.
            backend.prefill_logits = lambda **kwargs: np.array([1., 2.]) + int(kwargs['capture'])
            with self.assertRaisesRegex(ValueError, 'Attention hook'):
                validate_backend(backend, data, [self.rows[0]], self.config, Path(tmp))


if __name__ == '__main__':
    unittest.main()
