"""Regression checks for candidate identity and experiment-two conclusions."""
from copy import deepcopy
from pathlib import Path
import json
import tempfile
import unittest
from unittest.mock import patch
import numpy as np
from experiments.analysis import action_audits, load_records, summarize, value
from experiments.action_analysis import action_tables
from experiments.candidates import candidate_composition, coverage, proposed_boxes
from experiments.common import load_config, read_json, write_json
from experiments.engine import Engine
from experiments.metrics import score_prediction
from experiments.experiment2_protocol import PROPOSAL_SYSTEM
from experiments.runner import Runner, generate_proposals, policy_order, proposal_path
from test_experiments import FixtureData, FakeBackend

ROOT = Path(__file__).resolve().parents[1]


def audit_fixture(root, baseline=0):
    candidates = [dict(index=i, source='grid', scheduled_source='grid') for i in range(32)]
    audit = dict(sample_id='gseval/example', source_group_id='source', dataset='gseval', subset='test',
        candidates=candidates, attention_scores=list(range(32)), candidate_pool='frozen',
        task_type='multi', region_kind='mask', min_instance_area_fraction=.005,
        generation_seeds=[42], confirmation_seeds=[],
        geometry=[dict(k=k, threshold=.9, **candidate_composition(candidates[:k]), pool_all_regions_covered=True,
            fraction_regions_covered=1., single_candidate_all_regions_covered=False,
            best_single_candidate_min_region_coverage=0.) for k in [8,16,32]])
    def row(stage, score, **extra):
        return dict(experiment=2, subset='test', sample_id=audit['sample_id'], dataset='gseval',
            source_group_id='source', seed=42, status='ok', task_type='multi',
            extra=dict(stage=stage, candidate_pool='frozen', **extra),
            scores=dict(detection_correct=score, all_instances_hit=score, all_boxes_correct=score))
    rows=[row('baseline', baseline), row('oracle',1)]
    rows += [row('candidate',int(i==10),candidate=i) for i in range(32)]
    rows += [row('selected',0,k=k,policy=p,budget=1,chosen=[0]) for k in [8,16,32] for p in ['attention','grid']]
    write_json(Path(root)/'audits/source.json',audit)
    return audit, rows


class Experiment2Test(unittest.TestCase):
    def test_backend_metadata_roundtrip_preserves_identity_but_detects_changes(self):
        from experiments.delivery import backend_matches
        actual = dict(model_config=dict(id2label={0: 'LABEL_0', 1: 'LABEL_1'}),
                      lock=dict(revision='a'*40), devices=['NVIDIA A100-SXM4-80GB'])
        saved = json.loads(json.dumps(actual))
        self.assertNotEqual(actual, saved)
        self.assertTrue(backend_matches(actual, saved))
        changed = deepcopy(saved);changed['lock']['revision']='b'*40
        self.assertFalse(backend_matches(actual, changed))
        changed = deepcopy(saved);changed['devices']=['NVIDIA A100-PCIE-40GB']
        self.assertFalse(backend_matches(actual, changed))

    def test_proposal_reminder_keeps_query_and_excludes_reference(self):
        with tempfile.TemporaryDirectory() as tmp:
            data=FixtureData(tmp);cfg=load_config(ROOT/'configs/experiments.json')
            sample=data.records['I_plus'];sample['reference']['answer']='PRIVATE_REFERENCE_SENTINEL'
            engine=Engine(FakeBackend(),data,tmp,cfg,'test_fixture')
            with patch.object(engine,'infer',wraps=engine.infer) as infer:
                generate_proposals(engine,[sample],'test')
            args=infer.call_args.args
            self.assertTrue(args[1].startswith(sample['question']))
            self.assertEqual(args[2],sample['question'])
            self.assertIn('decimal fraction',args[1])
            self.assertIn('exactly 8 distinct boxes',args[1])
            self.assertNotIn('PRIVATE_REFERENCE_SENTINEL',str(args[1:]))
            with self.assertRaises(ValueError):
                proposed_boxes('{"regions": [[10,20,300,400]]}',(64,64))

    def test_short_duplicate_and_invalid_proposals_have_visible_fallbacks(self):
        box = [.2, .2, .8, .8]
        cases = [(json.dumps(dict(regions=[box])), 1, False),
                 (json.dumps(dict(regions=[box] * 8)), 8, False),
                 ('invalid response', None, True)]
        for text, proposed, failed in cases:
            with self.subTest(proposed=proposed), tempfile.TemporaryDirectory() as tmp:
                data = FixtureData(tmp); cfg = load_config(ROOT/'configs/experiments.json')
                sample = data.records['I_plus']
                engine = Engine(FakeBackend(), data, tmp, cfg, 'test_fixture')
                with patch.object(engine, 'infer', return_value=dict(text=text, request_id='fixture')):
                    self.assertEqual(generate_proposals(engine, [sample], 'test'), 0)
                pool = read_json(proposal_path(data, 'test', sample))
                self.assertEqual(pool['proposed_question_regions'], proposed)
                self.assertEqual(pool['proposal_parse_error'] is not None, failed)
                self.assertEqual(len({tuple(c['bbox']) for c in pool['candidates']}), 32)
                composition = pool['candidate_composition']
                self.assertEqual(composition['question_slots'], 8)
                self.assertEqual(composition['question_candidates'], 0 if failed else 1)
                self.assertEqual(composition['question_shortfall'], 8 if failed else 7)

    def test_question_policy_prioritizes_real_proposals_before_grid_supplements(self):
        candidates = [dict(source=s, scheduled_source=s)
                      for s in ['grid', 'grid', 'saliency', 'question'] * 2]
        candidates[3]['source'] = 'grid_fallback'
        self.assertEqual(policy_order('question', candidates, [1]*8, 42, 'example'),
                         [7, 3, 0, 1, 2, 4, 5, 6])
        self.assertEqual(policy_order('grid', candidates, [1]*8, 42, 'example')[:4], [0, 1, 4, 5])

    def test_localization_distinguishes_extra_boxes_and_keeps_invalid_outputs(self):
        sample = deepcopy(FixtureData('.').records['I_plus']); sample['dataset'] = 'vistaqa'
        reference = [[24, 24, 40, 40]]
        prediction = dict(status='ANSWERED', answer='2', parse_error=None)
        scores = score_prediction(prediction, sample, reference + [[0, 0, 8, 8]], reference)
        self.assertTrue(scores['detection_correct'])  # Existing VistaQA definition stays fixed.
        self.assertTrue(scores['all_instances_hit']); self.assertFalse(scores['all_boxes_correct'])
        self.assertEqual(scores['precision'], .5)
        invalid = score_prediction(dict(status=None, parse_error='bad JSON'), sample, [], reference)
        self.assertFalse(invalid['all_instances_hit']); self.assertFalse(invalid['all_boxes_correct'])
        legacy = dict(status='ok', scores=dict(format_valid=False, region_kind='mask'))
        self.assertIs(value(legacy, 'all_boxes_correct'), False)
        self.assertNotIn('all_boxes_correct', legacy['scores'])
        self.assertIsNone(value(dict(status='not_run'), 'all_boxes_correct'))

    def test_localization_gaps_and_recovery_use_separate_denominators(self):
        with tempfile.TemporaryDirectory() as tmp:
            _, rows = audit_fixture(tmp)
            for row in rows:
                row['scores']['all_instances_hit'] = 1
            audits = action_audits(tmp, rows)
            recall = next(r for r in audits if r['k']==16 and r['policy']=='attention'
                          and r['component']=='all_instances_hit')
            strict = next(r for r in audits if r['k']==16 and r['policy']=='attention'
                          and r['component']=='all_boxes_correct')
            self.assertEqual(recall['selection_gap'], 0)
            self.assertIsNone(recall['pool_recovery_rate'])
            self.assertEqual(strict['selection_gap'], 1)
            self.assertEqual(strict['pool_recovery_rate'], 1)
            # Legacy format failures count as failed actions rather than missing scores.
            failed = next(r for r in rows if r['extra'].get('candidate')==0)
            failed['scores'] = dict(format_valid=False, region_kind='mask', detection_correct=False)
            audits = action_audits(tmp, rows)
            self.assertTrue(all(r['audit_complete'] for r in audits))

    def test_vistaqa_summary_reports_strict_and_recall_outcomes_for_each_budget(self):
        class ExtraBoxBackend(FakeBackend):
            def infer(self, views, prompt, question, system, seed, capture=True):
                result = super().infer(views, prompt, question, system, seed, capture)
                if system != PROPOSAL_SYSTEM and len(views)==1:
                    prediction = json.loads(result['text'])
                    prediction['boxes'].append(dict(view=0, bbox=[0, 0, .125, .125]))
                    result['text'] = json.dumps(prediction)
                return result
        with tempfile.TemporaryDirectory() as tmp:
            data = FixtureData(tmp); sample = data.records['I_plus']; sample['dataset'] = 'vistaqa'
            cfg = load_config(ROOT/'configs/experiments.json')
            cfg.update(overview_edge=32, crop_edge=32, bootstrap_repeats=3)
            engine = Engine(ExtraBoxBackend(), data, tmp, cfg, 'test_fixture')
            generate_proposals(engine, [sample], 'test')
            self.assertEqual(Runner(engine).run(2, [sample]), dict(source_errors=0, inference_errors=0))
            records = load_records(engine.run_dir)
            self.assertEqual(len(records), 79)
            chosen = next(r for r in records if r['condition']=='question_k8_b2')
            self.assertEqual(chosen['extra']['chosen_sources'], ['question', 'grid_fallback'])
            summary = summarize(engine.run_dir, cfg)
            metrics = read_json(summary/'metrics.json')
            baseline = {r['metric']:r['mean'] for r in metrics if r['condition']=='overview'}
            self.assertEqual(baseline['all_instances_hit'], 1)
            self.assertEqual(baseline['all_boxes_correct'], 0)
            self.assertEqual(baseline['detection_correct'], 1)
            paired = read_json(summary/'paired_changes.json')
            for budget in [1,2,4]:
                condition = f'attention_k8_b{budget}'
                scores = {r['metric']:r['mean'] for r in paired if r['condition']==condition}
                self.assertEqual(scores['all_boxes_correct'], 1)
                self.assertEqual(scores['all_boxes_correct.repair'], 1)
                self.assertEqual(scores['all_instances_hit'], 0)
                self.assertNotIn('all_instances_hit.repair', scores)
            geometry = read_json(summary/'candidate_coverage.json')
            self.assertEqual(len(geometry), 3)
            self.assertEqual(next(r for r in geometry if r['k']==32)['question_shortfall'], 7)

    def test_geometry_separates_pool_from_single_candidate(self):
        masks=[]
        for x in [0,6]:
            m=np.zeros((8,8),dtype=bool);m[:2,x:x+2]=True;masks.append(m)
        candidates=[dict(bbox=[0,0,2,2]),dict(bbox=[6,0,8,2]),dict(bbox=[0,0,8,2])]
        small,large=coverage(candidates,masks,(8,8),counts=[2,3])
        self.assertTrue(small['pool_all_regions_covered'])
        self.assertFalse(small['single_candidate_all_regions_covered'])
        self.assertEqual(small['best_single_candidate_min_region_coverage'],0)
        self.assertTrue(large['single_candidate_all_regions_covered'])

    def test_changed_pool_is_rejected_and_unchanged_pool_resumes(self):
        with tempfile.TemporaryDirectory() as tmp:
            data=FixtureData(Path(tmp)/'work');backend=FakeBackend()
            cfg=load_config(ROOT/'configs/experiments.json');cfg.update(overview_edge=32,crop_edge=32,bootstrap_repeats=3)
            engine=Engine(backend,data,tmp,cfg,'test_fixture');sample=data.records['I_plus']
            generate_proposals(engine,[sample],'test');runner=Runner(engine)
            self.assertEqual(runner.run(2,[sample]),dict(source_errors=0,inference_errors=0))
            calls=backend.calls;runner.run(2,[sample]);self.assertEqual(calls,backend.calls)
            before={r['record_file']:r for r in load_records(engine.run_dir)}
            path=proposal_path(data,'test',sample);proposal=read_json(path)
            proposal['identity']['proposer']['revision']='b'*40
            proposal['candidates'][3]['bbox']=[6,6,58,58];write_json(path,proposal)
            with self.assertRaisesRegex(ValueError,'Candidate pool changed'):
                runner.experiment2(sample)
            self.assertEqual(before,{r['record_file']:r for r in load_records(engine.run_dir)})
            summary=summarize(engine.run_dir,cfg)
            paired=read_json(summary/'paired_changes.json')
            self.assertTrue(any(r['experiment']==2 and r['condition']=='oracle_crop' for r in paired))
            for b in [1,2,4]:
                self.assertTrue(any(r['experiment']==2 and r['condition'].endswith('_b'+str(b)) for r in paired))

    def test_candidate_view_mismatch_does_not_silently_resume(self):
        with tempfile.TemporaryDirectory() as tmp:
            data=FixtureData(tmp);cfg=load_config(ROOT/'configs/experiments.json');cfg.update(overview_edge=32,crop_edge=32)
            engine=Engine(FakeBackend(),data,tmp,cfg,'test_fixture');sample=data.records['I_plus']
            generate_proposals(engine,[sample],'test');runner=Runner(engine);runner.run(2,[sample])
            row=next(r for r in load_records(engine.run_dir) if r['condition']=='candidate_00')
            row['views'][1]['source_box']=[1,1,2,2]
            path=engine.run_dir/'records'/row.pop('record_file');write_json(path,row)
            with self.assertRaisesRegex(ValueError,'Cached action views'):
                runner.experiment2(sample)

    def test_bottlenecks_recovery_and_geometry_denominators(self):
        with tempfile.TemporaryDirectory() as tmp:
            _,rows=audit_fixture(tmp)
            audits=action_audits(tmp,rows)
            small=next(r for r in audits if r['k']==8)
            large=next(r for r in audits if r['k']==16)
            self.assertEqual((small['proposal_gap'],small['selection_gap']),(1,0))
            self.assertEqual((large['proposal_gap'],large['selection_gap']),(0,1))
            self.assertEqual(small['pool_recovery_rate'],0)
            self.assertEqual(large['pool_recovery_rate'],1)
            self.assertEqual(large['selected_recovery_rate'],0)
            self.assertEqual(large['oracle_recovery_rate'],1)
            tables=action_tables(audits,3)
            self.assertEqual(len(tables['candidate_coverage']),3)
            self.assertTrue(all(r['n']==1 for r in tables['candidate_coverage_summary']))
            self.assertTrue(any(r['stratum']=='initial_detection:all_incorrect' for r in tables['action_stratified_summary']))

    def test_initially_correct_is_not_in_recovery_denominator(self):
        with tempfile.TemporaryDirectory() as tmp:
            _,rows=audit_fixture(tmp,baseline=1)
            self.assertTrue(all(r['pool_recovery_rate'] is None for r in action_audits(tmp,rows)))

    def test_missing_candidate_seed_invalidates_pool(self):
        with tempfile.TemporaryDirectory() as tmp:
            audit,rows=audit_fixture(tmp)
            audit['generation_seeds']=[42,43];write_json(Path(tmp)/'audits/source.json',audit)
            rows += [dict(deepcopy(r),seed=43) for r in rows
                     if not (r['extra']['stage']=='candidate' and r['extra']['candidate']==0)]
            audits=action_audits(tmp,rows)
            self.assertTrue(all(not r['audit_complete'] and 'proposal_gap' not in r for r in audits))

    def test_failed_selection_does_not_receive_cached_candidate_credit(self):
        with tempfile.TemporaryDirectory() as tmp:
            _,rows=audit_fixture(tmp)
            for r in rows:
                if r['extra']['stage']=='selected':r['status']='error'
            audits=action_audits(tmp,rows)
            self.assertTrue(all(r['audit_complete'] and not r['selection_complete'] for r in audits))
            self.assertTrue(all(r['selected_gain'] is None and 'selection_gap' not in r for r in audits))

    def test_summary_rejects_mixed_pool_records(self):
        with tempfile.TemporaryDirectory() as tmp:
            _,rows=audit_fixture(tmp);rows[-1]['extra']['candidate_pool']='changed'
            with self.assertRaisesRegex(ValueError,'Mixed candidate pools'):
                action_audits(tmp,rows)


if __name__=='__main__':unittest.main()
