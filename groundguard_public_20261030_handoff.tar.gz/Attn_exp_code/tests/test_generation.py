"""Check official presence semantics and prevent scoring unfinished thinking."""
import unittest
import torch
from experiments.generation import PresencePenalty, native_eos_ids, final_response
from experiments.protocol import parse_prediction


class GenerationTest(unittest.TestCase):
    def test_presence_excludes_prompt_and_counts_presence_not_frequency(self):
        ids = torch.tensor([[0, 1, 2, 2, 3], [3, 2, 1, 1, 1]])
        scores = torch.tensor([[2., -2., 1., -1., 0.], [0., 1., 2., 3., 4.]])
        result = PresencePenalty(1.5, 2)(ids, scores)
        expected = torch.tensor([[2., -2., -.5, -2.5, 0.], [0., -.5, 2., 3., 4.]])
        torch.testing.assert_close(result, expected)
        self.assertEqual(scores[0, 2].item(), 1.)

    def test_presence_does_nothing_before_first_generated_token(self):
        scores = torch.randn(1, 4)
        self.assertIs(PresencePenalty(1.5, 2)(torch.tensor([[1, 2]]), scores), scores)

    def test_invalid_presence_rejected(self):
        for value in [float('nan'), float('inf'), 3.]:
            with self.assertRaises(ValueError):
                PresencePenalty(value, 2)

    def test_native_eos_keeps_text_end_and_chat_end(self):
        self.assertEqual(native_eos_ids(248044, 248046), [248044, 248046])
        self.assertEqual(native_eos_ids([248044, 248046], 248046), [248044, 248046])

    def test_unfinished_thinking_json_cannot_be_scored_as_final_answer(self):
        draft = '{"answer":"yes","status":"MATCH","boxes":[],"facts":[]}'
        text, complete = final_response('Possible answer: ' + draft, True)
        self.assertFalse(complete)
        self.assertIsNotNone(parse_prediction(text, 1)['parse_error'])
        text, complete = final_response('draft ' + draft + '</think>\n' + draft, True)
        self.assertTrue(complete)
        self.assertIsNone(parse_prediction(text, 1)['parse_error'])

    def test_non_thinking_text_is_preserved(self):
        self.assertEqual(final_response('unchanged', False), ('unchanged', None))


if __name__ == '__main__':
    unittest.main()
