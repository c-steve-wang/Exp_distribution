"""Experiment 1 failures, abstentions, paired controls, and launch scope."""
from copy import deepcopy
from pathlib import Path
import json
import os
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

from experiments.analysis import load_records, summarize
from experiments.common import fingerprint, load_config, read_json, write_json
from experiments.engine import Engine
from experiments.judge import prediction_text, parse_judgment
from experiments.metrics import score_prediction
from experiments.runner import Runner, experiment1_expected, select_samples
from test_experiments import FixtureData, FakeBackend

ROOT = Path(__file__).resolve().parents[1]


class Experiment1Test(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.data = FixtureData(self.tmp.name)
        self.config = load_config(ROOT / 'configs/experiments.json')
        self.config.update(overview_edge=32, crop_edge=32, bootstrap_repeats=10)
        self.engine = Engine(FakeBackend(), self.data, self.tmp.name, self.config, 'test_fixture')
        self.sample = self.data.records['I_plus']

    def test_source_failure_accounts_for_all_four_conditions_and_recovers(self):
        with patch.object(self.data, 'image', side_effect=OSError('unreadable image')):
            failures = Runner(self.engine).run(1, [self.sample])
        self.assertEqual(failures, dict(source_errors=1, inference_errors=4))
        rows = load_records(self.engine.run_dir)
        self.assertEqual(len(rows), 4)
        self.assertTrue(all(r['status'] == 'error' for r in rows))
        summary = summarize(self.engine.run_dir, self.config)
        accuracy = [r for r in read_json(summary / 'metrics.json') if r['metric'] == 'task_correct']
        self.assertEqual(len(accuracy), 4)
        self.assertTrue(all(r['n'] == 1 and r['mean'] == 0 for r in accuracy))
        failures = Runner(self.engine, retry_errors=True).run(1, [self.sample])
        self.assertFalse(any(failures.values()))
        self.assertFalse(list((self.engine.run_dir / 'source_errors').glob('*.json')))
        self.assertTrue(all(r['status'] == 'ok' for r in load_records(self.engine.run_dir)))

    def test_unstarted_conditions_remain_visible_without_fabricating_accuracy(self):
        expected = experiment1_expected(self.sample, 'test', 42)
        write_json(self.engine.run_dir / 'expected' / 'interrupted.json', dict(records=expected))
        write_json(self.engine.run_dir / 'expected' / 'overlap.json', dict(records=expected))
        summary = summarize(self.engine.run_dir, self.config)
        self.assertEqual(len(load_records(self.engine.run_dir)), 4)
        complete = read_json(summary / 'completeness.json')
        self.assertEqual(len(complete['expected_records_not_run']), 4)
        execution = [r for r in read_json(summary / 'metrics.json') if r['metric'] == 'execution_success']
        accuracy = [r for r in read_json(summary / 'metrics.json') if r['metric'] == 'task_correct']
        self.assertTrue(all(r['mean'] == 0 and r['n'] == 1 for r in execution))
        self.assertTrue(all(r['mean'] is None and r['n'] == 0 for r in accuracy))

    def test_partial_source_failure_preserves_completed_measurements(self):
        def partial(sample):
            runner.job(1, sample, 'overview', [runner.overview(self.data.image(sample))])
            raise RuntimeError('crop preparation failed')
        runner = Runner(self.engine)
        with patch.object(runner, 'experiment1', side_effect=partial):
            failures = runner.run(1, [self.sample])
        rows = load_records(self.engine.run_dir)
        self.assertEqual(failures['inference_errors'], 3)
        self.assertEqual(next(r for r in rows if r['condition'] == 'overview')['status'], 'ok')

    def test_no_target_is_skipped_but_corrupt_positive_is_an_error(self):
        absent = deepcopy(self.sample)
        absent['reference']['regions'] = []
        with patch.object(self.data, 'image', side_effect=AssertionError('No image needed')):
            failures = Runner(self.engine).run(1, [absent])
        self.assertFalse(any(failures.values()))
        rows = load_records(self.engine.run_dir)
        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0]['status'], 'skipped')

    def test_empty_positive_annotation_fails_four_conditions(self):
        with patch.object(self.data, 'region_mask', return_value=self.data.mask & False):
            failures = Runner(self.engine).run(1, [self.sample])
        self.assertEqual(failures['inference_errors'], 4)

    def test_evidence_control_contrast_uses_matched_conditions(self):
        Runner(self.engine).run(1, [self.sample])
        for path in (self.engine.run_dir / 'records').glob('*.json'):
            row = read_json(path)
            correct = row['condition'] == 'overview_evidence'
            row['scores'].update(task_correct=correct, answer_correct=correct, detection_correct=correct)
            write_json(path, row)
        summary = summarize(self.engine.run_dir, self.config)
        direct = [r for r in read_json(summary / 'paired_changes.json') if r['baseline'] == 'overview_control'
                  and r['condition'] == 'overview_evidence' and r['metric'] == 'task_correct']
        self.assertEqual(len(direct), 1)
        self.assertEqual(direct[0]['mean'], 1.)
        self.assertEqual(direct[0]['n'], 1)
        self.assertEqual(len(read_json(summary / 'inference_costs.json')), 4)
        for path in (self.engine.run_dir / 'records').glob('*.json'):
            row = read_json(path)
            if row['condition'] == 'overview_control':
                row.update(status='skipped', reason='No matched control')
                write_json(path, row)
        summary = summarize(self.engine.run_dir, self.config)
        self.assertFalse(any(r['baseline'] == 'overview_control' for r in read_json(summary / 'paired_changes.json')))

    def test_unknown_cannot_smuggle_an_answer_into_judge_or_exact_match(self):
        sample = deepcopy(self.sample)
        sample['dataset'] = 'vistaqa'
        prediction = dict(status='UNKNOWN', answer='2', parse_error=None)
        row = dict(prediction=prediction)
        self.assertNotIn('2', prediction_text(row))
        scores = score_prediction(prediction, sample, [], [r['bbox_xyxy'] for r in sample['reference']['regions']])
        self.assertFalse(scores['exact_answer_match'])
        row.update(status='ok', dataset='vistaqa', scores=scores)
        write_json(self.engine.run_dir / 'records' / 'unknown.json', row)
        write_json(self.engine.run_dir / 'judgments' / 'unknown.json', dict(status='ok', correct=True))
        self.assertIsNone(load_records(self.engine.run_dir)[0]['scores']['task_correct'])
        # The official judge may accept an abstention when the reference permits it.
        write_json(self.engine.run_dir / 'judgments' / 'unknown.json',
                   dict(status='ok', correct=True, prediction_text=prediction_text(row)))
        measured = load_records(self.engine.run_dir)[0]['scores']
        self.assertTrue(measured['task_correct'])
        self.assertFalse(measured['joint_answer_detection'])

    def test_invalid_coordinates_continue_and_remain_in_primary_denominator(self):
        second = deepcopy(self.data.records['I_minus'])
        second['reference']['answer'] = '2'
        second['source_group_id'] = 'synthetic/counting/0001'
        infer = self.engine.backend.infer

        def bad_first(*args, **kwargs):
            result = infer(*args, **kwargs)
            if self.engine.backend.calls == 1:
                result['text'] = json.dumps(dict(answer='2', status='ANSWERED',
                    boxes=[dict(view=0, bbox=[0, 0, 1000, 1000])]))
            return result

        with patch.object(self.engine.backend, 'infer', side_effect=bad_first):
            failures = Runner(self.engine).run(1, [self.sample, second])
        self.assertFalse(any(failures.values()))
        rows = load_records(self.engine.run_dir)
        self.assertEqual(len(rows), 8)
        invalid = [r for r in rows if not r['scores']['format_valid']]
        self.assertEqual(len(invalid), 1)
        self.assertFalse(invalid[0]['scores']['task_correct'])
        self.assertFalse(invalid[0]['scores']['joint_answer_detection'])
        output = summarize(self.engine.run_dir, self.config)
        primary = next(r for r in read_json(output / 'metrics.json')
                       if r['condition'] == 'overview' and r['metric'] == 'task_correct')
        valid = next(r for r in read_json(output / 'valid_output_metrics.json')
                     if r['condition'] == 'overview' and r['metric'] == 'task_correct')
        self.assertEqual((primary['n'], primary['mean']), (2, .5))
        self.assertEqual((valid['n'], valid['mean']), (1, 1.))
        quality = next(r for r in read_json(output / 'output_quality.json') if r['condition'] == 'overview')
        self.assertEqual((quality['generated'], quality['format_errors'], quality['format_error_rate']), (2, 1, .5))
        paired = next(r for r in read_json(output / 'paired_changes_valid_outputs.json')
                      if r['baseline'] == 'overview' and r['condition'] == 'overview_evidence'
                      and r['metric'] == 'task_correct')
        self.assertEqual((paired['n'], paired['mean']), (1, 0.))
        failed = read_json(output / 'format_failures.json')
        self.assertEqual(len(failed), 1)
        self.assertTrue((self.engine.run_dir / failed[0]['raw_output_file']).exists())

    def test_invalid_output_cannot_receive_credit_from_saved_judgment(self):
        sample = deepcopy(self.sample)
        sample['dataset'] = 'vistaqa'
        prediction = dict(answer='', status=None, parse_error='Invalid normalized box')
        scores = score_prediction(prediction, sample, [], [])
        write_json(self.engine.run_dir / 'records' / 'invalid.json',
                   dict(status='ok', dataset='vistaqa', prediction=prediction, scores=scores))
        write_json(self.engine.run_dir / 'judgments' / 'invalid.json', dict(status='ok', correct=True))
        measured = load_records(self.engine.run_dir)[0]['scores']
        self.assertFalse(measured['task_correct'])
        self.assertFalse(measured['joint_answer_detection'])

    def test_malformed_judgment_is_not_silently_scored_wrong(self):
        for value in [None, 2, .5, [], {}, 'maybe']:
            with self.assertRaises(ValueError):
                parse_judgment(json.dumps(dict(correct=value)))
        for value, expected in [(0, False), (1, True), ('yes', True), ('false', False)]:
            self.assertEqual(parse_judgment(json.dumps(dict(correct=value)))[0], expected)

    def test_smoke_selects_positive_sources_before_applying_limit(self):
        absent = deepcopy(self.sample)
        absent.update(sample_id='a/absent', source_group_id='a')
        absent['reference']['regions'] = []
        positive = deepcopy(self.sample)
        positive.update(sample_id='z/positive', source_group_id='z')
        with patch.object(self.data, 'primary', create=True, return_value=[absent, positive]):
            selected = select_samples(self.data, self.config, 1, 'test', limit=1, positive_only=True)
        self.assertEqual([r['sample_id'] for r in selected], ['z/positive'])

    def test_cli_summary_refuses_incomplete_inference(self):
        from experiments.__main__ import main
        write_json(self.engine.run_dir / 'expected' / 'interrupted.json',
                   dict(records=experiment1_expected(self.sample, 'test', 42)))
        args = ['experiments', '--config', str(self.engine.run_dir / 'experiment_config.json'),
                'summarize', '--run-dir', str(self.engine.run_dir), '--require-complete']
        with patch('sys.argv', args), self.assertRaises(SystemExit):
            main()
        self.assertTrue((self.engine.run_dir / 'summary' / 'completeness.json').exists())



if __name__ == '__main__':
    unittest.main()
