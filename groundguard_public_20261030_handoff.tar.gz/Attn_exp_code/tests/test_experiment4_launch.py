"""The unified launch gate binds actual measurements, backend and manifest."""
from pathlib import Path
from types import SimpleNamespace
import tempfile
import unittest
from experiments.common import write_json,file_hash,read_json
from experiments.delivery import require_gpu_gate,gate_path


class LaunchGateTests(unittest.TestCase):
    def test_saved_metadata_and_mismatched_evidence(self):
        with tempfile.TemporaryDirectory() as folder:
            path=Path(folder)/'manifest.json';write_json(path,dict(model='model_a'))
            metadata={'lock':{'revision':'a'*40},'model_config':{'id2label':{0:'LABEL_0'}}}
            backend=SimpleNamespace(metadata=lambda:metadata)
            gate=dict(passed=True,manifest_sha256=file_hash(path),backend=metadata,
                checks=[dict(hook_preserves_tokens=True,hook_logits_allclose=True)])
            write_json(gate_path(path),gate);require_gpu_gate(path,backend)
            metadata['lock']['revision']='b'*40
            with self.assertRaises(ValueError):require_gpu_gate(path,backend)
            metadata['lock']['revision']='a'*40
            gate['checks'][0]['hook_preserves_tokens']=False;write_json(gate_path(path),gate)
            with self.assertRaises(ValueError):require_gpu_gate(path,backend)
            gate['checks'][0]['hook_preserves_tokens']=True;write_json(gate_path(path),gate)
            write_json(path,dict(model='model_b'))
            with self.assertRaises(ValueError):require_gpu_gate(path,backend)


if __name__=='__main__':unittest.main()
