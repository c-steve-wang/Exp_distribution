"""VistaQA's frozen official prompt, served by a local text-only judge on CUDA."""
import ast
from pathlib import Path
from .common import fingerprint, file_hash, read_json, write_json
from .protocol import final_json


def official_prompt():
    path = Path(__file__).resolve().parents[1] / 'third_party/vistaqa/config.py'
    for node in ast.parse(path.read_text()).body:
        if isinstance(node, ast.AnnAssign) and isinstance(node.target, ast.Name) and node.target.id == 'JUDGE_PROMPT_TEMPLATE':
            return ast.literal_eval(node.value), file_hash(path)
    raise ValueError('Official judge prompt not found')


def prediction_text(row):
    """Judge an abstention as an abstention, even if its answer field guesses."""
    if row['prediction']['status'] == 'UNKNOWN':
        return 'The answer cannot be determined from the supplied image.'
    return row['prediction']['answer']


def parse_judgment(raw):
    parsed = final_json(raw)
    value = parsed['correct']
    if isinstance(value, str):
        value = value.strip().lower()
        if value not in {'1', 'true', 'yes', '0', 'false', 'no'}:
            raise ValueError('Invalid judge correct value')
        correct = value in {'1', 'true', 'yes'}
    elif type(value) in {int, bool} and value in (0, 1):
        correct = bool(value)
    else:
        raise ValueError('Invalid judge correct value')
    return correct, str(parsed.get('reason', ''))


def judge_results(run_dir, config, lock, limit=None, retry_errors=False):
    import torch
    from transformers import AutoTokenizer, AutoModelForCausalLM
    if not torch.cuda.is_available():
        raise RuntimeError('Semantic judging is a server GPU job')
    spec = config['judge']
    checkpoint = lock['judge']
    if checkpoint['repo_id'] != spec['repo_id'] or len(checkpoint['revision']) != 40:
        raise ValueError('Invalid judge checkpoint lock')
    root = Path(run_dir)
    template, prompt_hash = official_prompt()
    judge_id = dict(spec=spec, checkpoint=checkpoint, prompt_sha256=prompt_hash,
                    status_policy='unknown_as_abstention_v1')
    path = root / 'judge.json'
    if path.exists() and read_json(path) != judge_id:
        raise ValueError('Judge identity changed; do not mix semantic scores')
    write_json(path, judge_id)
    files = sorted((root / 'records').glob('*.json'))
    pending = []
    for file in files:
        row = read_json(file)
        if row.get('status') != 'ok' or row['dataset'] != 'vistaqa':
            continue
        output = root / 'judgments' / file.name
        if output.exists() and (read_json(output)['status'] == 'ok' or not retry_errors):
            continue
        pending.append((row, output))
    if limit is not None:
        pending = pending[:limit]
    if not pending:
        return
    path = checkpoint.get('local_path') or spec['repo_id']
    tokenizer = AutoTokenizer.from_pretrained(path, revision=checkpoint['revision'])
    model = AutoModelForCausalLM.from_pretrained(path, revision=checkpoint['revision'], dtype=getattr(torch, spec['dtype']),
                                               device_map=spec['device_map'], attn_implementation='sdpa').eval()
    for i, (row, output) in enumerate(pending):
        if not row['scores']['format_valid']:
            write_json(output, dict(status='ok', correct=False, reason='Invalid task output format', judge_id=judge_id))
            continue
        answer = prediction_text(row)
        prompt = template.format(question=row['question'], gt_answer=row['reference']['answer'],
            pred_answer=answer, task_type=row['task_type'], domain=row.get('domain', ''))
        key = fingerprint(dict(prompt=prompt, judge=judge_id))
        cache = root / 'judge_cache' / (key + '.json')
        if cache.exists() and (read_json(cache)['status'] == 'ok' or not retry_errors):
            result = read_json(cache)
        else:
            try:
                tokens = tokenizer.apply_chat_template([{'role': 'user', 'content': prompt}], add_generation_prompt=True,
                                                       tokenize=True, return_tensors='pt').to(model.get_input_embeddings().weight.device)
                with torch.inference_mode():
                    generated = model.generate(tokens, do_sample=False, max_new_tokens=spec['max_new_tokens'])
                raw = tokenizer.decode(generated[0, tokens.shape[1]:], skip_special_tokens=True)
                correct, reason = parse_judgment(raw)
                result = dict(status='ok', correct=correct, raw_text=raw, reason=reason,
                              prediction_text=answer, judge_id=judge_id)
            except Exception as error:
                result = dict(status='error', error=repr(error), judge_id=judge_id)
            write_json(cache, result)
        write_json(output, result)
        print(f'judge {i + 1}/{len(pending)} {row["sample_id"]}', flush=True)
