"""Offline head/query and depth diagnostics from compact text→vision caches."""
from pathlib import Path
import numpy as np
from .common import read_json,write_json
from .metrics import token_mask_fractions,attention_metrics


def summarize_attention_detail(root,data):
    from .analysis import dump_csv,load_records
    rows=[];seen=set()
    for row in load_records(root):
        if row['status']!='ok' or not row.get('request_id') or row['request_id'] in seen:continue
        seen.add(row['request_id']);cache=Path(root)/'cache'/(row['request_id']+'.json')
        inference=read_json(cache)
        if not inference.get('attention_file'):continue
        sample=data.get(row['sample_id']);mask=data.region_mask(sample)
        if mask is None or not mask.any():continue
        boxes=inference['token_boxes'];size=(sample['image']['width'],sample['image']['height'])
        fractions=token_mask_fractions(boxes,mask,size)
        visual_index={index:i for i,index in enumerate(inference['visual_indices'])}
        with np.load(cache.with_name(inference['attention_file']),allow_pickle=False) as arrays:
            layers=arrays['layer_weights']
            for index,layer in enumerate(inference['layer_names']):
                m,_=attention_metrics(layers[index:index+1],boxes,mask,size)
                rows.append(dict(request_id=row['request_id'],sample_id=row['sample_id'],condition=row['condition'],
                    stage='prefill_depth',layer=layer,head=None,query=None,**m))
            for key,meta in inference.get('attention_indices',{}).items():
                values=arrays[key]
                indices=[visual_index[i] for i in meta['visual_keys']]
                # Retain head and query identity; do not optimize selection on test scores.
                for head in range(values.shape[0]):
                    for query in range(values.shape[1]):
                        mass=float(values[head,query].sum())
                        evidence=float(values[head,query]@fractions[indices]/mass) if mass>0 else None
                        rows.append(dict(request_id=row['request_id'],sample_id=row['sample_id'],condition=row['condition'],
                            stage=meta['stage'],layer=meta['layer'],head=head,query=meta['queries'][query],
                            spatial_visual_mass=mass,evidence_mass=evidence,complete_visual_support=len(indices)==len(boxes),
                            role='exploratory_no_test_head_selection'))
    out=Path(root)/'summary';write_json(out/'attention_head_query_depth.json',rows);dump_csv(out/'attention_head_query_depth.csv',rows)
    return out/'attention_head_query_depth.json'
