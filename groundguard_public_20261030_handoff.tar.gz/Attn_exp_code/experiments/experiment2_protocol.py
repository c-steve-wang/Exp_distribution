import json
import math

SYSTEM = '''Analyze only the supplied images. Return your final response as one JSON object:
{"answer": "short answer", "status": "ANSWERED|UNKNOWN|MATCH|NO_MATCH|PRESENT|ABSENT",
 "boxes": [{"view": 0, "bbox": [x1,y1,x2,y2]}], "facts": ["short directly observed fact"]}.
Use fractional coordinates between 0.0 and 1.0 relative to the specified image view:
x is the fraction of image width and y is the fraction of image height.
For example, a box covering the entire supplied image is [0.0, 0.0, 1.0, 1.0].
Never output pixel coordinates or coordinates on a 0-to-1000 scale.
Every box must satisfy 0 <= x1 < x2 <= 1 and 0 <= y1 < y2 <= 1.
Number image views from 0 in their supplied order. Give boxes for all requested targets;
avoid repeating the same object across views. If no target matches, return an empty boxes list.
For a general question use ANSWERED or UNKNOWN. For a referring description use MATCH,
NO_MATCH or UNKNOWN. For an existence query use PRESENT, ABSENT or UNKNOWN.
Use UNKNOWN when the supplied observation cannot determine the answer.
Do not use external knowledge to invent visible objects. Keep the original task semantics.'''

PROPOSAL_SYSTEM = '''Using only this overview image and question, propose exactly 8 distinct regions
worth inspecting at higher resolution. Do not answer or perform the original task.
Return exactly one JSON object with the single key "regions" and a list of boxes.
Every box is [x1,y1,x2,y2], where BOTH x and y are decimal fractions of the image
width and height between 0.0 and 1.0. The entire image is [0.0,0.0,1.0,1.0].
Require 0 <= x1 < x2 <= 1 and 0 <= y1 < y2 <= 1.
Never use pixels or a 0-to-1000 coordinate scale. Never output bbox_2d or labels.
Choose different regions worth inspecting; do not repeat an identical box.
Do not return an answer or a detection list.'''

PROPOSAL_REMINDER = '''
Region-proposal output requirements: Do not answer the original question.
Return exactly {"regions": [[x1,y1,x2,y2], ...]} with exactly 8 distinct boxes, then stop.
Each coordinate must be a decimal fraction between 0.0 and 1.0.
For example, a central region can be [0.25,0.25,0.75,0.75].
Use the key regions, not bbox_2d. Do not return labels, text, or a top-level list.
Do not use pixel coordinates or a 0-to-1000 scale. Close all JSON brackets.'''

FACT_QUESTION = '''Record visible facts about the contents of a unique black frame, without answering a task question.
Return {"facts": ["count=N", "color=COLOR", "circle_left_of_square=yes|no"]}.
Count symbols only. COLOR is red, blue, cyan or mixed. Only include facts directly discernible;
omit uncertain or inapplicable fields. If no unique frame can be identified, return an empty list.'''
FACT_SYSTEM = 'Describe the supplied views using only the requested fact vocabulary. Return one JSON object.'

FORMAT_REMINDER = '''
Output requirements: Return exactly one JSON object, then stop. Do not repeat it.
Include answer, status, boxes, and facts. Use each JSON key once per object.
For every bbox, BOTH x and y must be decimal fractions between 0.0 and 1.0.
A full-image box is [0.0, 0.0, 1.0, 1.0]. Use x1 < x2 and y1 < y2.
Do not mix fractions with pixels or 0-to-1000 coordinates. Number supplied views
from zero. If no target can be located, use an empty boxes list and the appropriate
task status. Keep facts to at most three short items. Close all JSON brackets and braces.'''


def allowed_statuses(dataset):
    if dataset in {'gseval', 'groundingme'}:
        return {'MATCH', 'NO_MATCH', 'UNKNOWN'}
    if dataset == 'hallusegbench':
        return {'PRESENT', 'ABSENT', 'UNKNOWN'}
    return {'ANSWERED', 'UNKNOWN'}


def task_system(sample):
    """Expose only the current task's labels; never consult reference answers."""
    statuses = '|'.join(sorted(allowed_statuses(sample['dataset'])))
    general = ('For a general question use ANSWERED or UNKNOWN. For a referring description use MATCH,\n'
               'NO_MATCH or UNKNOWN. For an existence query use PRESENT, ABSENT or UNKNOWN.')
    if sample['dataset'] in {'gseval', 'groundingme'}:
        instruction = ('Use MATCH when an object matches the entire referring description; '
                       'NO_MATCH when no object matches that description; UNKNOWN when uncertain. '
                       'NO_MATCH concerns this description, not absence of the entire object category.')
    elif sample['dataset'] == 'hallusegbench':
        instruction = ('Use PRESENT when the queried target exists, ABSENT when it does not, '
                       'and UNKNOWN when uncertain.')
    else:
        instruction = 'Use ANSWERED for a concrete answer, and UNKNOWN when uncertain.'
    return SYSTEM.replace('ANSWERED|UNKNOWN|MATCH|NO_MATCH|PRESENT|ABSENT', statuses).replace(general, instruction)


def task_prompt(sample, views=1):
    from .protocol import task_box_limit, box_budget_instruction
    if type(views) is not int or views < 1:
        raise ValueError('At least one supplied view is required')
    task = ('existence query' if sample['dataset'] == 'hallusegbench' else
            'referring description' if sample['dataset'] in {'gseval', 'groundingme'} else 'general question')
    labels = ', '.join(sorted(allowed_statuses(sample['dataset'])))
    return (f'Task type: {task}\nQuestion:\n{sample["question"]}' + FORMAT_REMINDER
            + f'\nFor THIS task, status must be exactly one of: {labels}.\n'
            + f'There are exactly {views} supplied images. Legal view indices: {list(range(views))}.\n'
            + 'Each box must be an object with its own view and a flat four-number bbox, '
              'for example {"view":0,"bbox":[0.125,0.25,0.5,0.75]}.\n'
              'Both axes use fractions: 25% is 0.25, never 25 or 250. '
              'Do not add placeholder [0,0,0,0] boxes for views without a target. '
              'Each requested target should be reported once, in a view where it can be located.\n'
            + box_budget_instruction(task_box_limit(sample['dataset'])))


def image_content(views, prompt):
    """Label images explicitly without exposing source boxes or annotation metadata."""
    content = []
    for i, item in enumerate(views):
        content.extend([dict(type='text', text=f'Image view {i}:\n'),
                        dict(type='image', image=item['image'])])
    return content + [dict(type='text', text=prompt)]


def prediction_schema(dataset, views):
    if type(views) is not int or views < 1:
        raise ValueError('At least one supplied view is required')
    from .protocol import prediction_schema as shared_schema, task_box_limit
    return shared_schema(dataset, views, max_boxes=task_box_limit(dataset))


def proposal_schema():
    box = dict(type='array', items=dict(type='number', minimum=0, maximum=1), minItems=4, maxItems=4)
    return dict(type='object', properties=dict(regions=dict(type='array', items=box, minItems=8, maxItems=8)),
                required=['regions'], additionalProperties=False)


from .protocol import final_json, valid_box, parse_prediction
