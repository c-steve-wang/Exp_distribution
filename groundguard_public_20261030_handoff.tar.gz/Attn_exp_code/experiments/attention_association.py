"""Continuous E1 attention–behavior associations, stratified by dataset.

Effects and uncertainty are both reported. A confidence interval crossing zero
is not encoded as an absent relationship. Partial rank correlations are
descriptive adjustment, never a causal attribution to attention.
"""
from collections import defaultdict
import numpy as np

CONTROLS = 'union area + minimum instance area + annotation instance count + task type'


def ranks(values):
    values = np.asarray(values, dtype=float)
    order = np.argsort(values, kind='stable')
    sorted_values = values[order]
    bounds = np.r_[0, np.flatnonzero(sorted_values[1:] != sorted_values[:-1])+1, len(values)]
    result = np.empty(len(values), dtype=float)
    result[order] = np.repeat((bounds[:-1]+bounds[1:]-1)/2, np.diff(bounds))
    return result


def partial_rank(x, y, covariates, tasks, adjusted):
    x, y = ranks(x), ranks(y)
    x, y = x-x.mean(), y-y.mean()
    sx, sy = np.linalg.norm(x), np.linalg.norm(y)
    if min(sx, sy) < 1e-10:
        return None
    x, y = x/sx, y/sy
    if adjusted:
        ranked = []
        for column in covariates.T:
            values = ranks(column)
            values -= values.mean()
            ranked.append(values/max(np.linalg.norm(values), 1e-10))
        design = np.column_stack([np.ones(len(x)), *ranked, tasks])
        if len(x)-np.linalg.matrix_rank(design) < 4:
            return None
        x = x-design@np.linalg.lstsq(design, x, rcond=None)[0]
        y = y-design@np.linalg.lstsq(design, y, rcond=None)[0]
    x, y = x-x.mean(), y-y.mean()
    sx, sy = np.linalg.norm(x), np.linalg.norm(y)
    return float(np.clip(x@y/(sx*sy), -1, 1)) if min(sx, sy) > 1e-9 else None


def association(rows, feature, outcome, adjusted, repeats=1000, seed=42):
    """Rows already belong to one dataset and the valid overview cohort."""
    fields = [feature, outcome, 'evidence_area_fraction', 'min_instance_area_fraction', 'instances']
    rows = [r for r in rows if all(r.get(k) is not None and np.isfinite(r[k]) for k in fields)]
    groups = defaultdict(list)
    for i, row in enumerate(rows):
        groups[row['source_group_id']].append(i)
    result = dict(n=len(rows), source_groups=len(groups), effect=None, low=None, high=None,
        bootstrap_valid=0, bootstrap_repeats=repeats, direction='unmeasured',
        interval_includes_zero=None, covariates=CONTROLS if adjusted else 'none')
    if len(rows) < 5:
        return result
    names = sorted({r['task_type'] for r in rows})
    tasks = np.array([[float(r['task_type']==name) for name in names[1:]] for r in rows]).reshape(len(rows), -1)
    covariates = np.array([[r[k] for k in fields[2:]] for r in rows])
    x, y = (np.array([r[k] for r in rows], dtype=float) for k in [feature, outcome])
    estimate = partial_rank(x, y, covariates, tasks, adjusted)
    result['effect'] = estimate
    if estimate is None:
        return result
    result['direction'] = 'positive' if estimate > 0 else 'negative' if estimate < 0 else 'zero'
    clusters = [np.array(v) for _, v in sorted(groups.items())]
    boot, rng = [], np.random.default_rng(seed)
    for _ in range(repeats):
        indices = np.concatenate([clusters[j] for j in rng.integers(0, len(clusters), len(clusters))])
        effect = partial_rank(x[indices], y[indices], covariates[indices], tasks[indices], adjusted)
        if effect is not None:
            boot.append(effect)
    result['bootstrap_valid'] = len(boot)
    if boot:
        low, high = map(float, np.quantile(boot, [.025, .975]))
        result.update(low=low, high=high, interval_includes_zero=low <= 0 <= high)
    return result
