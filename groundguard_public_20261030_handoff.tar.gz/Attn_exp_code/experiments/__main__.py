"""Usage: python -m experiments --help. CPU commands never import torch."""
import argparse
from copy import deepcopy
from pathlib import Path
import json
from .common import load_config, read_json, write_json, fingerprint, file_hash
from .data_source import resolve_data_root, fetch_data, SOURCE_CONFIG


def model_spec(config, key):
    spec = deepcopy(config['model_defaults'])
    spec.update({**config['models'], **config.get('pilot_models', {})}[key])
    return spec


def fraction_arg(value):
    fraction = float(value)
    if not 0 < fraction <= 1:
        raise argparse.ArgumentTypeError('Pilot fraction must be in (0, 1]')
    return fraction


def parser():
    cli = argparse.ArgumentParser(description='GroundGuard experiments 1–4')
    cli.add_argument('--config', default='configs/experiments.json')
    cli.add_argument('--data-root', help='Existing prepared data; otherwise reuse the pinned HF dataset locally')
    cli.add_argument('--work-root', default='experiment_work')
    cli.add_argument('--output-root', default='experiment_outputs')
    cli.add_argument('--lock', default='configs/models.public.lock.json')
    commands = cli.add_subparsers(dest='command', required=True)
    fetch = commands.add_parser('fetch-data', help='Reuse or cache the pinned SteveWCG/Attn_exp_data snapshot')
    fetch.add_argument('--local-dir', help='Optional persistent dataset cache directory on this server')
    prepare = commands.add_parser('prepare', help='CPU: freeze the public-data action audit')
    prepare.add_argument('--include-synthetic', action='store_true',
                         help='Later controlled experiments: also generate synthetic scenes in a separate work directory')
    for name in ['lock-models', 'download-models']:
        command = commands.add_parser(name, help='Server: resolve checkpoints/download weights')
        command.add_argument('--models', nargs='+', default=['all'])
        command.add_argument('--include-judge', action='store_true')
    for name in ['plan', 'run', 'propose', 'smoke']:
        command = commands.add_parser(name)
        if name != 'smoke':
            command.add_argument('--include-synthetic', action='store_true', help='Opt in to later controlled experiments')
        command.add_argument('--subset', choices=['test'], default='test')
        command.add_argument('--datasets', nargs='+', choices=['vistaqa', 'gseval', 'groundingme', 'hallusegbench', 'synthetic'])
        selection = command.add_mutually_exclusive_group()
        selection.add_argument('--limit', type=int, help='Limit source groups for a smoke/debug run; omit for full analysis')
        if name != 'smoke':
            selection.add_argument('--pilot-fraction', type=fraction_arg,
                                   help='Seeded fraction of source groups per dataset, e.g. 0.1; no held-out split')
        if name == 'smoke':
            command.set_defaults(limit=2)
            command.add_argument('--experiment', type=int, choices=[1, 3, 4], default=1)
            command.add_argument('--positive-only', action='store_true', help='Validate all crop modes using annotated positive samples')
        command.add_argument('--shard-index', type=int, default=0)
        command.add_argument('--shards', type=int, default=1)
        command.add_argument('--retry-errors', action='store_true')
        if name in ['plan', 'run']:
            command.add_argument('--experiment', type=int, choices=[1, 2, 3, 4], required=True)
            command.add_argument('--interleave-datasets', action='store_true',
                                 help='Alternate datasets by whole source group; selection and per-example seeds are unchanged')
        if name in ['run', 'smoke']:
            command.add_argument('--model', required=True)
        if name == 'run':
            command.add_argument('--write-run-info', help='Save the actual run directory and inference status as JSON')
    for name in ['summarize', 'judge']:
        command = commands.add_parser(name)
        command.add_argument('--run-dir', required=True)
        if name == 'judge':
            command.add_argument('--limit', type=int)
            command.add_argument('--retry-errors', action='store_true')
        else:
            command.add_argument('--require-complete', action='store_true',
                                 help='Write summaries, then fail on missing or failed inference (judging can be pending)')
    visualize = commands.add_parser('visualize', help='CPU: render one measured record and its attention')
    visualize.add_argument('--run-dir', required=True)
    visualize.add_argument('--record', required=True, help='Record filename or absolute path')
    visualize.add_argument('--include-synthetic', action='store_true')
    return cli


def lock_models(args, cfg):
    from huggingface_hub import HfApi, snapshot_download
    keys = list(cfg['models']) if 'all' in args.models else args.models
    available = {**cfg['models'], **cfg.get('pilot_models', {})}
    specs = {k: available[k] for k in keys}
    if args.include_judge:
        specs['judge'] = cfg['judge']
    path = Path(args.lock)
    lock = read_json(path) if path.exists() else {}
    for key, spec in specs.items():
        if key in lock and lock[key]['repo_id'] != spec['repo_id']:
            raise ValueError('Existing lock targets a different checkpoint: ' + key)
        if args.command == 'lock-models':
            if key not in lock:
                lock[key] = dict(repo_id=spec['repo_id'], revision=HfApi().model_info(spec['repo_id']).sha)
                write_json(path, lock)
        else:
            if key not in lock:
                raise ValueError('Run lock-models first: ' + key)
            snapshot_download(spec['repo_id'], revision=lock[key]['revision'])
        print(key + ': ' + lock[key]['revision'], flush=True)


def main():
    args = parser().parse_args()
    if args.command in {'run', 'propose', 'smoke', 'judge'}:
        raise SystemExit('This legacy execution entrypoint is retired. Use scripts/project.py with its frozen manifest, GPU preflight, and configured judge.')
    cfg = load_config(args.config)
    if args.command == 'fetch-data':
        print(json.dumps(fetch_data(args.local_dir), indent=2, ensure_ascii=False))
        return
    if args.command in ['lock-models', 'download-models']:
        lock_models(args, cfg)
        return
    if args.command == 'summarize':
        from .analysis import summarize
        output = summarize(args.run_dir, cfg)
        print(output)
        complete = read_json(output / 'completeness.json')
        if args.require_complete and any(complete[k] for k in ['source_errors', 'selected_sources_not_completed',
                'inference_errors', 'expected_records_not_run']):
            raise SystemExit('Inference is incomplete; see ' + str(output / 'completeness.json'))
        return
    if args.command == 'judge':
        from .judge import judge_results
        judge_results(args.run_dir, cfg, read_json(args.lock), args.limit, args.retry_errors)
        return
    from .data import ExperimentData, prepare_audit
    args.data_root = resolve_data_root(args.data_root)
    include_synthetic = getattr(args, 'include_synthetic', False)
    if 'synthetic' in (getattr(args, 'datasets', None) or []) and not include_synthetic:
        raise ValueError('Synthetic data is deferred; opt in with --include-synthetic for later controlled runs')
    if args.command == 'prepare':
        synthetic_root = Path(args.work_root) / 'synthetic'
        if args.include_synthetic:
            from .synthetic import generate
            generate(synthetic_root, cfg['seed'], cfg['synthetic_per_task'])
        elif (synthetic_root / 'catalog.jsonl').exists():
            raise ValueError('This work directory contains synthetic scenes; use a new public-data work directory')
        data = ExperimentData(args.data_root, args.work_root, include_synthetic=include_synthetic)
        manifest = prepare_audit(data, cfg, 'test')
        print(f'test: {len(manifest["sample_ids"])} natural + {len(manifest["synthetic_sample_ids"])} synthetic audit sources')
        return
    data = ExperimentData(args.data_root, args.work_root, include_synthetic=include_synthetic)
    if args.command == 'visualize':
        from .visualize import render_record
        print(render_record(data, args.run_dir, args.record))
        return
    from .runner import select_samples, generate_proposals, Runner, interleave_samples
    experiment = 2 if args.command == 'propose' else getattr(args, 'experiment', 1)
    if experiment == 4 and not cfg.get('experiment4_measurement'):
        raise ValueError('Experiment 4 requires --config configs/public_e4.json')
    if experiment == 4 and args.command == 'run':
        raise ValueError('Use scripts/project.py run with its frozen manifest and matching GPU preflight')
    if experiment == 3 and not cfg.get('experiment3_measurement'):
        raise ValueError('Experiment 3 requires --config configs/public_e3.json')
    if experiment == 3 and args.command == 'run':
        raise ValueError('Use the frozen scripts/project.py run entrypoint; it enforces the matching GPU preflight gate')
    pilot_fraction = getattr(args, 'pilot_fraction', None)
    samples = select_samples(data, cfg, experiment, args.subset, args.datasets, args.limit, args.shard_index, args.shards,
                             pilot_fraction=pilot_fraction, positive_only=getattr(args, 'positive_only', False))
    if getattr(args, 'interleave_datasets', False):
        samples = interleave_samples(samples)
    if args.command == 'plan':
        from collections import Counter
        result = dict(experiment=experiment, subset=args.subset, primary_records=len(samples),
            data_root=str(args.data_root), include_synthetic=include_synthetic, pilot_fraction=pilot_fraction,
            source_groups=len({s['source_group_id'] for s in samples}), datasets=dict(Counter(s['dataset'] for s in samples)),
            synthetic_present=bool(data.synthetic), inference='not executed', sample_ids=[s['sample_id'] for s in samples[:10]])
        if experiment == 1:
            applicable = [s for s in samples if s['reference']['regions']]
            result.update(positive_records=len(applicable), not_applicable_records=len(samples) - len(applicable),
                          maximum_condition_records=4 * len(applicable),
                          note='A missing matched control is skipped and reported; other conditions still run.')
        if experiment == 3:
            from .experiment3 import expected
            planned = [r for s in samples for r in expected(data, s, args.subset, cfg['seed'])]
            result.update(expected_condition_records=len(planned),
                          expanded_records=len({r['sample_id'] for r in planned}),
                          note='Missing matched controls and zero-mass attention interventions are explicitly skipped.')
        if experiment == 4:
            from .experiment4 import expected
            planned = [r for s in samples for r in expected(data, s, args.subset, cfg['seed'], cfg)]
            result.update(expected_condition_records=len(planned),
                expanded_records=len({r['sample_id'] for r in planned}),
                conditions=dict(Counter(r['condition'] for r in planned)),
                note='All Hallu pairs receive a common-resolution four-cell baseline and preplanned region/control rescue.')
        print(json.dumps(result, indent=2, ensure_ascii=False))
        return
    key = cfg['proposer'] if args.command == 'propose' else args.model
    from .backends import VisionBackend
    from .engine import Engine
    backend = VisionBackend(model_spec(cfg, key), read_json(args.lock)[key])
    if args.command == 'smoke':
        from .validation import validate_backend
        print(validate_backend(backend, data, samples, cfg, Path(args.output_root) / 'validation' / key,
                               experiment=experiment))
        return
    engine = Engine(backend, data, args.output_root, cfg, key)
    write_json(engine.run_dir / 'data_source.json', dict(configured_source=read_json(SOURCE_CONFIG),
               build_report_sha256=file_hash(args.data_root / 'build_report.json')))
    write_json(engine.run_dir / f'selection_e{experiment}_{args.subset}_shard{args.shard_index}of{args.shards}_{fingerprint([s["sample_id"] for s in samples])[:12]}.json',
               dict(experiment=experiment, subset=args.subset, shard_index=args.shard_index, shards=args.shards,
                    sample_ids=[s['sample_id'] for s in samples], limited=args.limit is not None or pilot_fraction is not None,
                    pilot_fraction=pilot_fraction, sampling_seed=cfg['seed'],
                    interleave_datasets=getattr(args, 'interleave_datasets', False)))
    if args.command == 'propose':
        generate_proposals(engine, samples, args.subset, args.retry_errors)
    else:
        info = dict(run_dir=str(engine.run_dir.resolve()), model=key, experiment=experiment,
                    pilot_fraction=pilot_fraction, selected_records=len(samples), status='running')
        if args.write_run_info:
            write_json(args.write_run_info, info)
        failures = Runner(engine, args.subset, args.retry_errors).run(experiment, samples)
        info.update(failures, status='inference_failed' if any(failures.values()) else 'inference_finished')
        if args.write_run_info:
            write_json(args.write_run_info, info)
    print('Run directory: ' + str(engine.run_dir), flush=True)
    if args.command == 'run' and any(failures.values()):
        raise SystemExit('Some inference tasks failed; retry with --retry-errors and inspect completeness.json after summarize.')


if __name__ == '__main__':
    main()
