from pathlib import Path
import hashlib
import json
import os
import random
import tempfile


def canonical(value):
    return json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(',', ':'), allow_nan=False)


def fingerprint(value):
    return hashlib.sha256(canonical(value).encode()).hexdigest()


def file_hash(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def read_json(path):
    return json.loads(Path(path).read_text())


def write_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temporary = tempfile.mkstemp(prefix=path.name + '.', dir=path.parent)
    try:
        with os.fdopen(fd, 'w') as stream:
            stream.write(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + '\n')
        os.replace(temporary, path)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


def rng_for(seed, *parts):
    return random.Random(int(fingerprint([seed, *parts])[:16], 16))


def shard_contains(key, index, total):
    if total < 1 or not 0 <= index < total:
        raise ValueError('Invalid shard index/count')
    return int(fingerprint(key)[:16], 16) % total == index


def load_config(path):
    config = read_json(path)
    if config['schema_version'] != 1:
        raise ValueError('Unsupported experiment config')
    if config['seed'] != 42:
        raise ValueError('The frozen protocol uses sampling seed 42')
    return config

