import math
import re
import unicodedata
import numpy as np
from .geometry import pixel_bounds, top_area_mask
from .protocol import allowed_statuses


LOCALIZATION_METRICS = ('all_instances_hit', 'all_boxes_correct')
INSTANCE_COVERAGE_POLICY = 'fractional_membership_at_exact_cutoff_v1'

def iou(a, b):
    intersection = max(0, min(a[2], b[2]) - max(a[0], b[0])) * max(0, min(a[3], b[3]) - max(a[1], b[1]))
    union = (a[2] - a[0]) * (a[3] - a[1]) + (b[2] - b[0]) * (b[3] - b[1]) - intersection
    return intersection / union if union > 0 else 0.


def box_matches(predicted, reference, threshold=.5):
    """Maximum bipartite cardinality matching, not order-dependent greedy matching."""
    owners = {}
    edges = [[j for j, target in enumerate(reference) if iou(box, target) >= threshold] for box in predicted]
    def assign(i, seen):
        for j in edges[i]:
            if j in seen:
                continue
            seen.add(j)
            if j not in owners or assign(owners[j], seen):
                owners[j] = i
                return True
        return False
    count = sum(assign(i, set()) for i in range(len(predicted)))
    return dict(matches=count, precision=count / len(predicted) if predicted else (0. if reference else None),
                recall=count / len(reference) if reference else None,
                all_instances_hit=count == len(reference) if reference else None,
                all_boxes_correct=count == len(reference) == len(predicted) if reference else None)


def normalize_answer(text):
    return re.sub(r'\s+', ' ', unicodedata.normalize('NFKC', str(text)).casefold()).strip().rstrip('.。')


def nonanswer_guard(prediction, reference):
    """Content guard for textual answers only; preserve zero and native OCR punctuation."""
    return (not str(prediction).strip() or
            (not any(c.isalnum() for c in str(prediction)) and any(c.isalnum() for c in str(reference))))


def finalize_answer_scores(row):
    """Apply to new and cached scores in memory, without rewriting inference/judge evidence."""
    if row.get('status') != 'ok':
        return row
    scores, ref, pred = row['scores'], row.get('reference', {}), row.get('prediction', {})
    if ref.get('answer_type') != 'grounding_presence' and 'answer' in ref:
        guarded = nonanswer_guard(pred.get('answer', ''), ref['answer']) and pred.get('status') != 'UNKNOWN'
        scores['nonanswer_guard_applied'] = guarded
        if guarded:
            scores.update(answer_correct=False, task_correct=False, joint_answer_detection=False,
                          concrete_answer=False, exact_answer_match=False)
    answer, loc = scores.get('answer_correct'), scores.get('all_boxes_correct')
    if ref.get('regions') and answer is not None and loc is not None:
        scores['joint_answer_localization'] = bool(answer and loc and scores.get('concrete_answer'))
    else:
        scores['joint_answer_localization'] = None
    return row


def project_mass(weights, token_boxes, size):
    weights = np.asarray(weights, dtype=np.float64)
    if len(weights) != len(token_boxes) or not np.isfinite(weights).all() or (weights < 0).any():
        raise ValueError('Invalid spatial attention weights')
    out = np.zeros((size[1], size[0]), dtype=np.float64)
    for mass, item in zip(weights, token_boxes):
        x1, y1, x2, y2, overlap = cell_overlap(item['bbox'], size)
        out[y1:y2, x1:x2] += mass * overlap
    return out


def cell_overlap(box, size):
    """Integrate continuous token cells over pixels, including subpixel cells."""
    a, b, c, d = box
    x1, y1, x2, y2 = max(0, math.floor(a)), max(0, math.floor(b)), min(size[0], math.ceil(c)), min(size[1], math.ceil(d))
    xx, yy = np.arange(x1, x2), np.arange(y1, y2)
    dx = np.maximum(0, np.minimum(xx + 1, c) - np.maximum(xx, a))
    dy = np.maximum(0, np.minimum(yy + 1, d) - np.maximum(yy, b))
    overlap = dy[:, None] * dx[None, :]
    if overlap.sum() <= 0:
        raise ValueError('Visual token has no image support')
    return x1, y1, x2, y2, overlap / overlap.sum()


def token_mask_fractions(token_boxes, mask, size):
    fractions = []
    for item in token_boxes:
        x1, y1, x2, y2, overlap = cell_overlap(item['bbox'], size)
        fractions.append(float((overlap * mask[y1:y2, x1:x2]).sum()))
    return np.asarray(fractions)


def fractional_top_coverage(heatmap, mask, pixels):
    """Expected mask coverage with uniform selection among cutoff ties.

    Above-cutoff pixels have weight one; tied pixels share the remaining area
    budget equally. This does not invent pixel resolution inside a visual token.
    """
    area = int(mask.sum())
    if not area:
        return None
    count = min(max(0, int(pixels)), heatmap.size)
    if count == 0:
        return 0.
    if count == heatmap.size:
        return 1.
    threshold = np.partition(heatmap.ravel(), heatmap.size-count)[heatmap.size-count]
    above, tied = heatmap > threshold, heatmap == threshold
    fraction = (count-int(above.sum()))/int(tied.sum())
    return float((int((above & mask).sum())+fraction*int((tied & mask).sum()))/area)


def instance_attention_metrics(heatmap, masks, coverages=(.05, .1, .2)):
    """Use the union metric's fractional cutoff rule for every instance."""
    masks = list(masks)
    measured = bool(heatmap.sum() > 0)
    coverage = {str(c): [fractional_top_coverage(heatmap, mask, math.ceil(c * heatmap.size))
                        if measured and mask is not None else None for mask in masks]
                for c in coverages}
    return dict(instance_coverage_policy=INSTANCE_COVERAGE_POLICY,
        instance_mass=[float(heatmap[mask].sum()) if measured and mask is not None and mask.any()
                       else None for mask in masks],
        instance_coverage=coverage,
        instance_coverage_tie_averaged={k:list(v) for k,v in coverage.items()},
        all_instances_covered_at90={k:all(f >= .9 for f in v)
            if v and all(f is not None for f in v) else None for k,v in coverage.items()})


def attention_metrics(layer_weights, token_boxes, mask, size, coverages=(.05, .1, .2), tie_diagnostics=False):
    """Average queries/heads before this call; layer_weights retains every measured layer."""
    values = np.asarray(layer_weights, dtype=np.float64)
    if values.ndim != 2 or values.shape[0] == 0:
        raise ValueError('Attention must have shape [measured_layers, spatial_visual_tokens]')
    if not np.isfinite(values).all() or (values < 0).any():
        raise ValueError('Nonfinite or negative attention')
    raw = values.mean(axis=0)
    total = float(raw.sum())
    if total <= 0:
        return dict(spatial_visual_mass=0., measured_layers=int(values.shape[0]),
                    per_layer_spatial_visual_mass=values.sum(axis=1).tolist(),
                    annotation_available=mask is not None and bool(mask.any()),
                    baseline_policy='valid_footprint_area_same_projection_v2',
                    evidence_mass=None, uniform_evidence_mass=None, enrichment=None,
                    peak_hit=None, coverage={}, coverage_tie_averaged={},
                    within_visual_normalization_defined=False), np.zeros((size[1], size[0]), dtype=float)
    heatmap = project_mass(raw / total, token_boxes, size)
    # Area is counted per valid footprint: overlapping overview/crop tokens are
    # distinct supports. Project the baseline through the same map as attention.
    areas = np.asarray([max(0., min(size[0], b['bbox'][2]) - max(0., b['bbox'][0])) *
                        max(0., min(size[1], b['bbox'][3]) - max(0., b['bbox'][1])) for b in token_boxes])
    if len(areas) != len(raw) or not len(areas) or (areas <= 0).any():
        raise ValueError('Every spatial token must have a positive valid footprint')
    uniform = project_mass(areas / areas.sum(), token_boxes, size)
    result = dict(spatial_visual_mass=total, measured_layers=int(values.shape[0]),
                  per_layer_spatial_visual_mass=values.sum(axis=1).tolist(),
                  annotation_available=mask is not None and bool(mask.any()),
                  baseline_policy='valid_footprint_area_same_projection_v2',
                  evidence_mass=None, uniform_evidence_mass=None, enrichment=None,
                  peak_hit=None, coverage={}, coverage_tie_averaged={})
    if mask is not None and mask.any():
        evidence = float(heatmap[mask].sum())
        baseline = float(uniform[mask].sum())
        mask_fractions = token_mask_fractions(token_boxes, mask, size)
        result.update(evidence_mass=evidence, uniform_evidence_mass=baseline,
                      enrichment=evidence / baseline if baseline > 0 else None,
                      peak_hit=bool(mask.ravel()[int(np.argmax(heatmap))]),
                      coverage={str(c): fractional_top_coverage(heatmap, mask, math.ceil(c * heatmap.size))
                                for c in coverages},
                      per_layer_evidence_mass=[float(v @ mask_fractions / v.sum())
                                               if v.sum() > 0 else None for v in values])
        result.update(coverage_tie_averaged=dict(result['coverage']),
                      coverage_tie_policy='fractional_membership_at_exact_cutoff')
        if tie_diagnostics:
            plateau = heatmap == heatmap.max()
            result.update(coverage_tie_averaged={str(c): fractional_top_coverage(
                heatmap, mask, math.ceil(c*heatmap.size)) for c in coverages},
                coverage_tie_policy='fractional_membership_at_exact_cutoff',
                peak_plateau_pixels=int(plateau.sum()),
                peak_plateau_any_hit=bool((plateau & mask).any()),
                peak_plateau_hit_fraction=float(mask[plateau].mean()))
    return result, heatmap


def score_prediction(prediction, sample, predicted_boxes, reference_boxes, support_available=True):
    ref = sample['reference']
    status = prediction.get('status')
    valid = prediction.get('parse_error') is None and status in allowed_statuses(sample['dataset'])
    concrete = valid and status != 'UNKNOWN'
    result = dict(format_valid=valid, concrete_answer=concrete, region_kind=ref['region_kind'],
                  answer_correct=None, task_correct=None, support_available=support_available)
    if not valid:
        result.update(task_correct=False, answer_correct=False, detection_correct=False,
                      joint_answer_detection=False)
        if reference_boxes:
            result.update(matches=0, precision=0., recall=0., all_instances_hit=False, all_boxes_correct=False)
        if sample['dataset'] == 'synthetic':
            penalty = not ref.get('global_ambiguous')
            result.update(supported_concrete_answer=False, unsupported_concrete_answer=False,
                          evidence_match=False, abstain_penalty=penalty, utility_w=-int(penalty))
        return result
    if ref['answer_type'] == 'grounding_presence':
        expected = ref['answer']
        result['answer_correct'] = status == expected
        if ref['target_status'] in {'absent', 'no_match'}:
            result['detection_correct'] = status == expected and not predicted_boxes
            result['false_positive'] = bool(predicted_boxes) or status in {'PRESENT', 'MATCH'}
        else:
            match = box_matches(predicted_boxes, reference_boxes)
            result.update(match)
            # Native GroundingSuite / GroundingME Acc@0.5 expects one prediction.
            result['detection_correct'] = status == expected and match['all_boxes_correct']
        result['task_correct'] = bool(result['answer_correct'] and result['detection_correct'])
        result['joint_answer_detection'] = bool(result['task_correct'] and concrete)
    else:
        result['exact_answer_match'] = concrete and normalize_answer(prediction.get('answer', '')) == normalize_answer(ref['answer'])
        match = box_matches(predicted_boxes, reference_boxes)
        result.update(match)
        result['detection_correct'] = match['all_instances_hit'] if reference_boxes else None
        # Natural-language semantic accuracy is filled by the separate frozen judge.
        if sample['dataset'] == 'synthetic':
            unknown = ref.get('global_ambiguous') or not support_available
            result['answer_correct'] = status == 'UNKNOWN' if ref.get('global_ambiguous') else concrete and result['exact_answer_match']
            result['task_correct'] = status == 'UNKNOWN' if unknown else result['answer_correct']
            result['supported_concrete_answer'] = bool(concrete and support_available and result['answer_correct'])
            result['unsupported_concrete_answer'] = bool(concrete and (not support_available or not result['answer_correct']))
            result['abstain_penalty'] = bool(status == 'UNKNOWN' and not ref.get('global_ambiguous'))
            result['evidence_match'] = bool(support_available and result['detection_correct'])
            result['utility_w'] = (int(result['answer_correct']) + int(result['evidence_match'])
                                   - int(result['unsupported_concrete_answer']) - int(result['abstain_penalty']))
    return result


def rank_correlation(a, b):
    def ranks(values):
        order = np.argsort(values, kind='stable')
        output = np.zeros(len(values), dtype=float)
        start = 0
        while start < len(values):
            end = start + 1
            while end < len(values) and values[order[end]] == values[order[start]]:
                end += 1
            output[order[start:end]] = (start + end - 1) / 2
            start = end
        return output
    a, b = np.asarray(a), np.asarray(b)
    if len(a) < 2 or np.ptp(a) == 0 or np.ptp(b) == 0:
        return None
    return float(np.corrcoef(ranks(a), ranks(b))[0, 1])


def score_value(scores, key):
    # Older invalid outputs did not persist these two localization fields.
    # They remain failures when analyzed, without rewriting saved records.
    if (key in LOCALIZATION_METRICS and scores.get('format_valid') is False
            and scores.get('region_kind') in {'mask', 'bbox'}):
        return False
    return scores.get(key)
