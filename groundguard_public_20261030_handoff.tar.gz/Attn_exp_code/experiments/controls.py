"""Fixed public no-image/wrong-image controls; no spatial truth on donor images."""
from pathlib import Path
from .common import fingerprint, write_json, read_json
from .geometry import view
from .metrics import score_prediction, finalize_answer_scores
from .protocol import SYSTEM, task_prompt, parse_prediction, prediction_contract
from .protocol import prediction_request, parse_task_prediction


def donor_plan(samples, population, seed):
    result = {}
    for sample in samples:
        donors = [r for r in population if r['dataset']==sample['dataset']
            and r['source_group_id']!=sample['source_group_id'] and r['image']['path']!=sample['image']['path']]
        if not donors:
            raise ValueError('No cross-source donor for '+sample['sample_id'])
        donor = min(donors,key=lambda r:fingerprint([seed,'wrong_image',sample['sample_id'],r['sample_id']]))
        result[sample['sample_id']] = dict(donor_id=donor['sample_id'],donor_source_group_id=donor['source_group_id'],seed=seed)
    return result


def expected_controls(samples, donors, seed):
    planned = []
    for sample in samples:
        for condition in ('control_original','control_no_image','control_wrong_image'):
            extra = dict(axis='visual_control')
            if condition=='control_wrong_image':extra.update(donors[sample['sample_id']])
            planned.append(dict(experiment=1,subset='test',sample_id=sample['sample_id'],source_group_id=sample['source_group_id'],
                dataset=sample['dataset'],task_type=sample['task_type'],condition=condition,seed=seed,extra=extra))
    return planned


def run_controls(engine, samples, donors, no_image_support, retry_errors=False):
    from .runner import record_identity
    planned = expected_controls(samples, donors, engine.config['seed'])
    write_json(engine.run_dir/'expected'/('controls_'+fingerprint(planned)+'.json'),dict(records=planned))
    by_id={s['sample_id']:s for s in samples}
    for item in planned:
        path=engine.run_dir/'records'/(fingerprint(record_identity(item))+'.json')
        if path.exists() and (read_json(path)['status']!='error' or not retry_errors):continue
        sample=by_id[item['sample_id']];row=dict(item,model=engine.model_key,run_id=engine.run_id)
        try:
            original=[view(engine.data.image(sample),edge=engine.config['overview_edge'],label='overview')]
            condition=item['condition']
            if condition=='control_no_image' and not no_image_support['supported']:
                row.update(status='skipped',reason='unsupported_no_image_interface',capability=no_image_support)
            elif condition=='control_original':
                row.update(engine.evaluate(sample,original,item['seed'],experiment=1),status='ok')
            else:
                views=[] if condition=='control_no_image' else [view(engine.data.image(engine.data.get(item['extra']['donor_id'])),
                    edge=engine.config['overview_edge'],label='overview')]
                contract=prediction_contract(engine.config,original,1)
                request=prediction_request(sample,views,engine.config,1,
                    structured=bool(engine.backend.spec.get('structured_output')),contract=contract)
                inference=engine.infer(views,question=sample['question'],seed=item['seed'],capture=False,**request)
                prediction=parse_task_prediction(inference['text'],len(views) if request.get('output_schema') else 1,
                    sample['dataset'],contract,finish_reason=inference.get('finish_reason'),schema=request.get('output_schema'))
                scores=score_prediction(prediction,sample,[],[])
                # Native status can be compared with the original question's answer;
                # localization against the original image is undefined under controls.
                for key in ('detection_correct','joint_answer_detection','joint_answer_localization','all_instances_hit',
                            'all_boxes_correct','matches','precision','recall','false_positive'):
                    scores[key]=None
                scores['task_correct']=scores['answer_correct']
                row.update(status='ok',prediction=prediction,scores=scores,attention={},request_id=inference['request_id'],
                    reference=sample['reference'],question=sample['question'],domain=sample.get('domain',''),
                    image=sample['image'],pair_id=sample.get('pair_id'),native_condition=sample['condition'],
                    predicted_boxes=None,evidence_area_fraction=None,min_instance_area_fraction=None,
                    spatial_metrics_applicability='not_applicable_visual_control',
                    prediction_contract=contract,views=inference['request']['views'],
                    costs={k:inference[k] for k in ('input_tokens','output_tokens','spatial_visual_tokens','input_seconds',
                        'inference_seconds','peak_allocated_bytes')})
                finalize_answer_scores(row)
        except Exception as error:
            import traceback
            row.update(status='error',error=repr(error),traceback=traceback.format_exc())
        write_json(path,row)


def summarize_controls(root,rows,repeats):
    from collections import defaultdict
    from .analysis import dump_csv,interval
    paired=defaultdict(dict)
    for row in rows:
        if row.get('extra',{}).get('axis')=='visual_control':
            paired[(row['dataset'],row['sample_id'],row['seed'])][row['condition']]=row
    details=[];groups=defaultdict(list)
    for (dataset,sample_id,seed),conditions in paired.items():
        original=conditions.get('control_original')
        for condition in ('control_no_image','control_wrong_image'):
            other=conditions.get(condition)
            def answer(row):
                return row.get('scores',{}).get('answer_correct') if row and row['status']=='ok' else None
            a,b=answer(original),answer(other)
            ref=original or other
            if ref is None:continue
            entry=dict(dataset=dataset,sample_id=sample_id,seed=seed,source_group_id=ref['source_group_id'],
                baseline='control_original',condition=condition,original_score=a,control_score=b,
                delta=float(b)-float(a) if a is not None and b is not None else None,
                original_execution=original['status'] if original else 'not_run',
                control_execution=other['status'] if other else 'not_run',
                donor=other.get('extra') if other else None)
            details.append(entry);groups[(dataset,condition)].append(entry)
    summary=[]
    for (dataset,condition),group in groups.items():
        estimate=interval([(r['source_group_id'],r['delta']) for r in group],repeats)
        summary.append(dict(dataset=dataset,condition=condition,planned_pairs=len(group),
            scored_pairs=estimate['n'],score_coverage=estimate['n']/len(group) if group else None,
            not_run=sum(r['control_execution']=='not_run' for r in group),
            errors=sum(r['control_execution']=='error' for r in group),
            unsupported_or_skipped=sum(r['control_execution']=='skipped' for r in group),**estimate))
    for name,values in [('visual_control_pairs',details),('visual_control_summary',summary)]:
        write_json(Path(root)/'summary'/(name+'.json'),values);dump_csv(Path(root)/'summary'/(name+'.csv'),values)
