"""One manifest-driven public project entrypoint for E1–E4 and all adapters."""
from pathlib import Path
from collections import Counter, defaultdict
import argparse
import importlib.metadata
import json
import os
import shutil
import sys
import time
from .common import read_json, write_json, fingerprint, file_hash, shard_contains
from .engine import code_fingerprint

ROOT=Path(__file__).resolve().parents[1]
DATASETS=('vistaqa','gseval','groundingme','hallusegbench')


def backend_matches(actual,saved):
    return fingerprint(actual)==fingerprint(saved)


def select_public(data,config,experiment,count=None,pilot_fraction=None):
    from .runner import select_samples
    from .data import prepare_audit
    if count is not None and pilot_fraction is not None:
        raise ValueError('Choose either samples_per_dataset or pilot_fraction')
    if experiment==2:prepare_audit(data,config,'test')
    rows=select_samples(data,config,experiment,'test',datasets=DATASETS,pilot_fraction=pilot_fraction)
    if count is None:return rows
    if not 5 <= count <= 10:raise ValueError('Smoke uses 5–10 sources per dataset')
    result=[]
    for dataset in DATASETS:
        groups=defaultdict(list)
        for row in rows:
            if row['dataset']==dataset:groups[row['source_group_id']].append(row)
        keys=sorted(groups,key=lambda key:fingerprint([config['seed'],'smoke',dataset,key]))[:count]
        if len(keys)!=count:raise ValueError('Insufficient public sources: '+dataset)
        # One original task per source; Hallu expands to its four cells in E3/E4.
        result += [min(groups[key],key=lambda r:r['sample_id']) for key in keys]
    return result


def observations(data,sample,config,experiment,structured=None):
    from .geometry import view,expand_box,box_from_mask
    if experiment==3:
        from .experiment3 import observation_set, request
        _,_,items=observation_set(data,sample,config)
        return [(name,views,request(sample,views)) for name,(views,_) in items.items() if views]
    if experiment==4:
        from .experiment4 import observation_set,request
        return [(name,item['views'],request(sample,item['views'])) for name,item in observation_set(data,sample,config).items() if item['views']]
    from .protocol import prediction_request
    if structured is None:
        structured=bool(config.get('model_defaults',{}).get('structured_output'))
    image=data.image(sample);mask=data.region_mask(sample)
    full=view(image,edge=config['overview_edge'],label='overview');views=[[full]]
    if mask is not None and mask.any():
        crop=view(image,expand_box(box_from_mask(mask),image.size,config['crop_margin']),config['crop_edge'],label='crop')
        views += [[full,crop],[crop]]
        if experiment==2:views.append([full,crop,crop,crop,crop])
    result=[]
    for i,group in enumerate(views):
        request=prediction_request(sample,group,config,experiment,structured=structured)
        result.append((f'view_probe_{i}',group,request))
    return result


def select_controls(samples,count,seed):
    """Pilot controls must come from the selected pilot, not add outside sources."""
    result=[]
    for dataset in DATASETS:
        groups=defaultdict(list)
        for row in samples:
            if row['dataset']==dataset:groups[row['source_group_id']].append(row)
        keys=sorted(groups,key=lambda key:fingerprint([seed,'smoke',dataset,key]))[:count]
        result.extend(min(groups[key],key=lambda r:r['sample_id']) for key in keys)
    return result


def runtime_versions():
    result={}
    for package in ('torch','torchvision','transformers','xgrammar','numpy','Pillow','accelerate','huggingface_hub','matplotlib'):
        try:result[package]=importlib.metadata.version(package)
        except importlib.metadata.PackageNotFoundError:result[package]=None
    return result


def prepare(args):
    from .data import ExperimentData
    from .data_source import resolve_data_root,validate_data_root
    from .__main__ import model_spec
    from .backends import NativeInputs,aligned_question_indices
    config=read_json(args.config);lock=read_json(args.lock)
    data_root=resolve_data_root(args.data_root)
    data=ExperimentData(data_root,args.work_root)
    checked=validate_data_root(data_root,require_snapshot=True,check_assets=True)
    pilot_fraction=getattr(args,'pilot_fraction',None)
    samples=select_public(data,config,args.experiment,args.samples_per_dataset,pilot_fraction)
    from .runner import select_samples
    population=select_samples(data,config,args.experiment,'test',datasets=DATASETS)
    population_groups={name:len({s['source_group_id'] for s in population if s['dataset']==name}) for name in DATASETS}
    selected_groups={name:len({s['source_group_id'] for s in samples if s['dataset']==name}) for name in DATASETS}
    spec=model_spec(config,args.model);checkpoint=lock[args.model]
    if args.model_path:
        checkpoint=dict(checkpoint,local_path=str(Path(args.model_path).resolve()));lock=dict(lock,**{args.model:checkpoint})
    inputs=NativeInputs(spec,checkpoint)
    if spec.get('structured_output'):
        from .structured import structured_metadata
        structured_metadata(spec)
    expanded=samples
    if args.experiment in (3,4):
        from .experiment3 import worlds
        expanded=[w for s in samples for w in worlds(data,s)]
    # Check actual native processor outputs; no Qwen placeholder shortcuts.
    probes=[]
    for sample in expanded:
        for name,views,request in observations(data,sample,config,args.experiment,bool(spec.get('structured_output'))):
            batch,boxes,visual_id,metadata=inputs._inputs(views,request['prompt'],request['system'])
            ids=batch['input_ids'][0].tolist();visual=[i for i,t in enumerate(ids) if t==visual_id]
            queries,mode=aligned_question_indices(inputs.tokenizer,ids,sample['question'],visual)
            if len(ids)>spec['max_input_tokens']:raise ValueError('Processor input exceeds configured bound: '+sample['sample_id'])
            probes.append(dict(sample_id=sample['sample_id'],condition=name,views=len(views),input_tokens=len(ids),
                visual_tokens=len(visual),query_mode=mode,queries=queries,token_boxes=boxes,
                preprocessing=metadata,input_fields=sorted(batch)))
    capability=dict(supported=False,reason='not_tested')
    try:
        _,_,request=observations(data,samples[0],config,args.experiment,bool(spec.get('structured_output')))[0]
        batch,boxes,_,_=inputs._inputs([],request['prompt'],request['system'])
        if boxes or any(k in batch for k in ('pixel_values','image_grid_thw','image_position_ids')):
            raise ValueError('Text-only input still contains vision tensors')
        capability=dict(supported=True,input_fields=sorted(batch))
    except (ValueError,TypeError,KeyError,NotImplementedError) as error:
        capability=dict(supported=False,reason=repr(error))
    expected=[]
    if args.experiment in (3,4):
        if args.experiment==3:
            from .experiment3 import expected as plan
            expected=[r for s in samples for r in plan(data,s,'test',config['seed'])]
        else:
            from .experiment4 import expected as plan
            expected=[r for s in samples for r in plan(data,s,'test',config['seed'],config)]
    elif args.experiment==1:
        from .runner import experiment1_expected
        expected=[r for s in samples for r in experiment1_expected(s,'test',config['seed'])]
    controls=[];donors={}
    if config.get('visual_controls',{}).get('enabled'):
        from .controls import donor_plan
        controls=(select_controls(samples,config['visual_controls']['samples_per_dataset'],config['seed'])
                  if pilot_fraction is not None else select_public(data,config,1,config['visual_controls']['samples_per_dataset']))
        donors=donor_plan(controls,list(data.primary('test')),config['visual_controls']['seed'])
    manifest=dict(version=1,status='cpu_preflight_passed',experiment=args.experiment,model=args.model,config=config,lock=lock,
        code=code_fingerprint(),entrypoint_sha256=file_hash(ROOT/'scripts/project.py'),data=data.fingerprint(),
        data_root=str(data_root),work_root=str(Path(args.work_root).resolve()),output_root=str(Path(args.output_root).resolve()),
        sample_ids=[s['sample_id'] for s in samples],samples_per_dataset=args.samples_per_dataset,
        purpose='pilot_validation' if pilot_fraction is not None else 'smoke_validation_only' if args.samples_per_dataset else 'formal_public_run',
        pilot_fraction=pilot_fraction,pilot_sampling='per_dataset_source_groups_stratified_task_status',
        population_source_groups=population_groups,selected_source_groups=selected_groups,
        datasets=dict(Counter(s['dataset'] for s in samples)),source_groups=len({s['source_group_id'] for s in samples}),
        expected_records=(len(samples)*(34+5*len(config['candidate_counts'])*sum(b>0 for b in config['budgets']))) if args.experiment==2 and not spec['generation']['do_sample'] else len(expected) if expected else None,
        expected_conditions=dict(Counter(r['condition'] for r in expected)),
        e2_plan='32 fixed candidates; nested K=8/16/32; B=1/2/4; proposer and pool shared across models' if args.experiment==2 else None,
        native_processor_checks=len(probes),versions=runtime_versions(),data_validation=checked,
        controls=[s['sample_id'] for s in controls],donors=donors,no_image_interface=capability)
    path=Path(args.manifest).resolve()
    write_json(path,manifest);write_json(path.with_suffix('.processor.json'),probes)
    write_json(path.with_suffix('.expected.json'),dict(records=expected))
    # Copy the precise source used for this run; unlike historical snapshots this
    # is one frozen implementation per code identity, never an import alternative.
    snapshot=Path(manifest['output_root'])/'code'/manifest['code']
    for folder in ('experiments','groundguard_data','third_party'):
        for source in (ROOT/folder).rglob('*.py'):
            dest=snapshot/source.relative_to(ROOT);dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(source,dest)
    print(json.dumps(dict(manifest=str(path),model=args.model,experiment=args.experiment,datasets=manifest['datasets'],
        planned=manifest['expected_records'],cpu_processor_checks=len(probes),pilot_fraction=pilot_fraction,
        population_source_groups=population_groups,selected_source_groups=selected_groups),ensure_ascii=False),flush=True)


def verify(path):
    from .data import ExperimentData
    m=read_json(path)
    if m['code']!=code_fingerprint():raise ValueError('Code changed after preflight; prepare a new manifest')
    data=ExperimentData(m['data_root'],m['work_root'])
    if m['data']!=data.fingerprint():raise ValueError('Data changed after preflight')
    return m,data,[data.get(s) for s in m['sample_ids']]


def gate_path(path):return Path(path).with_suffix('.gpu.json')


def require_gpu_gate(manifest_path, backend):
    gate=gate_path(manifest_path)
    if not gate.exists():raise ValueError('Run gpu-preflight first')
    checked=read_json(gate)
    if not checked['passed'] or checked['manifest_sha256']!=file_hash(manifest_path) or not backend_matches(backend.metadata(),checked['backend']):
        raise ValueError('GPU preflight does not match this manifest/backend')
    if not checked.get('checks') or not all(c['hook_preserves_tokens'] and c['hook_logits_allclose'] for c in checked['checks']):
        raise ValueError('GPU preflight measurements failed')
    return checked


def run(args):
    from .__main__ import model_spec
    from .backends import VisionBackend
    from .engine import Engine
    from .runner import Runner,generate_proposals
    m,data,samples=verify(args.manifest);cfg=m['config'];exp=m['experiment']
    if args.command!='gpu-preflight' and not gate_path(args.manifest).exists():
        raise ValueError('Run gpu-preflight first')
    backend=VisionBackend(model_spec(cfg,m['model']),m['lock'][m['model']])
    gate=gate_path(args.manifest)
    if args.command=='gpu-preflight':
        # A small input audit on real public records; output quality is recorded
        # separately from hook equality. All selected samples run in smoke below.
        sample=next(s for s in samples if s['reference']['regions'])
        checks=[]
        for name,views,request in observations(data,sample,cfg,exp,bool(backend.spec.get('structured_output'))):
            kwargs=dict(views=views,question=sample['question'],seed=cfg['seed'],**request)
            hooked=backend.infer(**kwargs,capture=True);plain=backend.infer(**kwargs,capture=False)
            probe={k:v for k,v in kwargs.items() if k not in ('seed','output_schema')}
            import numpy as np
            a=backend.prefill_logits(**probe,capture=True);b=backend.prefill_logits(**probe,capture=False)
            checks.append(dict(condition=name,hook_preserves_tokens=hooked['output_ids']==plain['output_ids'],
                hook_logits_allclose=bool(np.allclose(a,b,rtol=1e-5,atol=1e-5)),max_logit_difference=float(abs(a-b).max()),
                hooked_peak_bytes=hooked['peak_allocated_bytes'],plain_peak_bytes=plain['peak_allocated_bytes'],
                input_tokens=hooked['input_tokens'],visual_tokens=hooked['spatial_visual_tokens'],
                measured_layers=hooked['layer_names'],unmeasurable_layers=hooked['unmeasurable_layers'],
                query_mode=hooked['query_mode'],head_query_arrays=len(hooked['attention_arrays']),
                seconds=hooked['inference_seconds'],preprocessing=hooked['preprocessing'],token_boxes=hooked['token_boxes']))
        result=dict(manifest_sha256=file_hash(args.manifest),backend=backend.metadata(),checks=checks,
            passed=bool(checks) and all(c['hook_preserves_tokens'] and c['hook_logits_allclose'] for c in checks))
        write_json(gate,result)
        if not result['passed']:raise ValueError('Hook changes model outputs; see '+str(gate))
        print(gate,flush=True);return
    checked=require_gpu_gate(args.manifest,backend)
    engine=Engine(backend,data,m['output_root'],cfg,m['model'])
    write_json(engine.run_dir/'delivery_manifest.json',m)
    write_json(engine.run_dir/'adaptation_validation.json',checked)
    from .completeness import write_shard_plan
    from .controls import expected_controls
    controls=[data.get(s) for s in m['controls']]
    write_shard_plan(engine.run_dir,m,samples,controls,args.shards)
    # Global expected conditions must exist even when another shard never starts.
    write_json(engine.run_dir/'expected/delivery_main.json',
               read_json(Path(args.manifest).with_suffix('.expected.json')))
    write_json(engine.run_dir/'expected/delivery_controls.json',
               dict(records=expected_controls(controls,m['donors'],cfg['seed'])))
    samples=[s for s in samples if shard_contains(s['source_group_id'],args.shard_index,args.shards)]
    write_json(engine.run_dir/f'selection_e{exp}_test_shard{args.shard_index}of{args.shards}.json',
        dict(experiment=exp,subset='test',sample_ids=[s['sample_id'] for s in samples],shards=args.shards,shard_index=args.shard_index))
    if args.command=='propose':
        if m['model']!=cfg['proposer']:raise ValueError('Use a manifest for the frozen proposer '+cfg['proposer'])
        errors=generate_proposals(engine,samples,'test',args.retry_errors)
        if errors:raise ValueError('Proposal errors: '+str(errors))
    else:
        failures=Runner(engine,'test',args.retry_errors).run(exp,samples)
        if m['controls']:
            from .controls import run_controls
            controls=[s for s in controls if shard_contains(s['source_group_id'],args.shard_index,args.shards)]
            run_controls(engine,controls,m['donors'],m['no_image_interface'],args.retry_errors)
        from .analysis import summarize
        summary=summarize(engine.run_dir,cfg)
        complete=read_json(summary/'completeness.json')
        local=next(s for s in complete['shard_completion'] if s['experiment']==exp
                   and s['shards']==args.shards and s['shard_index']==args.shard_index)
        write_json(Path(args.manifest).with_suffix(f'.run_shard{args.shard_index}.json'),dict(run_dir=str(engine.run_dir),model=m['model'],experiment=exp,
            inference_complete=complete['inference_complete'],
            shard_inference_complete=local['inference_complete'],shards=args.shards,shard_index=args.shard_index))
        if any(failures.values()) or local['incomplete_record_files']:raise ValueError('Inference failures saved; resume with --retry-errors')
    print(engine.run_dir,flush=True)


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('command',choices=['prepare','gpu-preflight','propose','run','summarize','judge','export'])
    p.add_argument('--manifest',default='work/public/manifest.json')
    p.add_argument('--experiment',type=int,choices=(1,2,3,4),default=1)
    p.add_argument('--model',default='qwen35_9b');p.add_argument('--config',default='configs/public_e1.json')
    p.add_argument('--lock',default='configs/models.public.lock.json');p.add_argument('--model-path')
    p.add_argument('--data-root');p.add_argument('--work-root',default='work/public');p.add_argument('--output-root',default='outputs/public')
    from .__main__ import fraction_arg
    selection=p.add_mutually_exclusive_group()
    selection.add_argument('--samples-per-dataset',type=int,choices=range(5,11))
    selection.add_argument('--pilot-fraction',type=fraction_arg,
        help='Stratified fraction of source groups per dataset; E2 uses its fixed audit pool')
    p.add_argument('--shards',type=int,default=1);p.add_argument('--shard-index',type=int,default=0)
    p.add_argument('--retry-errors',action='store_true');p.add_argument('--run-dir');p.add_argument('--destination')
    p.add_argument('--execute',action='store_true',help='Execute configured remote semantic judge')
    args=p.parse_args()
    if args.shards<1 or not 0<=args.shard_index<args.shards:p.error('Invalid shard index/count')
    if args.command=='prepare':prepare(args)
    elif args.command in ('gpu-preflight','propose','run'):run(args)
    else:
        if not args.run_dir:p.error('--run-dir required')
        root=Path(args.run_dir)
        if args.command=='judge':
            sys.path.insert(0,str(ROOT/'scripts'))
            from judge_public import judge
            judge(root,args.execute)
        else:
            from .analysis import summarize
            out=summarize(root,read_json(root/'experiment_config.json'))
            if args.command=='export':
                if not args.destination:p.error('--destination required for export')
                dest=Path(args.destination)
                if dest.exists():raise FileExistsError(dest)
                dest.mkdir(parents=True)
                for name in ('summary','records','judgments','candidate_pools','expected','progress','source_errors','figures'):
                    if (root/name).exists():shutil.copytree(root/name,dest/name)
                for source in root.glob('*.json'):shutil.copy2(source,dest/source.name)
                write_json(dest/'export_identity.json',dict(source=str(root.resolve()),analysis_code=code_fingerprint(),
                    files={str(f.relative_to(dest)):file_hash(f) for f in dest.rglob('*') if f.is_file()}))
                print(dest)
            else:print(out)


if __name__=='__main__':main()
