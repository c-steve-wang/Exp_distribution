"""E4 public-data protocol: factual four cells, native resolution, and region rescue."""
from .common import rng_for
from .geometry import view, box_from_mask, expand_box, matched_control_box

FACT_CONDITIONS = ('fact_baseline', 'fact_region', 'fact_control')
HALLU_CELLS = {'factual_original', 'factual_replacement',
               'counterfactual_original', 'counterfactual_replacement'}


def enabled(config):
    return config.get('experiment4_measurement', {}).get('version') == 1


def worlds(data, sample):
    if sample['dataset'] == 'synthetic':
        raise ValueError('E4 v1 covers public data; synthetic I0 remains deferred')
    if sample['dataset'] != 'hallusegbench':
        return [sample]
    pair = data.pair(sample)
    if set(pair) != HALLU_CELLS:
        raise ValueError('E4 requires all four HalluSegBench cells')
    return [pair[k] for k in sorted(pair)]


def resolution_edges(sample, config):
    longest = max(sample['image']['width'], sample['image']['height'])
    edges = {e for e in config['resolutions'] if e <= longest}
    if longest < max(config['resolutions']):
        edges.add(longest)
    return sorted(edges)


def common_edge(pair, config):
    return min(config['overview_edge'],
               *(max(w['image']['width'], w['image']['height']) for w in pair))


def expected(data, sample, subset, seed, config):
    pair = worlds(data, sample)
    shared = common_edge(pair, config)
    result = []
    for world in pair:
        longest = max(world['image']['width'], world['image']['height'])
        conditions = [(f'resolution_{edge}', dict(resolution=edge,
            native_long_edge=longest, complete_three_way=longest >= max(config['resolutions']),
            axis='resolution')) for edge in resolution_edges(world, config)]
        if world['dataset'] == 'hallusegbench':
            conditions += [(name, dict(resolution=shared, axis='fact')) for name in FACT_CONDITIONS]
        for condition, extra in conditions:
            result.append(dict(experiment=4, subset=subset, sample_id=world['sample_id'],
                condition=condition, seed=seed, extra=extra, source_group_id=world['source_group_id'],
                dataset=world['dataset'], task_type=world['task_type'], pair_id=world.get('pair_id'),
                native_condition=world['condition'], reference=world['reference'], image=world['image']))
    return result


def request(sample, views):
    # Reuse the tested task schema and original-image localization contract.
    # E4 has no hidden-pixel intervention, so omit the E3-specific caution.
    from .experiment3 import request as full_image_request
    result = full_image_request(sample, views)
    result['prompt'] = result['prompt'].replace('A hidden region is not proof that a target is absent.\n', '\n')
    return result


def observation_set(data, sample, config):
    """Build this world's observations. Pair geometry never enters model prompts."""
    image = data.image(sample)
    if image.size != (sample['image']['width'], sample['image']['height']):
        raise ValueError('Image dimensions differ from frozen manifest')
    observations = {}
    for edge in resolution_edges(sample, config):
        observations[f'resolution_{edge}'] = dict(
            views=[view(image, edge=edge, label='overview')], skip=None,
            metadata=dict(axis='resolution', requested_long_edge=edge, no_source_upsampling=True))
    if sample['dataset'] != 'hallusegbench':
        return observations
    edge = common_edge(worlds(data, sample), config)
    overview = view(image, edge=edge, label='overview')
    baseline = dict(axis='fact', common_long_edge=edge,
        region_scope='author_target_or_replacement_region_not_complete_reasoning_support')
    observations['fact_baseline'] = dict(views=[overview], skip=None, metadata=baseline)
    regions = sample.get('intervention_regions') or sample['reference']['regions']
    region_sample = dict(sample, reference=dict(sample['reference'], region_kind='mask', regions=regions))
    mask = data.region_mask(region_sample)
    if not regions or mask is None or not mask.any():
        raise ValueError('Hallu fact rescue requires a nonempty target/replacement region')
    box = expand_box(box_from_mask(mask), image.size, config['crop_margin'])
    crop = view(image, box, config['crop_edge'], label='region_crop')
    # Both queries on the same image receive the same geometry and random control.
    control = matched_control_box(box, mask, rng_for(config['seed'], 'e4_control',
        sample['pair_id'], sample['image']['path']))
    geometry = dict(baseline, region_crop_box=box,
        crop_image_area_fraction=(box[2]-box[0])*(box[3]-box[1])/(image.width*image.height),
        crop_input_long_edge=config['crop_edge'], annotation_assisted=True)
    observations['fact_region'] = dict(views=[overview, crop], skip=None, metadata=geometry)
    observations['fact_control'] = dict(
        views=[overview, view(image, control, config['crop_edge'], label='control_crop')] if control else [],
        skip=None if control else 'No same-size control crop with at most 5% region overlap',
        metadata=dict(geometry, control_crop_box=control))
    return observations


def run(runner, sample):
    planned = expected(runner.data, sample, runner.subset, runner.cfg['seed'], runner.cfg)
    by_id = {w['sample_id']: w for w in worlds(runner.data, sample)}
    observations = {}
    for item in planned:
        sid = item['sample_id']
        if sid not in observations:
            observations[sid] = observation_set(runner.data, by_id[sid], runner.cfg)
        observation = observations[sid][item['condition']]
        runner.job(4, by_id[sid], item['condition'], observation['views'], item['seed'],
            extra=item['extra'], skip=observation['skip'], metadata=observation['metadata'])
