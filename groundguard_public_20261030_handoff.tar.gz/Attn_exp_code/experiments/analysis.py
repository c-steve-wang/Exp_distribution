"""Dataset-separated summaries and paired source-cluster bootstrap intervals."""
from collections import defaultdict
from pathlib import Path
import csv
import json
import numpy as np
from .common import read_json, write_json, fingerprint
from .metrics import LOCALIZATION_METRICS, score_value, rank_correlation, normalize_answer, project_mass, finalize_answer_scores
from .judge import prediction_text


def load_records(run_dir):
    root = Path(run_dir)
    rows = []
    for path in sorted((root / 'records').glob('*.json')):
        row = read_json(path)
        judgment = root / 'judgments' / path.name
        if (row['status'] == 'ok' and row['dataset'] == 'vistaqa'
                and row['scores'].get('format_valid', False) and judgment.exists()):
            result = read_json(judgment)
            compatible = (row['prediction']['status'] != 'UNKNOWN'
                          or result.get('prediction_text') == prediction_text(row))
            if row.get('prediction_contract', {}).get('protocol') in {'experiment3_v1', 'experiment4_v1'}:
                from .common import file_hash
                judge_path = root / 'judge.json'
                compatible = (compatible and result.get('input_record_sha256') == file_hash(path)
                              and judge_path.exists() and result.get('judge_id') == read_json(judge_path))
            if result['status'] == 'ok' and compatible:
                row['scores']['answer_correct'] = bool(result['correct'])
                row['scores']['task_correct'] = bool(result['correct'])
                row['scores']['joint_answer_detection'] = bool(result['correct'] and row['scores']['detection_correct']
                                                               and row['scores']['concrete_answer'])
        finalize_answer_scores(row)
        row['record_file'] = path.name
        rows.append(row)
    # Interrupted jobs must remain visible, even if they never wrote a result.
    from .runner import record_identity
    existing = {row['record_file'] for row in rows}
    for manifest in sorted((root / 'expected').glob('*.json')):
        for expected in read_json(manifest)['records']:
            name = fingerprint(record_identity(expected)) + '.json'
            if name not in existing:
                rows.append(dict(expected, status='not_run', record_file=name))
                existing.add(name)
    return rows


def interval(pairs, repeats=1000, seed=42):
    """Resample whole source groups; keep all rows/conditions of a sampled source."""
    grouped = defaultdict(list)
    for source, value in pairs:
        if value is not None:
            grouped[source].append(float(value))
    if not grouped:
        return dict(mean=None, low=None, high=None, n=0, source_groups=0)
    keys = sorted(grouped)
    sums = np.array([sum(grouped[k]) for k in keys])
    counts = np.array([len(grouped[k]) for k in keys])
    if len(keys) == 1:
        average = float(sums.sum() / counts.sum())
        return dict(mean=average, low=average, high=average, n=int(counts.sum()), source_groups=1)
    rng = np.random.default_rng(seed)
    samples = []
    for _ in range(repeats):
        indices = rng.integers(0, len(keys), len(keys))
        samples.append(float(sums[indices].sum() / counts[indices].sum()))
    return dict(mean=float(sums.sum() / counts.sum()), low=float(np.quantile(samples, .025)),
                high=float(np.quantile(samples, .975)), n=int(counts.sum()), source_groups=len(keys))


def value(row, key):
    if key == 'execution_success':
        return None if row['status'] == 'skipped' else row['status'] == 'ok'
    if row['status'] != 'ok':
        return False if row['status'] == 'error' and key in {'task_correct', 'answer_correct', 'detection_correct', 'joint_answer_detection', 'format_valid', 'concrete_answer', 'supported_concrete_answer', 'unknown', 'all_instances_hit', 'all_boxes_correct', 'precision', 'recall'} else None
    if key == 'unknown':
        return row['prediction']['status'] == 'UNKNOWN'
    if key == 'attention.coverage_10':
        return row['attention'].get('coverage', {}).get('0.1')
    if key.startswith('attention.'):
        return row['attention'].get(key.split('.', 1)[1])
    return score_value(row['scores'], key)


def mean_component(records, key):
    if any(r['status'] != 'ok' for r in records):
        return None
    values = [value(r, key) for r in records]
    return None if not values or any(v is None for v in values) else float(np.mean(values))


def action_audits(root, rows):
    indexed = defaultdict(list)
    for row in rows:
        if row['experiment'] == 2:
            indexed[(row['subset'], row['sample_id'])].append(row)
    result = []
    for path in sorted((Path(root) / 'audits').glob('*.json')):
        audit = read_json(path)
        records = indexed[(audit['subset'], audit['sample_id'])]
        if audit.get('candidate_pool') and any(r['extra'].get('candidate_pool') != audit['candidate_pool'] for r in records):
            raise ValueError('Mixed candidate pools in experiment 2 records')
        baseline = [r for r in records if r['extra'].get('stage') == 'baseline']
        confirmation_base = {r['seed']: r for r in records if r['extra'].get('stage') == 'confirmation_baseline'}
        actions = {i: [r for r in records if r['extra'].get('stage') == 'candidate' and r['extra']['candidate'] == i] for i in range(32)}
        components = ['detection_correct'] if audit['dataset'] in {'gseval', 'groundingme'} else ['answer_correct', 'detection_correct']
        components += list(LOCALIZATION_METRICS)
        if audit['dataset'] == 'vistaqa':
            components += ['joint_answer_localization']
        if audit['dataset'] == 'synthetic':
            components += ['utility_w', 'utility_u']
            truth = set(next(r['reference']['facts'] for r in records if r['status'] == 'ok'))
            for i, calls in actions.items():
                for call in calls:
                    if call['status'] != 'ok':
                        continue
                    seed = str(call['seed'])
                    h0 = audit['facts']['h0'].get(seed)
                    after = audit['facts']['actions'].get(f'{seed}:{i}')
                    if h0 and after and h0['parse_error'] is None and after['parse_error'] is None:
                        new = len((set(after['facts']) & truth) - set(h0['facts']))
                        call['scores']['new_cue'] = new
                        if call['scores'].get('utility_w') is not None:
                            call['scores']['utility_u'] = call['scores']['utility_w'] + new
            for base in baseline:
                if base['status'] == 'ok':
                    base['scores']['utility_u'] = base['scores'].get('utility_w')
            for call in records:
                if call['status'] != 'ok':
                    continue
                if call['extra'].get('stage') == 'confirmation_baseline':
                    call['scores']['utility_u'] = call['scores'].get('utility_w')
                elif call['extra'].get('stage') == 'confirmation':
                    seed, i = str(call['seed']), call['extra']['chosen'][0]
                    h0 = audit['facts'].get('confirmation_h0', {}).get(seed)
                    after = audit['facts'].get('confirmation_actions', {}).get(f'{seed}:{i}')
                    if h0 and after and h0['parse_error'] is None and after['parse_error'] is None:
                        new = len((set(after['facts']) & truth) - set(h0['facts']))
                        call['scores']['utility_u'] = call['scores']['utility_w'] + new
        if audit['dataset'] == 'synthetic':
            for call in records:
                if call['extra'].get('stage') == 'selected' and call['extra']['budget'] == 1 and call['status'] == 'ok':
                    candidate = next((r for r in actions[call['extra']['chosen'][0]]
                                      if r['seed'] == call['seed'] and r.get('request_id') == call.get('request_id')), None)
                    if candidate and candidate.get('scores', {}).get('utility_u') is not None:
                        call['scores']['utility_u'] = candidate['scores']['utility_u']
        from .action_analysis import outcomes
        result.extend(outcomes(audit, records, baseline, actions, confirmation_base, components))
    return result


def dump_csv(path, rows):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        path.write_text('')
        return
    keys = sorted(set().union(*(row.keys() for row in rows)))
    with path.open('w', newline='') as file:
        writer = csv.DictWriter(file, keys)
        writer.writeheader()
        for row in rows:
            writer.writerow({k: json.dumps(v, ensure_ascii=False) if isinstance(v, (dict, list)) else v for k, v in row.items()})


def summarize(run_dir, config):
    root = Path(run_dir)
    if read_json(root / 'run.json')['config'] != fingerprint(config):
        raise ValueError('Use the same frozen experiment config as this run')
    rows = load_records(root)
    from .paper_analysis import refresh_attention, summarize_paper
    attention_audit = refresh_attention(root, rows)
    repeats = config['bootstrap_repeats']
    pending_vistaqa = any(r['status'] == 'ok' and r['dataset'] == 'vistaqa'
        and r['scores'].get('format_valid') and r['scores'].get('answer_correct') is None for r in rows)
    groups = defaultdict(list)
    for row in rows:
        cohorts = ['available']
        if row['experiment'] == 4 and row.get('extra', {}).get('complete_three_way'):
            cohorts.append('complete_three_way')
        for cohort in cohorts:
            groups[(row['subset'], row['experiment'], row['dataset'], row['condition'], cohort)].append(row)
    summaries = []
    stratified, macro = [], []
    metrics = ['execution_success', 'task_correct', 'answer_correct', 'detection_correct', 'joint_answer_detection',
        'precision', 'recall', *LOCALIZATION_METRICS, 'joint_answer_localization', 'exact_answer_match', 'format_valid',
        'concrete_answer', 'unknown', 'false_positive', 'supported_concrete_answer', 'unsupported_concrete_answer',
        'attention.spatial_visual_mass', 'attention.evidence_mass', 'attention.enrichment', 'attention.peak_hit', 'attention.coverage_10']
    for (subset, experiment, dataset, condition, cohort), group in sorted(groups.items()):
        for key in metrics:
            if dataset in {'gseval', 'groundingme'} and key == 'answer_correct':
                continue
            eligible = [r for r in group if key != 'unsupported_concrete_answer' or r.get('scores', {}).get('concrete_answer')]
            estimate = interval([(r['source_group_id'], value(r, key)) for r in eligible], repeats)
            if dataset == 'vistaqa' and pending_vistaqa and key in {'answer_correct', 'task_correct', 'joint_answer_detection'}:
                estimate = dict(mean=None, low=None, high=None, n=0, source_groups=0, semantic_scoring_pending=True)
            summaries.append(dict(subset=subset, experiment=experiment, dataset=dataset, condition=condition, cohort=cohort, metric=key,
                eligible_records=len(eligible), metric_denominator=estimate['n'],
                metric_coverage=estimate['n']/len(eligible) if eligible else None,
                format_errors=sum(r['status']=='ok' and not r['scores'].get('format_valid') for r in group),
                pending_judge=sum(r['status']=='ok' and r['dataset']=='vistaqa' and r['scores'].get('format_valid')
                    and r['scores'].get('answer_correct') is None for r in group),
                attempted=len(group), errors=sum(r['status'] == 'error' for r in group),
                skipped=sum(r['status'] == 'skipped' for r in group), not_run=sum(r['status'] == 'not_run' for r in group), **estimate))
            if key not in {'task_correct', 'detection_correct', 'attention.enrichment', 'attention.peak_hit'}:
                continue
            subgroups = defaultdict(list)
            for row in group:
                labels = ['task:' + row['task_type']]
                if row['status'] == 'ok':
                    area = row['min_instance_area_fraction']
                    labels += ['area:' + ('unmeasured' if area is None else 'empty' if area == 0 else 'small' if area < .01 else 'medium' if area < .1 else 'large'),
                               'instances:' + str(len(row['reference']['regions'])), 'annotation:' + row['reference']['region_kind']]
                for label in labels:
                    subgroups[label].append(row)
            task_means = []
            for label, subgroup in sorted(subgroups.items()):
                estimate = interval([(r['source_group_id'], value(r, key)) for r in subgroup], repeats)
                stratified.append(dict(subset=subset, experiment=experiment, dataset=dataset, condition=condition,
                                       cohort=cohort, metric=key, stratum=label, **estimate))
                if label.startswith('task:'):
                    task_means.append(estimate['mean'])
            macro.append(dict(subset=subset, experiment=experiment, dataset=dataset, condition=condition, cohort=cohort,
                metric=key, task_types=len(task_means), macro_mean=float(np.mean(task_means)) if task_means and all(v is not None for v in task_means) else None))
    # Conditional diagnostics never replace the primary metrics above.
    valid_summaries, output_quality = [], []
    for (subset, experiment, dataset, condition, cohort), group in sorted(groups.items()):
        if cohort != 'available':
            continue
        generated = [r for r in group if r['status'] == 'ok']
        valid = [r for r in generated if r['scores']['format_valid']]
        invalid_count = len(generated) - len(valid)
        dimensions = dict(subset=subset, experiment=experiment, dataset=dataset, condition=condition)
        output_quality.append(dict(**dimensions, records=len(group), generated=len(generated),
            valid_outputs=len(valid), format_errors=invalid_count,
            format_error_rate=invalid_count / len(generated) if generated else None,
            inference_errors=sum(r['status'] == 'error' for r in group),
            not_run=sum(r['status'] == 'not_run' for r in group),
            skipped=sum(r['status'] == 'skipped' for r in group)))
        for metric in metrics:
            if dataset in {'gseval', 'groundingme'} and metric == 'answer_correct':
                continue
            eligible = [r for r in valid if metric != 'unsupported_concrete_answer'
                        or r['scores'].get('concrete_answer')]
            estimate = interval([(r['source_group_id'], value(r, metric)) for r in eligible], repeats)
            valid_summaries.append(dict(**dimensions, cohort='valid_outputs', metric=metric,
                generated=len(generated), valid_outputs=len(valid), excluded_format_errors=invalid_count,
                planned_records=len(group), valid_output_coverage=len(valid)/len(group) if group else None,
                unscored=len(eligible) - estimate['n'], **estimate))
    format_failures = [dict(experiment=r['experiment'], subset=r['subset'], dataset=r['dataset'],
        sample_id=r['sample_id'], condition=r['condition'], record_file=r['record_file'],
        error=r['prediction'].get('parse_error') or 'Status is not allowed for this task',
        raw_output_file='cache/' + r['request_id'] + '.json' if r.get('request_id') else None)
        for r in rows if r['status'] == 'ok' and not r['scores']['format_valid']]
    # Conditions use exactly matched sample/seed pairs; missing baseline or scores remain visible in counts.
    pairs = defaultdict(dict)
    for row in rows:
        if row['experiment'] in [1, 2, 3, 4] and not (row['experiment'] == 4 and config.get('experiment4_measurement')) and row.get('extra', {}).get('stage') not in {'confirmation', 'confirmation_baseline'}:
            pairs[(row['subset'], row['experiment'], row['dataset'], row['sample_id'], row['seed'])][row['condition']] = row
    differences = defaultdict(list)
    valid_differences = defaultdict(list)
    joint = []
    for (subset, experiment, dataset, sample_id, seed), conditions in pairs.items():
        base_name = {1: 'overview', 2: 'overview', 3: 'visible', 4: f'resolution_{min(config["resolutions"])}'}[experiment]
        base = conditions.get(base_name)
        for name, row in conditions.items():
            if row['status'] == 'ok':
                joint.append(dict(subset=subset, experiment=experiment, dataset=dataset, sample_id=sample_id,
                    source_group_id=row['source_group_id'], condition=name, seed=seed,
                    attention_hit=value(row, 'attention.peak_hit'), detection=value(row, 'detection_correct'),
                    answer=value(row, 'answer_correct'), task_type=row['task_type'],
                    area_fraction=row['evidence_area_fraction'], instances=len(row['reference']['regions']),
                    region_kind=row['reference']['region_kind']))
            baselines = [(base_name, base)]
            if experiment == 1 and name == 'overview_evidence':
                baselines.append(('overview_control', conditions.get('overview_control')))
            for comparison_name, comparison in baselines:
                if (not comparison or name == comparison_name or comparison['status'] == 'skipped'
                        or row['status'] == 'skipped'):
                    continue
                for metric in ['task_correct', 'answer_correct', 'detection_correct', 'joint_answer_detection',
                               'precision', 'recall', *LOCALIZATION_METRICS, 'joint_answer_localization',
                               'attention.evidence_mass', 'attention.enrichment', 'attention.coverage_10']:
                    if dataset == 'vistaqa' and pending_vistaqa and metric in {'answer_correct', 'task_correct', 'joint_answer_detection'}:
                        continue
                    a, b = value(comparison, metric), value(row, metric)
                    if a is not None and b is not None:
                        if dataset in {'gseval', 'groundingme'} and metric == 'answer_correct':
                            continue
                        cohort = 'complete_three_way' if row.get('extra', {}).get('complete_three_way') else 'other_sources'
                        key = (subset, experiment, dataset, comparison_name, name, cohort, metric)
                        collections = [differences]
                        if (comparison['status'] == row['status'] == 'ok'
                                and comparison['scores']['format_valid'] and row['scores']['format_valid']):
                            collections.append(valid_differences)
                        for collection in collections:
                            collection[key].append((row['source_group_id'], float(b) - float(a)))
                            if metric.endswith('correct'):
                                if not a:
                                    collection[(*key[:-1], metric + '.repair')].append((row['source_group_id'], b))
                                if a:
                                    collection[(*key[:-1], metric + '.degrade')].append((row['source_group_id'], not b))
    paired = [dict(subset=k[0], experiment=k[1], dataset=k[2], baseline=k[3], condition=k[4], cohort=k[5], metric=k[6],
                   **interval(v, repeats)) for k, v in sorted(differences.items())]
    valid_paired = [dict(subset=k[0], experiment=k[1], dataset=k[2], baseline=k[3], condition=k[4],
        cohort=k[5], metric=k[6], format_filter='both_conditions_valid', **interval(v, repeats))
        for k, v in sorted(valid_differences.items())]
    cf = counterfactual_pairs(rows, root)
    audits = action_audits(root, rows)
    from .action_analysis import action_tables
    action_outputs = action_tables(audits, repeats)
    derived = defaultdict(list)
    for row in audits:
        for metric in ['proposal_gap', 'selection_gap', 'normalized_regret', 'spearman', 'best_action_hit', 'all_equal', 'selected_gain', 'confirmation_gain_mean']:
            if row.get(metric) is not None:
                derived[(row['subset'], row['dataset'], row['k'], row['policy'], row['component'], metric)].append((row['source_group_id'], row[metric]))
    audit_summary = [dict(subset=k[0],dataset=k[1],k=k[2],policy=k[3],component=k[4],metric=k[5],**interval(v,repeats)) for k,v in sorted(derived.items())]
    cf_groups = defaultdict(list)
    for row in cf:
        for metric in ['both_correct','same_answer','stale_answer','intervention_attention_delta','i0_attention_js']:
            cf_groups[(row['subset'],row['dataset'],row['resolution'],row['left'],row['right'],metric)].append((row['source_group_id'],row[metric]))
    cf_summary = [dict(subset=k[0],dataset=k[1],resolution=k[2],left=k[3],right=k[4],metric=k[5],**interval(v,repeats)) for k,v in sorted(cf_groups.items())]
    output = root / 'summary'
    costs = []
    for (subset, experiment, dataset, condition, cohort), group in sorted(groups.items()):
        if cohort != 'available':
            continue
        measured = [r for r in group if r['status'] == 'ok' and r.get('costs')]
        if not measured:
            continue
        entry = dict(subset=subset, experiment=experiment, dataset=dataset, condition=condition, records=len(measured))
        for key in ['input_tokens', 'output_tokens', 'spatial_visual_tokens', 'input_seconds', 'inference_seconds']:
            values = [r['costs'][key] for r in measured]
            entry[key + '_mean'] = float(np.mean(values))
            entry[key + '_p95'] = float(np.quantile(values, .95))
        entry['max_device_peak_allocated_bytes'] = max(
            (n for r in measured for n in r['costs']['peak_allocated_bytes']), default=0)
        entry['note'] = 'Per-request measurements; cached requests must not be summed as new GPU wall time.'
        costs.append(entry)
    for name, items in [('metrics', summaries), ('paired_changes', paired), ('joint_attention_detection_answer', joint),
                        ('valid_output_metrics', valid_summaries), ('output_quality', output_quality),
                        ('paired_changes_valid_outputs', valid_paired), ('format_failures', format_failures),
                        ('inference_costs', costs),
                        ('stratified_metrics', stratified), ('task_macro_averages', macro),
                        ('action_audits', audits), ('action_summary',audit_summary),
                        ('counterfactual_pairs', cf), ('counterfactual_summary',cf_summary)]:
        dump_csv(output / (name + '.csv'), items)
        write_json(output / (name + '.json'), items)
    for name, items in action_outputs.items():
        dump_csv(output / (name + '.csv'), items)
        write_json(output / (name + '.json'), items)
    errors = [read_json(p) for p in (root / 'source_errors').glob('*.json')]
    from .completeness import source_completeness
    completion = source_completeness(root, rows, errors)
    pending = sum(r['status'] == 'ok' and r['dataset'] == 'vistaqa' and r['scores']['task_correct'] is None for r in rows)
    behavior_note = ('For E1, e1_valid_metrics and e1_paired_valid_changes are the valid-output mechanism tables; '
                     'metrics and paired_changes retain all-attempt sensitivity diagnostics. '
                     if config.get('experiment1_measurement') else
                     'Invalid outputs remain failures in primary accuracy metrics; valid_output_metrics and '
                     'paired_changes_valid_outputs are conditional diagnostics. ')
    if config.get('experiment4_measurement'):
        behavior_note = ('For E4, e4_* tables use valid-output behavior and all measured prefill attention; '
                         'all_attempts is a separate sensitivity cohort. See e4_analysis_policy.json. ')
    write_json(output / 'completeness.json', dict(records=len(rows), source_errors=errors,
        **completion, vistaqa_judgments_pending=pending,
        expected_records_not_run=[r['record_file'] for r in rows if r['status'] == 'not_run'],
        inference_errors=sum(r['status'] == 'error' for r in rows), skipped=sum(r['status'] == 'skipped' for r in rows),
        format_errors=sum(r['status'] == 'ok' and not r['scores']['format_valid'] for r in rows),
        note='Intervals cluster by source_group_id. Datasets are never pooled. '+behavior_note+
             'Pending semantic scores are not exact-match substitutes.'))
    from .engine import code_fingerprint
    write_json(output / 'analysis_identity.json', dict(code=code_fingerprint(), config=fingerprint(config)))
    if config.get('experiment1_measurement'):
        from .experiment1_measurement import summarize_experiment1
        summarize_experiment1(root, rows, config)
    if config.get('experiment3_measurement'):
        from .experiment3_analysis import summarize_experiment3
        summarize_experiment3(root, rows, config)
    if config.get('experiment4_measurement'):
        from .experiment4_analysis import summarize_experiment4
        summarize_experiment4(root, rows, config)
    summarize_paper(root, rows, config, attention_audit)
    return output


def counterfactual_pairs(rows, root):
    grouped = defaultdict(dict)
    for row in rows:
        if (row['experiment'] == 4 and row.get('pair_id')
                and row.get('extra', {}).get('axis') not in {'fact', 'resolution'}):
            grouped[(row['subset'], row['dataset'], row['pair_id'], row['extra']['resolution'], row['seed'])][row['native_condition']] = row
    output = []
    for (subset, dataset, pair, resolution, seed), group in sorted(grouped.items()):
        comparisons = [('I_plus', 'I_minus'), ('I_plus', 'I_zero')] if dataset == 'synthetic' else [
            ('factual_original', 'counterfactual_original'), ('counterfactual_replacement', 'factual_replacement'),
            ('factual_original', 'factual_replacement'), ('counterfactual_original', 'counterfactual_replacement')]
        for a, b in comparisons:
            if a not in group or b not in group:
                continue
            left, right = group[a], group[b]
            joint = value(left, 'task_correct'), value(right, 'task_correct')
            valid = left['status'] == right['status'] == 'ok'
            if dataset == 'hallusegbench':
                unchanged = valid and left['prediction']['status'] == right['prediction']['status']
            else:
                unchanged = valid and (left['prediction']['status'], normalize_answer(left['prediction']['answer'])) == (right['prediction']['status'], normalize_answer(right['prediction']['answer']))
            output.append(dict(subset=subset, dataset=dataset, pair_id=pair, source_group_id=left['source_group_id'],
                resolution=resolution, seed=seed, left=a, right=b, observations_complete=valid,
                both_correct=all(joint) if all(x is not None for x in joint) else None,
                same_answer=unchanged if valid else None,
                stale_answer=bool(joint[0] and not joint[1] and unchanged) if valid and b != 'I_zero' else None,
                intervention_attention_delta=None, i0_attention_js=None))
            if valid:
                masses = [r['attention'].get('intervention_region', {}).get('region_mass') for r in [left, right]]
                if all(m is not None for m in masses):
                    output[-1]['intervention_attention_delta'] = masses[1] - masses[0]
                if dataset == 'synthetic' and b == 'I_zero':
                    output[-1]['i0_attention_js'] = spatial_js(left, right, root)
    return output


def spatial_js(left, right, root):
    size = (left['image']['width'], left['image']['height'])
    if size != (right['image']['width'], right['image']['height']):
        return None
    maps = []
    for row in [left, right]:
        inference = read_json(Path(root) / 'cache' / (row['request_id'] + '.json'))
        with np.load(Path(root) / 'cache' / inference['attention_file'], allow_pickle=False) as arrays:
            weights = arrays['layer_weights'].mean(axis=0)
        if weights.sum() <= 0:
            return None
        maps.append(project_mass(weights / weights.sum(), inference['token_boxes'], size).ravel())
    midpoint = (maps[0] + maps[1]) / 2
    distance = 0.
    for p in maps:
        valid = p > 0
        distance += .5 * float((p[valid] * np.log2(p[valid] / midpoint[valid])).sum())
    return max(0., distance)
