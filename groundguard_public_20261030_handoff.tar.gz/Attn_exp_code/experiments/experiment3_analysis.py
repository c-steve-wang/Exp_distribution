"""E3 matched estimands, independent localization and explicit missing denominators."""
from collections import Counter, defaultdict
from pathlib import Path
from .common import write_json

CONTRASTS = (('visible', 'hidden_evidence'), ('hidden_control', 'hidden_evidence'),
             ('hidden_control', 'hidden_attention'), ('hidden_evidence', 'hidden_reveal'),
             ('visible', 'hidden_reveal'))
METRICS = ('localization_correct', 'localization_recall_correct', 'answer_correct',
           'joint_localization_answer', 'coverage', 'unknown', 'false_positive',
           'false_existence_assertion', 'negative_answer_error', 'status_box_inconsistent',
           'attention_enrichment', 'attention_coverage10', 'attention_peak_hit',
           'attention_peak_plateau_hit', 'vcc', 'uar')


def valid(row):
    return row.get('status') == 'ok' and row.get('scores', {}).get('format_valid', False)


def metric(row, key, cohort='valid_outputs'):
    if not row or row['status'] in {'skipped', 'not_run'}:
        return None
    ref = row.get('reference', {})
    positive = bool(ref.get('regions'))
    negative = ref.get('target_status') in {'absent', 'no_match', 'no_annotated_target'}
    if key in {'localization_correct', 'localization_recall_correct'} and not positive:
        return None
    if key in {'false_positive', 'false_existence_assertion', 'negative_answer_error'} and not negative:
        return None
    if key in {'vcc', 'uar'} and row['dataset'] != 'synthetic':
        return None
    if not valid(row):
        if cohort == 'all_attempts' and key in {'localization_correct', 'localization_recall_correct',
                'answer_correct', 'joint_localization_answer', 'coverage', 'vcc'}:
            return False
        return None
    scores, attention = row['scores'], row['attention']
    if key == 'coverage':
        return scores['concrete_answer']
    if key == 'unknown':
        return row['prediction']['status'] == 'UNKNOWN'
    if key == 'negative_answer_error':
        return (not scores['answer_correct']) if scores.get('answer_correct') is not None and scores['concrete_answer'] else None
    if key == 'joint_localization_answer':
        localization = scores.get('localization_correct') if positive else scores.get('no_target_boxes')
        answer = scores.get('answer_correct')
        return bool(localization and answer and scores['concrete_answer']) if localization is not None and answer is not None else None
    if key == 'vcc':
        return scores.get('supported_concrete_answer')
    if key == 'uar':
        return scores.get('unsupported_concrete_answer') if scores['concrete_answer'] else None
    if key == 'attention_coverage10':
        return attention.get('coverage_tie_averaged', {}).get('0.1')
    if key == 'attention_peak_plateau_hit':
        return attention.get('peak_plateau_any_hit')
    if key.startswith('attention_'):
        return attention.get(key.removeprefix('attention_'))
    return scores.get(key)


def estimate(pairs, repeats):
    from .analysis import interval
    result = interval(pairs, repeats)
    if result['source_groups'] < 2:
        result.update(low=None, high=None)
    return result


def dimensions(row):
    ref = row.get('reference', {})
    return (row['subset'], row['dataset'], ref.get('region_kind', 'unmeasured'))


def summarize_experiment3(root, rows, config):
    from .analysis import dump_csv
    rows = [r for r in rows if r['experiment'] == 3]
    if not rows:
        return
    root = Path(root)
    repeats = config['bootstrap_repeats']
    groups, indexed = defaultdict(list), defaultdict(dict)
    for row in rows:
        # Dataset-specific tables, additionally split by task and target state.
        strata = ['all', 'task:' + row['task_type'],
                  'target:' + row.get('reference', {}).get('target_status', 'unmeasured')]
        for stratum in strata:
            groups[(*dimensions(row), row['condition'], stratum)].append(row)
        indexed[(row['subset'], row['dataset'], row['sample_id'], row['seed'])][row['condition']] = row
    metrics, quality = [], []
    for (subset, dataset, region_kind, condition, stratum), group in sorted(groups.items()):
        base = dict(subset=subset, dataset=dataset, region_kind=region_kind, condition=condition, stratum=stratum)
        counts = dict(planned=len(group), valid=sum(valid(r) for r in group),
            skipped=sum(r['status'] == 'skipped' for r in group),
            not_run=sum(r['status'] == 'not_run' for r in group),
            errors=sum(r['status'] == 'error' for r in group),
            invalid=sum(r['status'] == 'ok' and not valid(r) for r in group))
        quality.append(dict(base, **counts))
        for cohort in ('all_attempts', 'valid_outputs'):
            for name in METRICS:
                if dataset != 'synthetic' and name in {'vcc', 'uar'}:
                    continue
                pairs = [(r['source_group_id'], metric(r, name, cohort)) for r in group]
                e = estimate(pairs, repeats)
                metrics.append(dict(base, **counts, cohort=cohort, metric=name,
                    excluded_or_unscored=len(group)-e['n'], **e))
    paired_groups, joint_groups, transitions, geometry = defaultdict(list), defaultdict(list), [], []
    for conditions in indexed.values():
        visible = conditions.get('visible')
        for row in conditions.values():
            if valid(row):
                for method in ('attention_peak_hit', 'attention_peak_plateau_hit'):
                    a, d, y = (metric(row, k) for k in (method, 'localization_correct', 'answer_correct'))
                    joint_groups[(*dimensions(row), row['condition'], method)].append((row, a, d, y))
            if row.get('intervention') or row.get('geometry_baseline'):
                geometry.append(dict(sample_id=row['sample_id'], source_group_id=row['source_group_id'],
                    dataset=row['dataset'], condition=row['condition'], status=row['status'],
                    intervention=row.get('intervention'), geometry_baseline=row.get('geometry_baseline')))
        for left, right in CONTRASTS:
            a, b = conditions.get(left), conditions.get(right)
            if a is None and b is None:
                continue
            representative = a or b
            cohorts = ['all_sources']
            if visible and valid(visible):
                if metric(visible, 'attention_peak_hit') is True and metric(visible, 'localization_correct') is False:
                    cohorts.append('visible_peak_hit_localization_failed')
                if metric(visible, 'localization_correct') is True and metric(visible, 'answer_correct') is False:
                    cohorts.append('visible_localization_correct_answer_failed')
            transition = dict(subset=representative['subset'], dataset=representative['dataset'],
                sample_id=representative['sample_id'], source_group_id=representative['source_group_id'],
                left=left, right=right, left_execution=a['status'] if a else 'not_planned',
                right_execution=b['status'] if b else 'not_planned',
                left_prediction=a.get('prediction', {}).get('status') if a else None,
                right_prediction=b.get('prediction', {}).get('status') if b else None)
            transitions.append(transition)
            for cohort in cohorts:
                paired_groups[(*dimensions(representative), left, right, cohort)].append((a, b, representative))
    paired = []
    for key, group in sorted(paired_groups.items()):
        subset, dataset, region_kind, left, right, cohort = key
        for output_cohort in ('all_attempts', 'valid_outputs'):
            for name in ('localization_correct', 'answer_correct', 'joint_localization_answer',
                         'coverage', 'unknown', 'attention_enrichment', 'attention_coverage10'):
                complete = [(r['source_group_id'], metric(a, name, output_cohort), metric(b, name, output_cohort))
                            for a, b, r in group]
                complete = [(s, a, b) for s, a, b in complete if a is not None and b is not None]
                paired.append(dict(subset=subset, dataset=dataset, region_kind=region_kind,
                    left=left, right=right, cohort=cohort, output_cohort=output_cohort, metric=name,
                    planned_pairs=len(group), excluded_pairs=len(group)-len(complete),
                    **estimate([(s, float(b)-float(a)) for s, a, b in complete], repeats)))
                if name in {'localization_correct', 'answer_correct', 'joint_localization_answer'}:
                    for change, baseline in [('repair', False), ('degrade', True)]:
                        conditional = [(s, not b if baseline else b) for s, a, b in complete if bool(a) == baseline]
                        paired.append(dict(subset=subset, dataset=dataset, region_kind=region_kind,
                            left=left, right=right, cohort=cohort, output_cohort=output_cohort,
                            metric=name+'.'+change, planned_pairs=len(group), complete_pairs=len(complete),
                            conditioning='left_correct' if baseline else 'left_incorrect', **estimate(conditional, repeats)))
    joint = []
    for key, group in sorted(joint_groups.items()):
        subset, dataset, region_kind, condition, method = key
        eligible = [(r, bool(a), bool(d), bool(y)) for r, a, d, y in group if all(x is not None for x in (a, d, y))]
        for a in (False, True):
            for d in (False, True):
                for y in (False, True):
                    values = [(r['source_group_id'], (aa, dd, yy) == (a, d, y)) for r, aa, dd, yy in eligible]
                    joint.append(dict(subset=subset, dataset=dataset, region_kind=region_kind, condition=condition,
                        attention_definition=method, attention_hit=a, localization_correct=d, answer_correct=y,
                        valid_records=len(group), excluded_unmeasured=len(group)-len(eligible),
                        count=sum(v for _, v in values), **estimate(values, repeats)))
    counterfactual = []
    hallu = defaultdict(dict)
    for row in rows:
        if row['dataset'] == 'hallusegbench' and row.get('pair_id'):
            hallu[(row['subset'], row['pair_id'], row['condition'], row['seed'])][row['native_condition']] = row
    for (subset, pair_id, condition, seed), cells in hallu.items():
        for left, right in (('factual_original', 'counterfactual_original'),
                            ('counterfactual_replacement', 'factual_replacement')):
            a, b = cells.get(left), cells.get(right)
            if a is None and b is None:
                continue
            available = a is not None and b is not None
            complete = available and valid(a) and valid(b)
            representative = a or b
            counterfactual.append(dict(subset=subset, pair_id=pair_id, source_group_id=representative['source_group_id'],
                condition=condition, seed=seed, left=left, right=right, both_conditions_planned=available,
                valid_pair=complete, both_correct=bool(metric(a, 'answer_correct') and metric(b, 'answer_correct')) if complete else None,
                same_status=a['prediction']['status'] == b['prediction']['status'] if complete else None,
                note='Negative cells have only visible observations; no fabricated negative evidence crop.'))
    cf_summary = []
    cf_groups = defaultdict(list)
    for row in counterfactual:
        cf_groups[(row['subset'], row['condition'], row['left'], row['right'])].append(row)
    for key, group in sorted(cf_groups.items()):
        for name in ('both_correct', 'same_status'):
            cf_summary.append(dict(subset=key[0], condition=key[1], left=key[2], right=key[3],
                metric=name, planned_pairs=len(group), **estimate([(r['source_group_id'], r[name]) for r in group], repeats)))
    output = root/'summary'
    macro_groups = defaultdict(list)
    for row in metrics:
        if row['stratum'].startswith('task:'):
            macro_groups[(row['subset'], row['dataset'], row['region_kind'], row['condition'], row['cohort'], row['metric'])].append(row)
    macro = []
    for key, group in sorted(macro_groups.items()):
        measured = [r['mean'] for r in group if r['mean'] is not None]
        macro.append(dict(subset=key[0], dataset=key[1], region_kind=key[2], condition=key[3],
            cohort=key[4], metric=key[5], task_types=len(group), measured_task_types=len(measured),
            macro_mean=sum(measured)/len(measured) if measured and len(measured)==len(group) else None))
    for name, data in [('e3_metrics', metrics), ('e3_output_quality', quality), ('e3_paired_changes', paired),
                       ('e3_joint_distribution', joint), ('e3_transitions', transitions),
                       ('e3_geometry', geometry), ('e3_counterfactual_pairs', counterfactual),
                       ('e3_counterfactual_summary', cf_summary), ('e3_task_macro_averages', macro)]:
        write_json(output/(name+'.json'), data)
        dump_csv(output/(name+'.csv'), data)
    write_json(output/'e3_protocol.json', dict(version=1, contrasts=CONTRASTS,
        localization='Pure strict bbox set correctness, independent of answer status; recall also reported.',
        negative_detection='Boxes attributed to query targets with no author-annotated target; not category absence.',
        vistaqa_negative_answer='Semantic disagreement among concrete answers; not an automatic existence assertion.',
        natural_support='No exact VCC/UAR assigned to natural-image occlusions.',
        inference_failure='All-attempt accuracy counts errors and invalid outputs as failures; not-run remains unmeasured.',
        uncertainty='Source-group bootstrap; a single source has no interval.',
        semantic_pending=sum(valid(r) and r['dataset']=='vistaqa' and r['scores'].get('answer_correct') is None for r in rows),
        skipped_reasons=dict(Counter(r.get('reason') for r in rows if r['status']=='skipped'))))
