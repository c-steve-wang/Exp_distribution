"""Manifest-wide completion and separate execution-shard accounting."""
from pathlib import Path
from .common import read_json, write_json, shard_contains


def write_shard_plan(root, manifest, samples, controls, shards):
    """Persist all shard assignments before filtering to the executing shard."""
    experiment = manifest['experiment']
    plan = dict(experiment=experiment, subset=manifest.get('subset', 'test'), shards=shards,
        assignments=[dict(shard_index=i,
            sample_ids=[s['sample_id'] for s in samples if shard_contains(s['source_group_id'], i, shards)],
            control_ids=[s['sample_id'] for s in controls if shard_contains(s['source_group_id'], i, shards)],
            source_group_ids=sorted({s['source_group_id'] for s in samples+controls
                                    if shard_contains(s['source_group_id'], i, shards)}))
            for i in range(shards)])
    write_json(Path(root)/f'shard_plan_e{experiment}_{plan["subset"]}_{shards}.json', plan)
    return plan


def source_completeness(root, rows, errors):
    root = Path(root)
    selections = [read_json(p) for p in sorted(root.glob('selection_*.json'))]
    manifest_path = root/'delivery_manifest.json'
    manifest = read_json(manifest_path) if manifest_path.exists() else None
    full_scope = manifest is not None and 'sample_ids' in manifest
    if full_scope:
        expected = {(manifest['experiment'], manifest.get('subset', 'test'), sid)
                    for sid in manifest['sample_ids']}
    else:
        expected = {(s['experiment'], s['subset'], sid) for s in selections for sid in s['sample_ids']}
    completed, started = set(), set()
    for path in (root/'progress').glob('*.json'):
        p = read_json(path)
        key = (p['experiment'], p['subset'], p['sample_id'])
        started.add(key)
        if p['completed']:
            completed.add(key)
    for row in rows:
        if row['status'] != 'not_run':
            started.add((row['experiment'], row['subset'], row['sample_id']))
    # Controls have no source progress marker. Check their conditions separately,
    # including historical runs interrupted before run_controls wrote its plan.
    missing_controls = []
    if full_scope:
        indexed = {(r['sample_id'], r['condition'], r['seed']):r for r in rows
                   if r.get('extra', {}).get('axis') == 'visual_control'}
        for sid in manifest.get('controls', []):
            for condition in ('control_original','control_no_image','control_wrong_image'):
                row = indexed.get((sid, condition, manifest.get('config', {}).get('seed', 42)))
                if row is None or row['status'] in {'not_run','error'}:
                    missing_controls.append(dict(sample_id=sid, condition=condition,
                                                 status=row['status'] if row else 'not_run'))
    planned = {}
    for path in sorted(root.glob('shard_plan_*.json')):
        plan = read_json(path)
        for assignment in plan['assignments']:
            key = (plan['experiment'], plan['subset'], plan['shards'], assignment['shard_index'])
            planned[key] = assignment
    observed = {}
    for selection in selections:
        n = selection.get('shards', 1)
        key = (selection['experiment'], selection['subset'], n, selection.get('shard_index', 0))
        observed[key] = selection
        for i in range(n):
            planned.setdefault((*key[:3], i), {})
    shards = []
    for key, assignment in sorted(planned.items()):
        selection = observed.get(key)
        ids = assignment.get('sample_ids', selection.get('sample_ids') if selection else None)
        selected = {(key[0], key[1], sid) for sid in ids} if ids is not None else set()
        controls = set(assignment.get('control_ids', []))
        groups = set(assignment.get('source_group_ids', []))
        relevant = [r for r in rows if r['subset'] == key[1] and
                    (r.get('source_group_id') in groups or r['sample_id'] in set(ids or []) | controls)]
        failures = [e for e in errors if (e['experiment'], e['subset'], e['sample_id']) in selected]
        incomplete_records = [r['record_file'] for r in relevant if r['status'] in {'not_run', 'error'}]
        local_controls = [r for r in missing_controls if r['sample_id'] in controls]
        done = bool(selection is not None and ids is not None and not (selected-completed)
                    and not failures and not incomplete_records and not local_controls)
        shards.append(dict(experiment=key[0], subset=key[1], shards=key[2], shard_index=key[3],
            started=selection is not None, expected_sources=len(ids) if ids is not None else None,
            completed_sources=len(selected & completed),
            sources_not_completed=sorted(s[2] for s in selected-completed),
            incomplete_record_files=incomplete_records, source_errors=failures,
            control_records_not_completed=local_controls,
            inference_complete=done, state='complete' if done else 'incomplete' if selection else 'not_started'))
    missing = sorted(expected-completed)
    failed = bool(missing or errors or missing_controls or any(r['status'] in {'not_run','error'} for r in rows))
    return dict(completeness_scope='full_manifest' if full_scope else 'observed_selections_only',
        expected_sources=len(expected), completed_sources=len(expected & completed),
        selected_sources_not_completed=missing,
        control_records_not_completed=missing_controls,
        sources_never_started=sorted(expected-started),
        inference_complete=not failed if full_scope else False if failed else None,
        shard_completion=shards)
