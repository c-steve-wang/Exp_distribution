"""Read the uploaded, frozen dataset; never download the four upstream raw datasets."""
from pathlib import Path
import os
from .common import read_json, write_json, file_hash

PROJECT_ROOT = Path(__file__).resolve().parents[1]
SOURCE_CONFIG = PROJECT_ROOT / 'configs/data_source.json'


def prepared_root(path):
    path = Path(path).expanduser().resolve()
    return path if (path / 'build_report.json').is_file() else path / 'prepared_data'


def validate_data_root(path, source=None, require_snapshot=False, check_assets=False):
    """Check actual selection/manifest files, including test-only and complete-pair rules."""
    source = source or read_json(SOURCE_CONFIG)
    root = prepared_root(path)
    report_path = root / 'build_report.json'
    report = read_json(report_path)
    if report['status'] != 'complete':
        raise ValueError('Prepared data is incomplete')
    matches_snapshot = file_hash(report_path) == source['build_report_sha256']
    if require_snapshot and not matches_snapshot:
        raise ValueError('Dataset snapshot differs from configs/data_source.json; do not mix data versions')
    measured, assets = {}, set()
    for name, expected in source['test_units'].items():
        counts = report['datasets'][name]
        manifest = root / 'manifests' / (name + '.jsonl')
        selection_path = root / 'selections' / (name + '.json')
        if file_hash(manifest) != counts['manifest_sha256'] or file_hash(selection_path) != counts['selection_sha256']:
            raise ValueError('Dataset manifest/selection checksum mismatch: ' + name)
        selection = read_json(selection_path)
        selected, test = selection['selected_unit_ids'], selection['test_unit_ids']
        if selected != test or selection.get('development_unit_ids') or len(set(test)) != expected or len(test) != expected:
            raise ValueError('Expected all selected units in test, with no held-out split: ' + name)
        import json
        rows = [json.loads(line) for line in manifest.read_text().splitlines() if line]
        allowed = set(test)
        rows = [row for row in rows if row['unit_id'] in allowed]
        if {row['unit_id'] for row in rows} != set(test) or len({row['sample_id'] for row in rows}) != len(rows):
            raise ValueError('Missing or duplicate selected records: ' + name)
        if name == 'hallusegbench':
            pairs = {}
            for row in rows:
                pairs.setdefault(row['pair_id'], set()).add(row['condition'])
            cells = {'factual_original', 'factual_replacement', 'counterfactual_original', 'counterfactual_replacement'}
            if len(pairs) != expected or len(rows) != expected * 4 or any(v != cells for v in pairs.values()):
                raise ValueError('Incomplete HalluSegBench four-cell pairs')
        for row in rows:
            assets.add(row['image']['path'])
            for region in row['reference']['regions'] + row.get('intervention_regions', []):
                mask = region.get('mask')
                if mask and mask['encoding'] == 'binary_png':
                    assets.add(mask['path'])
        measured[name] = dict(test_units=len(test), records=len(rows),
                              source_groups=len({r['source_group_id'] for r in rows}), development_units=0)
    if check_assets:
        for relative in assets:
            asset = (root / relative).resolve()
            if not asset.is_relative_to(root) or not asset.is_file():
                raise ValueError('Missing or unsafe dataset asset: ' + relative)
    return dict(root=str(root), matches_pinned_snapshot=matches_snapshot, datasets=measured,
                asset_paths=len(assets), asset_existence_checked=check_assets)


def resolve_data_root(explicit=None, project_root=PROJECT_ROOT):
    """Local-only lookup. A plan or pilot never triggers a hidden dataset download."""
    source = read_json(Path(project_root) / 'configs/data_source.json')
    explicit = explicit or os.environ.get('GG_DATA_ROOT')
    if explicit:
        return Path(validate_data_root(explicit, source)['root'])
    project_root = Path(project_root)
    candidates = [project_root / 'prepared_data', project_root / 'data/Attn_exp_data/prepared_data',
                  project_root / 'Attn_exp_data/prepared_data', project_root.parent / 'Attn_exp_data/prepared_data']
    location = project_root / 'data/location.json'
    if location.exists():
        candidates.insert(0, Path(read_json(location)['root']))
    for candidate in candidates:
        report = candidate / 'build_report.json'
        if report.is_file() and file_hash(report) == source['build_report_sha256']:
            validate_data_root(candidate, source, require_snapshot=True)
            return candidate.resolve()
    raise FileNotFoundError('Run python -m experiments fetch-data once, or pass --data-root /path/to/prepared_data')


def fetch_data(local_dir=None, project_root=PROJECT_ROOT):
    project_root = Path(project_root)
    source = read_json(project_root / 'configs/data_source.json')
    if local_dir is None:
        try:
            root = resolve_data_root(project_root=project_root)
            result = validate_data_root(root, source, require_snapshot=True, check_assets=True)
            return dict(result, downloaded=False, repo_id=source['repo_id'], revision=source['revision'])
        except (FileNotFoundError, ValueError):
            pass
    destination = Path(local_dir).expanduser().resolve() if local_dir else project_root / 'data/Attn_exp_data'
    # Use local_dir so the existing reader sees regular files, not Hub-cache blob symlinks.
    from huggingface_hub import snapshot_download
    snapshot_download(repo_id=source['repo_id'], repo_type='dataset', revision=source['revision'],
                      local_dir=str(destination), max_workers=int(os.environ.get('GG_HF_MAX_WORKERS', '2')),
                      allow_patterns=['prepared_data/**', 'README.md', 'data_config.json',
                                                               'verification_report.json', 'SHA256SUMS'])
    result = validate_data_root(destination, source, require_snapshot=True, check_assets=True)
    write_json(project_root / 'data/location.json', dict(root=result['root'], repo_id=source['repo_id'], revision=source['revision']))
    return dict(result, downloaded=True, repo_id=source['repo_id'], revision=source['revision'])
