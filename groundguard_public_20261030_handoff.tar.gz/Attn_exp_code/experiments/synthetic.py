"""Deterministic Pillow scenes with explicit worlds and exact hidden-world equality."""
from pathlib import Path
import json
import numpy as np
from PIL import Image, ImageDraw
from .common import rng_for, file_hash, write_json, fingerprint
from .geometry import box_from_mask

COLORS = {'red': (215, 35, 35), 'blue': (30, 80, 210)}


def generate(root, seed=42, per_task=200):
    root = Path(root)
    config = dict(seed=seed, per_task=per_task, generator_version=4)
    if (root / 'generation.json').exists():
        if json.loads((root / 'generation.json').read_text())['config'] != config:
            raise ValueError('Synthetic configuration changed; use a new work directory')
        return
    root.mkdir(parents=True, exist_ok=True)
    records = []
    for task in ['counting', 'attribute', 'spatial']:
        for index in range(per_task):
            rng = rng_for(seed, 'synthetic', task, index)
            ambiguous = index >= round(per_task * .8)
            family = f'synthetic/{task}/{index:04d}'
            scale = [48, 96, 160][index % 3]
            width, height = scale * 3, scale * 2
            if ambiguous:
                width = min(width, 440)
            x, y = rng.randint(80, 900 - width), rng.randint(80, 900 - height)
            support_box = [x, y, x + width, y + height]
            base = Image.new('RGB', (1024, 1024), (235, 235, 225))
            draw = ImageDraw.Draw(base)
            distractor_count = [4, 12, 24][(index // 3) % 3]
            for _ in range(distractor_count):
                dx, dy = rng.randint(0, 990), rng.randint(0, 990)
                draw.rectangle((dx, dy, dx + 25, dy + 25), fill=(130, 130, 130))
            variants = ['ambiguous'] if ambiguous else ['I_plus', 'I_minus', 'I_zero']
            images = {}
            family_support = np.zeros((1024, 1024), dtype=bool)
            for variant in variants:
                image = base.copy()
                if variant == 'I_zero':
                    pixels = np.asarray(image).copy()
                    pixels[:, :, 1] = np.maximum(pixels[:, :, 1].astype(int) - 25, 0).astype('uint8')
                    image = Image.fromarray(pixels)
                draw = ImageDraw.Draw(image)
                panels = [[x, y, x + width, y + height]]
                if ambiguous:
                    panels = [[40, 280, 40 + width, 280 + height],
                              [980 - width, 280, 980, 280 + height]]
                masks = []
                answers = []
                for panel_index, panel in enumerate(panels):
                    px, py, ex, ey = panel
                    family_support[py:ey, px:ex] = True
                    draw.rectangle((px, py, ex - 1, ey - 1), fill='white', outline='black', width=3)
                    negative = variant == 'I_minus' or (ambiguous and panel_index == 1)
                    specs = []
                    if task == 'counting':
                        count = 3 if negative else 2
                        answers.append(str(count))
                        for j in range(count):
                            cx = px + (j + 1) * width / (count + 1)
                            cy = py + height / 2
                            radius = scale / 5
                            specs.append(('ellipse', [cx - radius, cy - radius, cx + radius, cy + radius], (25, 155, 170)))
                        question = 'How many symbols are inside the black frame?'
                    elif task == 'attribute':
                        color = 'blue' if negative else 'red'
                        answers.append(color)
                        cx, cy = (px + ex) / 2, (py + ey) / 2
                        specs.append(('rectangle', [cx - scale / 3, cy - scale / 3, cx + scale / 3, cy + scale / 3], COLORS[color]))
                        question = 'What color is the symbol inside the black frame?'
                    else:
                        answers.append('no' if negative else 'yes')
                        centers = [px + width / 3, px + width * 2 / 3]
                        if negative:
                            centers.reverse()
                        cy, radius = (py + ey) / 2, scale / 4
                        specs = [('ellipse', [centers[0] - radius, cy - radius, centers[0] + radius, cy + radius], (30, 130, 80)),
                                 ('rectangle', [centers[1] - radius, cy - radius, centers[1] + radius, cy + radius], (155, 90, 155))]
                        question = 'Inside the black frame, is the circle to the left of the square?'
                    for shape, bounds, color in specs:
                        getattr(draw, shape)(bounds, fill=color)
                        mask = Image.new('L', image.size, 0)
                        getattr(ImageDraw.Draw(mask), shape)(bounds, fill=255)
                        masks.append(mask)
                native_id = family + '/' + variant
                relative = Path('images') / task / f'{index:04d}_{variant}.png'
                (root / relative).parent.mkdir(parents=True, exist_ok=True)
                image.save(root / relative)
                regions = []
                for j, mask in enumerate(masks):
                    mask_path = Path('masks') / task / f'{index:04d}_{variant}_{j}.png'
                    (root / mask_path).parent.mkdir(parents=True, exist_ok=True)
                    mask.save(root / mask_path)
                    binary = np.asarray(mask) > 0
                    regions.append(dict(bbox_xyxy=box_from_mask(binary), area=int(binary.sum()),
                                        mask=dict(encoding='binary_png', path=str(mask_path), size=[1024, 1024])))
                support_path = Path('masks') / task / f'{index:04d}_support.png'
                Image.fromarray(family_support.astype('uint8') * 255).save(root / support_path)
                # Keep complete families together, including all intervention variants.
                split = 'test'
                answer = 'UNKNOWN' if ambiguous else answers[0]
                records.append(dict(schema_version=1, sample_id=native_id, unit_id=native_id,
                    dataset='synthetic', task_type=task, domain='controlled', source_group_id=family,
                    pair_id=family, condition=variant, is_primary=variant in {'I_plus', 'ambiguous'},
                    official_split='generated', analysis_split=split, question=question,
                    image=dict(path=str(relative), width=1024, height=1024, byte_sha256=file_hash(root / relative)),
                    support_mask=str(support_path), reference=dict(answer=answer, answer_type='text',
                        region_kind='mask', target_status='present', regions=regions,
                        global_ambiguous=ambiguous, possible_answers=answers,
                        facts=[] if ambiguous else ([f'count={answer}', 'color=cyan'] if task == 'counting' else
                            ['count=1', f'color={answer}'] if task == 'attribute' else
                            ['count=2', 'color=mixed', f'circle_left_of_square={answer}'])),
                    provenance=dict(generator='pillow-v4', seed=seed, family_index=index,
                                    target_scale=scale, distractor_count=distractor_count,
                                    support_box=box_from_mask(family_support), support_boxes=panels)))
                images[variant] = np.asarray(image)
            if not ambiguous:
                if not np.array_equal(images['I_plus'][~family_support], images['I_minus'][~family_support]):
                    raise ValueError('Hidden worlds differ outside the decisive region')
                if not np.array_equal(images['I_plus'][family_support], images['I_zero'][family_support]):
                    raise ValueError('Appearance control changes the decisive evidence')
    (root / 'catalog.jsonl').write_text(''.join(json.dumps(r, ensure_ascii=False) + '\n' for r in records))
    write_json(root / 'generation.json', dict(config=config, records=len(records),
               families=per_task * 3, hidden_world_equality_verified=True,
               catalog_sha256=file_hash(root / 'catalog.jsonl')))

