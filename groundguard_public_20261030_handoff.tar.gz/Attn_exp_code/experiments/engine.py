"""Atomic inference cache and reference-blind model calls, shared by all experiments."""
from pathlib import Path
import hashlib
import os
import tempfile
import zipfile
import numpy as np
from .common import fingerprint, write_json, read_json, file_hash
from .geometry import map_box, pixel_bounds, annotation_area
from .metrics import attention_metrics, instance_attention_metrics, project_mass, score_prediction
from .protocol import SYSTEM, task_prompt, parse_prediction, prediction_contract, FACT_SYSTEM, FACT_QUESTION, final_json
from .protocol import prediction_request, parse_task_prediction


def code_fingerprint():
    root = Path(__file__).parent
    return fingerprint({p.name: file_hash(p) for p in sorted(root.glob('*.py'))})


def save_npz(path, arrays):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temporary = tempfile.mkstemp(suffix='.npz', dir=path.parent)
    os.close(fd)
    try:
        # Lossless NPZ, with a low compression level: large head/query tensors
        # otherwise spend much longer in zlib than in GPU inference. Preserve
        # every value/dtype and the existing atomic replacement contract.
        with zipfile.ZipFile(temporary, 'w', compression=zipfile.ZIP_DEFLATED,
                             compresslevel=1, allowZip64=True) as archive:
            for name, value in arrays.items():
                with archive.open(name + '.npy', 'w', force_zip64=True) as member:
                    np.lib.format.write_array(member, np.asanyarray(value), allow_pickle=False)
        os.replace(temporary, path)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


class Engine:
    def __init__(self, backend, data, root, config, model_key):
        self.backend, self.data, self.root = backend, data, Path(root)
        self.config, self.model_key = config, model_key
        self._measurement_features = {}
        self.identity = dict(code=code_fingerprint(), config=fingerprint(config),
                             data=data.fingerprint(), backend=backend.metadata())
        self.run_id = fingerprint(self.identity)[:20]
        self.run_dir = self.root / 'runs' / model_key / self.run_id
        write_json(self.run_dir / 'run.json', self.identity)
        write_json(self.run_dir / 'experiment_config.json', config)

    def infer(self, views, prompt, question, system, seed, capture=True, output_schema=None):
        view_info = []
        for item in views:
            info = {k: v for k, v in item.items() if k not in {'image', '_occlusion'}}
            if '_occlusion' in item:
                mask = item['_occlusion']
                mask_hash = fingerprint(dict(shape=list(mask.shape), bytes=hashlib.sha256(mask.tobytes()).hexdigest()))
                path = self.run_dir / 'masks' / (mask_hash + '.npz')
                if not path.exists():
                    save_npz(path, dict(mask=mask))
                info['occlusion_mask'] = str(path.relative_to(self.run_dir))
            view_info.append(info)
        pixels = [hashlib.sha256(v['image'].tobytes()).hexdigest() for v in views]
        identity = dict(run=self.run_id, views=view_info, pixels=pixels, prompt=prompt, question=question,
                        system=system, seed=seed, capture=capture)
        if output_schema is not None:
            identity['output_schema'] = output_schema
        key = fingerprint(identity)
        path = self.run_dir / 'cache' / (key + '.json')
        if path.exists():
            return read_json(path)
        options = dict(output_schema=output_schema) if output_schema is not None else {}
        result = self.backend.infer(views, prompt, question, system, seed, capture=capture, **options)
        arrays = {k: result.pop(k) for k in ['layer_weights', 'local_layer_weights'] if k in result}
        arrays.update(result.pop('attention_arrays', {}))
        if arrays:
            save_npz(path.with_suffix('.npz'), arrays)
        result.update(request_id=key, request=identity, attention_file=key + '.npz' if arrays else None)
        write_json(path, result)
        return result

    def weights(self, inference):
        with np.load(self.run_dir / 'cache' / inference['attention_file'], allow_pickle=False) as file:
            return {k: file[k] for k in file.files}

    def heatmap(self, record, size):
        inference = read_json(self.run_dir / 'cache' / (record['request_id'] + '.json'))
        weights = self.weights(inference)['layer_weights'].mean(axis=0)
        return project_mass(weights / weights.sum() if weights.sum() > 0 else weights, inference['token_boxes'], size)

    def observe_facts(self, views, seed):
        result = self.infer(views, FACT_QUESTION, FACT_QUESTION, FACT_SYSTEM, seed, capture=False)
        try:
            facts = final_json(result['text'])['facts']
            if not isinstance(facts, list) or not all(isinstance(f, str) for f in facts):
                raise ValueError('Invalid fact list')
            return dict(facts=sorted(set(f.strip().casefold() for f in facts)), request_id=result['request_id'], parse_error=None)
        except (ValueError, KeyError, TypeError) as error:
            return dict(facts=[], request_id=result['request_id'], parse_error=str(error))

    def evaluate(self, sample, views, seed, support_available=None, experiment=None):
        contract = prediction_contract(self.config, views, experiment)
        strict = contract['strict']
        e3 = experiment == 3 and contract.get('protocol') == 'experiment3_v1'
        e4 = experiment == 4 and contract.get('protocol') == 'experiment4_v1'
        e2 = experiment == 2 and self.config.get('experiment2_measurement')
        request = prediction_request(sample, views, self.config, experiment,
            structured=bool(self.backend.spec.get('structured_output')), contract=contract)
        inference = self.infer(views, question=sample['question'], seed=seed, **request)
        prediction = parse_task_prediction(inference['text'], len(views), sample['dataset'], contract,
            finish_reason=inference.get('finish_reason'), schema=request.get('output_schema'))
        predicted = [map_box(b['bbox'], views[b['view']]['source_box']) for b in prediction['boxes']]
        refs = [r['bbox_xyxy'] for r in sample['reference']['regions']]
        scores = score_prediction(prediction, sample, predicted, refs, support_available)
        if e3 or e4:
            from .experiment3 import scores as e3_scores
            scores.update(e3_scores(prediction, sample, predicted, refs, scores))
        mask = self.data.region_mask(sample)
        features = None
        if strict and mask is not None and mask.any():
            from .experiment1_measurement import scene_features
            if sample['sample_id'] not in self._measurement_features:
                self._measurement_features[sample['sample_id']] = scene_features(
                    self.data.image(sample), mask, self.config['overview_edge'])
            features = self._measurement_features[sample['sample_id']]
        size = (sample['image']['width'], sample['image']['height'])
        weights = self.weights(inference)
        measurement_v3 = e3 or e4 or (experiment == 1 and self.config.get('experiment1_measurement', {}).get('version', 0) >= 3)
        attention, heatmap = attention_metrics(weights['layer_weights'], inference['token_boxes'], mask, size,
                                              tie_diagnostics=measurement_v3)
        attention['layer_names'] = inference['layer_names']
        if sample.get('intervention_regions'):
            # In a Hallu negative cell this is the edited/replacement region, not a present target.
            context_sample = dict(sample, reference=dict(sample['reference'], region_kind='mask', regions=sample['intervention_regions']))
            changed_mask = self.data.region_mask(context_sample)
            measured, _ = attention_metrics(weights['layer_weights'], inference['token_boxes'], changed_mask, size,
                                            tie_diagnostics=e4)
            attention['intervention_region'] = dict(region_mass=measured.get('evidence_mass'),
                enrichment=measured.get('enrichment'), peak_hit=measured.get('peak_hit'), scope='edited_or_replacement_region_not_target_presence')
            if e4:
                attention['intervention_region'].update(
                    coverage_tie_averaged=measured.get('coverage_tie_averaged', {}),
                    peak_plateau_any_hit=measured.get('peak_plateau_any_hit'),
                    peak_plateau_hit_fraction=measured.get('peak_plateau_hit_fraction'))
        attention.update(instance_attention_metrics(heatmap,
            [self.data.region_mask(sample, i) for i in range(len(refs))]))
        attention['per_view'] = []
        for i in range(len(views)):
            indices = [j for j, b in enumerate(inference['token_boxes']) if b['view'] == i]
            part = weights['layer_weights'][:, indices]
            if part.sum() > 0:
                measured, _ = attention_metrics(part, [inference['token_boxes'][j] for j in indices], mask, size,
                                                tie_diagnostics=measurement_v3)
                attention['per_view'].append(dict(view=i, **measured))
            else:
                attention['per_view'].append(dict(view=i, spatial_visual_mass=0., within_visual_normalization_defined=False))
        if weights.get('local_layer_weights', np.empty(0)).size:
            local = weights['local_layer_weights']
            # A sliding window may contain no visual key for these query positions.
            attention['local_layers'] = dict(layer_names=inference['local_layer_names'],
                                            spatial_visual_mass=local.sum(axis=1).tolist())
            if local.sum() > 0:
                measured, _ = attention_metrics(local, inference['token_boxes'], mask, size)
                attention['local_layers']['metrics'] = measured
        geometry_baseline = None
        if measurement_v3:
            from .experiment1_measurement import full_view_geometry_baseline
            geometry_baseline = full_view_geometry_baseline(inference['request']['views'], refs)
        return dict(sample_id=sample['sample_id'], source_group_id=sample['source_group_id'],
            pair_id=sample['pair_id'], dataset=sample['dataset'], task_type=sample['task_type'], domain=sample.get('domain', ''),
            native_condition=sample['condition'], official_split=sample['official_split'],
            measurement_features=features or {},
            prediction_contract=contract, geometry_baseline=geometry_baseline,
            reference=sample['reference'], question=sample['question'], image=sample['image'],
            seed=seed, prediction=prediction, predicted_boxes=predicted, scores=scores, attention=attention,
            evidence_area_fraction=float(mask.mean()) if mask is not None else None,
            min_instance_area_fraction=min((annotation_area(r) for r in sample['reference']['regions']), default=0) / (size[0] * size[1]),
            views=inference['request']['views'], request_id=inference['request_id'],
            costs={k: inference[k] for k in ['input_tokens', 'output_tokens', 'spatial_visual_tokens',
                                            'input_seconds', 'inference_seconds', 'peak_allocated_bytes']})


def synthetic_support(data, sample, views, occlusions=None):
    if sample['dataset'] != 'synthetic':
        return None
    if sample['reference']['global_ambiguous']:
        return False
    required = data.support_mask(sample)
    observed = np.zeros_like(required)
    for i, v in enumerate(views):
        x1, y1, x2, y2 = pixel_bounds(v['source_box'], v['source_size'])
        part = np.zeros_like(required)
        part[y1:y2, x1:x2] = True
        if occlusions is not None and occlusions[i] is not None:
            part &= ~occlusions[i]
        observed |= part
    return bool((observed & required).sum() == required.sum())
