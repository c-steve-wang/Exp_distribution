"""Reference-blind JSON constraints applied only to generated tokens."""
from importlib.metadata import version
from .common import fingerprint


def structured_metadata(spec):
    mode = spec.get('structured_output')
    if mode is None:
        return None
    if mode != 'xgrammar':
        raise ValueError('Unsupported structured_output: ' + str(mode))
    installed = version('xgrammar')
    if installed != '0.2.8':
        raise ValueError('This protocol requires xgrammar==0.2.8')
    if spec.get('template_kwargs', {}).get('enable_thinking', False):
        raise ValueError('JSON-constrained output requires non-thinking generation')
    if spec['generation'].get('num_beams', 1) != 1:
        raise ValueError('JSON-constrained output currently supports one beam')
    return dict(engine='xgrammar', version=installed, protocol='task_json_v2')


class StructuredDecoder:
    def __init__(self, tokenizer, vocab_size, stop_token_ids, compact_json=False):
        import xgrammar as xgr
        self.xgr = xgr
        self.compact_json = compact_json
        self.compiler = xgr.GrammarCompiler(xgr.TokenizerInfo.from_huggingface(
            tokenizer, vocab_size=vocab_size, stop_token_ids=stop_token_ids), max_threads=2)
        self.grammars = {}

    def processor(self, schema):
        from xgrammar.contrib.hf import LogitsProcessor
        key = fingerprint(schema)
        if key not in self.grammars:
            formatting = (dict(any_whitespace=False, separators=(',', ':')) if self.compact_json
                          else dict(max_whitespace_cnt=2))
            self.grammars[key] = self.compiler.compile_json_schema(
                schema, any_order=False, **formatting)
        # Matchers are stateful: reuse compiled grammars, never a processor.
        return LogitsProcessor(self.grammars[key])
