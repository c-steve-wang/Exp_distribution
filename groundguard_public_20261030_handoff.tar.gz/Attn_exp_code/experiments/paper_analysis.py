"""Auditable paper estimands; no recognition labels are inferred from localization."""
from collections import defaultdict
from pathlib import Path
import numpy as np
from .common import read_json, write_json, fingerprint
from .metrics import attention_metrics, instance_attention_metrics, INSTANCE_COVERAGE_POLICY


def refresh_attention(root, rows, data=None):
    """Recompute old spatial measurements from cached weights, without VLM calls."""
    audit = []
    for row in rows:
        if (row.get('status') != 'ok' or not row.get('request_id')
                or row.get('spatial_metrics_applicability') == 'not_applicable_visual_control'
                or (row.get('extra', {}).get('axis') == 'visual_control'
                    and row.get('condition') != 'control_original')):
            continue
        if (row.get('attention', {}).get('baseline_policy') == 'valid_footprint_area_same_projection_v2'
                and row.get('attention', {}).get('instance_coverage_policy') == INSTANCE_COVERAGE_POLICY):
            continue
        cache = Path(root)/'cache'/(row['request_id']+'.json')
        if not cache.exists():
            audit.append(dict(record_file=row.get('record_file'), status='missing_inference_cache'))
            continue
        if data is None:
            from .data import ExperimentData
            from .data_source import resolve_data_root
            # An explicit GG_DATA_ROOT overrides the installed location.
            data = ExperimentData(resolve_data_root(), Path(root)/'analysis_work')
        sample = data.get(row['sample_id'])
        inference = read_json(cache)
        if not inference.get('attention_file'):
            audit.append(dict(record_file=row.get('record_file'), status='missing_attention_cache'))
            continue
        attention_path = Path(root)/'cache'/inference['attention_file']
        if not attention_path.exists():
            audit.append(dict(record_file=row.get('record_file'), status='missing_attention_cache'))
            continue
        with np.load(attention_path, allow_pickle=False) as arrays:
            weights = arrays['layer_weights']
        size = (sample['image']['width'], sample['image']['height'])
        old = row.get('attention', {})
        measured, heatmap = attention_metrics(weights, inference['token_boxes'], data.region_mask(sample), size, tie_diagnostics=True)
        measured.update(instance_attention_metrics(heatmap,
            [data.region_mask(sample, i) for i in range(len(sample['reference']['regions']))]))
        row['attention'] = dict(old, **measured)
        row['attention']['per_view'] = []
        for view in sorted({b['view'] for b in inference['token_boxes']}):
            selected = [i for i,b in enumerate(inference['token_boxes']) if b['view']==view]
            m, _ = attention_metrics(weights[:,selected], [inference['token_boxes'][i] for i in selected],
                data.region_mask(sample), size, tie_diagnostics=True)
            row['attention']['per_view'].append(dict(view=view, **m))
        if sample.get('intervention_regions'):
            region = dict(sample, reference=dict(sample['reference'], region_kind='mask', regions=sample['intervention_regions']))
            m, _ = attention_metrics(weights, inference['token_boxes'], data.region_mask(region), size, tie_diagnostics=True)
            row['attention']['intervention_region'] = dict(m, region_mass=m.get('evidence_mass'),
                scope='author_target_or_replacement_region_not_complete_reasoning_support')
        audit.append(dict(record_file=row.get('record_file'), status='recomputed_from_cache',
            old_enrichment=old.get('enrichment'), new_enrichment=measured.get('enrichment'),
            old_uniform_evidence_mass=old.get('uniform_evidence_mass'), new_uniform_evidence_mass=measured.get('uniform_evidence_mass'),
            old_instance_coverage=old.get('instance_coverage'), new_instance_coverage=measured['instance_coverage'],
            old_all_instances_covered_at90=old.get('all_instances_covered_at90'),
            new_all_instances_covered_at90=measured['all_instances_covered_at90']))
    return audit


def conditional_cpc(rows, rule, repeats=1000):
    from .experiment4_analysis import pair_metrics, valid, estimate
    if rule.get('aggregation') != 'min_endpoints' or rule.get('region') != 'author_target_or_replacement':
        raise ValueError('Unsupported frozen conditional CPC rule')
    tau = float(rule['tau'])
    if not np.isfinite(tau) or tau < 0:
        raise ValueError('Enrichment threshold must be finite and nonnegative')
    grouped = defaultdict(dict)
    for row in rows:
        if row.get('experiment') == 4 and row.get('dataset') == 'hallusegbench' and row.get('pair_id'):
            grouped[(row['subset'], row['condition'], row['pair_id'], row['seed'])][row['native_condition']] = row
    details, groups = [], defaultdict(list)
    for (subset, condition, pair, seed), cells in sorted(grouped.items()):
        # Original query is the primary factual contrast. Other contrasts stay in e4_*.
        a, b = cells.get('factual_original'), cells.get('counterfactual_original')
        source = (a or b or next(iter(cells.values())))['source_group_id']
        complete = bool(a and b and a['status'] == b['status'] == 'ok')
        def enrichment(row):
            if not row or row['status'] != 'ok':
                return None
            att = row.get('attention', {})
            # The protocol uses each image's author target/replacement region.
            return (att.get('intervention_region') or att).get('enrichment')
        values = [enrichment(r) for r in (a,b)]
        measured = all(v is not None and np.isfinite(v) for v in values)
        selected = bool(min(values) >= tau) if measured else None
        facts = pair_metrics(a,b,'valid_outputs') if a and b else {}
        fixed = a.get('question') == b.get('question') if a and b and 'question' in a and 'question' in b else None
        truth_valid = (a['reference'].get('answer')=='PRESENT' and b['reference'].get('answer')=='ABSENT') if a and b else None
        if fixed is False or truth_valid is False:
            raise ValueError('Invalid fixed-query Hallu truth mapping: '+pair)
        entry = dict(subset=subset, dataset='hallusegbench', condition=condition, pair_id=pair,
            source_group_id=source, seed=seed, complete_pair=complete, both_valid=valid(a) and valid(b),
            fixed_query_verified=fixed, truth_mapping_verified=truth_valid,
            left_enrichment=values[0], right_enrichment=values[1], pair_enrichment=min(values) if measured else None,
            condition_met=selected, factual_cpc=facts.get('both_status_correct'),
            joint_pair_correct=facts.get('both_correct'), rule_id=fingerprint(rule))
        details.append(entry); groups[(subset,condition)].append(entry)
    summary = []
    for (subset,condition), group in sorted(groups.items()):
        complete = [r for r in group if r['complete_pair']]
        selected = [r for r in complete if r['condition_met'] is True]
        eligible = [r for r in selected if r['factual_cpc'] is not None]
        e = estimate([(r['source_group_id'],r['factual_cpc']) for r in eligible],repeats)
        u = estimate([(r['source_group_id'],r['factual_cpc']) for r in complete],repeats)
        summary.append(dict(subset=subset,dataset='hallusegbench',condition=condition,rule=rule,
            planned_pairs=len(group),complete_pairs=len(complete),conditional_pairs=len(selected),
            conditional_scored_pairs=len(eligible),attention_missing=sum(r['condition_met'] is None for r in complete),
            conditional_coverage=len(selected)/len(complete) if complete else None,
            unconditional_cpc=u['mean'],unconditional_scored_pairs=u['n'],unconditional_interval=u,
            conditional_cpc=e['mean'],**e))
    return details, summary


def summarize_paper(root, rows, config, attention_audit):
    from .analysis import dump_csv
    from .controls import summarize_controls
    summarize_controls(root, rows, config['bootstrap_repeats'])
    output = Path(root)/'summary'
    rule = config.get('conditional_cpc', dict(tau=1., aggregation='min_endpoints',
        region='author_target_or_replacement', status='exploratory_no_development_freeze', development_sources=[]))
    development = set(rule.get('development_sources', []))
    test_sources = {r['source_group_id'] for r in rows if r['subset']=='test'}
    if development & test_sources:
        raise ValueError('Development sources overlap test sources')
    if rule.get('status') == 'development_frozen' and not development:
        raise ValueError('A development-frozen rule requires actual development sources')
    details, summary = conditional_cpc(rows, rule, config['bootstrap_repeats'])
    per_record = [dict(record_file=r.get('record_file'), model=r.get('model'), dataset=r['dataset'],
        sample_id=r['sample_id'], source_group_id=r['source_group_id'], experiment=r['experiment'],
        condition=r['condition'], seed=r['seed'], execution_status=r['status'], scores=r.get('scores'),
        attention=r.get('attention'), failure=r.get('error') or r.get('reason')) for r in rows]
    for name, values in [('paper_records',per_record),('attention_revision_audit',attention_audit),
                         ('conditional_cpc_pairs',details),('conditional_cpc',summary)]:
        write_json(output/(name+'.json'),values); dump_csv(output/(name+'.csv'),values)
    write_json(output/'measurement_definitions.json',dict(
        primary_axes='attention × localization/detection × answer',
        recognition='not independently annotated or measured; no recognition-to-reasoning attribution',
        localization='all_boxes_correct: one-to-one matching, no extra/missing boxes; all_instances_hit: recall only',
        vistaqa_joint='per-output answer_correct AND all_boxes_correct AND concrete_answer; never product of means',
        factual_cpc='both_status_correct on fixed original query; joint pair additionally requires localization',
        conditional_cpc=rule, attention_baseline='valid footprint area, same projection and region integration',
        top_area_ties='fractional membership at exact cutoff',
        annotations='existing dataset masks for attention, reference boxes for localization, native answers/status for task scoring',
        historical_runs='original split and exploratory usage preserved; no retrospective development claims'))
