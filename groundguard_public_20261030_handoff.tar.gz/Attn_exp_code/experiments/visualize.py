"""Scientific figures from measured attention only; no model inference."""
from pathlib import Path
import numpy as np
from .common import read_json
from .metrics import project_mass
from .geometry import view


def render_record(data, run_dir, record):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    from matplotlib.patches import Rectangle
    root = Path(run_dir)
    path = Path(record) if Path(record).is_absolute() else root / 'records' / record
    row = read_json(path)
    if row['status'] != 'ok':
        raise ValueError('This record contains no successful measurement')
    sample = data.get(row['sample_id'])
    image = data.image(sample)
    inference = read_json(root / 'cache' / (row['request_id'] + '.json'))
    with np.load(root / 'cache' / inference['attention_file'], allow_pickle=False) as arrays:
        weights = arrays['layer_weights'].mean(axis=0)
    heatmap = project_mass(weights / weights.sum() if weights.sum() > 0 else weights, inference['token_boxes'], image.size)
    mask = data.region_mask(sample)
    columns = max(3, len(row['views']))
    fig, grid = plt.subplots(2, columns, figsize=(5 * columns, 9), constrained_layout=True)
    for ax in grid.ravel():
        ax.axis('off')
    for i, metadata in enumerate(row['views']):
        occlusion = None
        if 'occlusion_mask' in metadata:
            with np.load(root / metadata['occlusion_mask'], allow_pickle=False) as file:
                occlusion = file['mask']
        observed = view(image, metadata['source_box'], metadata['requested_long_edge'], occlusion)
        grid[0, i].imshow(observed['image'])
        grid[0, i].set_title(f'Input view {i}: {metadata["label"]}')
    axes = grid[1, :3]
    for ax in axes:
        ax.imshow(image)
        ax.axis('off')
    axes[0].set_title('Original image and annotated evidence')
    if mask is not None and mask.any():
        axes[0].contour(mask, levels=[.5], colors=['lime'], linewidths=.8)
    axes[1].imshow(heatmap, cmap='magma', alpha=.65, vmin=0, vmax=max(float(np.quantile(heatmap, .995)), 1e-12))
    axes[1].set_title('Prefill global attention (source coordinates)')
    for x1,y1,x2,y2 in row['predicted_boxes']:
        axes[2].add_patch(Rectangle((x1,y1),x2-x1,y2-y1,fill=False,edgecolor='cyan',linewidth=1.5))
    axes[2].set_title(row['prediction']['status'] + ': ' + row['prediction']['answer'][:65])
    fig.suptitle(f'{row["model"]} | E{row["experiment"]} {row["condition"]}\n{row["sample_id"]}', fontsize=10)
    output = root / 'figures' / (path.stem + '.png')
    output.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(output, dpi=180)
    plt.close(fig)
    return output
