"""All boxes use continuous original-image xyxy coordinates."""
import math
import numpy as np
from PIL import Image


def full_box(size):
    return [0, 0, size[0], size[1]]


def annotation_area(region):
    if region.get('area') is not None:
        return float(region['area'])
    x1, y1, x2, y2 = region['bbox_xyxy']
    return max(0., x2 - x1) * max(0., y2 - y1)


def pixel_bounds(box, size):
    w, h = size
    x1, y1, x2, y2 = box
    return (max(0, math.ceil(x1 - .5)), max(0, math.ceil(y1 - .5)),
            min(w, math.ceil(x2 - .5)), min(h, math.ceil(y2 - .5)))


def box_from_mask(mask):
    yy, xx = np.nonzero(mask)
    return None if len(xx) == 0 else [int(xx.min()), int(yy.min()), int(xx.max() + 1), int(yy.max() + 1)]


def expand_box(box, size, fraction=.1):
    x1, y1, x2, y2 = box
    dx, dy = (x2 - x1) * fraction, (y2 - y1) * fraction
    return [max(0, math.floor(x1 - dx)), max(0, math.floor(y1 - dy)),
            min(size[0], math.ceil(x2 + dx)), min(size[1], math.ceil(y2 + dy))]


def resize_long_edge(image, edge):
    if edge is None:
        return image.copy()
    ratio = edge / max(image.size)
    return image.resize(tuple(max(1, round(v * ratio)) for v in image.size), Image.Resampling.LANCZOS)


def view(image, box=None, edge=None, occlusion=None, label='image'):
    box = [int(round(v)) for v in (box or full_box(image.size))]
    canvas = image.copy()
    if occlusion is not None:
        if occlusion.shape != (image.height, image.width):
            raise ValueError('Occlusion dimensions differ from source')
        canvas.paste((128, 128, 128), (0, 0, image.width, image.height),
                     Image.fromarray(occlusion.astype('uint8') * 255))
    cropped = canvas.crop(tuple(box))
    output = resize_long_edge(cropped, edge)
    result = dict(image=output, source_box=box, source_size=list(image.size),
                  input_size=list(output.size), requested_long_edge=edge, label=label,
                  occluded_pixels=int(occlusion.sum()) if occlusion is not None else 0)
    if occlusion is not None:
        result['_occlusion'] = occlusion
    return result


def grid_boxes(rows, cols, box, view_index=0):
    x1, y1, x2, y2 = box
    return [dict(view=view_index, bbox=[x1 + c * (x2 - x1) / cols,
                                      y1 + r * (y2 - y1) / rows,
                                      x1 + (c + 1) * (x2 - x1) / cols,
                                      y1 + (r + 1) * (y2 - y1) / rows])
            for r in range(rows) for c in range(cols)]


def map_box(normalized, source_box):
    x1, y1, x2, y2 = source_box
    a, b, c, d = normalized
    return [x1 + a * (x2 - x1), y1 + b * (y2 - y1),
            x1 + c * (x2 - x1), y1 + d * (y2 - y1)]


def matched_control(mask, rng, trials=256, max_overlap=.05):
    """Translate the whole target mask; preserve its area and shape exactly."""
    bounds = box_from_mask(mask)
    if bounds is None:
        return None
    x1, y1, x2, y2 = bounds
    patch = mask[y1:y2, x1:x2]
    h, w = mask.shape
    candidates = [(0, 0), (w - patch.shape[1], h - patch.shape[0])]
    candidates += [(rng.randint(0, w - patch.shape[1]), rng.randint(0, h - patch.shape[0]))
                   for _ in range(trials)]
    for x, y in candidates:
        out = np.zeros_like(mask)
        out[y:y + patch.shape[0], x:x + patch.shape[1]] = patch
        if (out & mask).sum() / mask.sum() <= max_overlap:
            return out
    return None


def matched_control_box(box, target, rng, max_overlap=.05):
    h, w = target.shape
    bw, bh = int(box[2] - box[0]), int(box[3] - box[1])
    if bw > w or bh > h:
        return None
    locations = [(0, 0), (w - bw, h - bh)]
    locations += [(rng.randint(0, w - bw), rng.randint(0, h - bh)) for _ in range(256)]
    for x, y in locations:
        if target[y:y + bh, x:x + bw].sum() / max(1, target.sum()) <= max_overlap:
            return [x, y, x + bw, y + bh]
    return None


def top_area_mask(heatmap, pixels):
    count = min(max(0, int(pixels)), heatmap.size)
    # Stable sorting fixes ties by row-major pixel order.
    order = np.argsort(-heatmap.ravel(), kind='stable')[:count]
    out = np.zeros(heatmap.size, dtype=bool)
    out[order] = True
    return out.reshape(heatmap.shape)

