"""E4 scientific plots from saved measurements; never invent or rerun inference."""
from collections import defaultdict
from pathlib import Path
import numpy as np
from .common import read_json, write_json, fingerprint


def render_figures(root, data, pair_id=None):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    from matplotlib.patches import Rectangle
    from .analysis import load_records
    from .metrics import project_mass
    root=Path(root);out=root/'figures/e4';out.mkdir(parents=True,exist_ok=True)
    changes=read_json(root/'summary/e4_paired_changes.json')
    saved=[]
    for metric in ('joint_correct','attention_coverage10'):
        fig,axes=plt.subplots(1,4,figsize=(16,4),constrained_layout=True)
        for ax,dataset in zip(axes,('vistaqa','gseval','groundingme','hallusegbench')):
            groups=defaultdict(list)
            for r in changes:
                if (r['dataset']==dataset and r['metric']==metric and r['axis']=='resolution'
                        and r['left']=='resolution_384' and r['right'] in {'resolution_768','resolution_1152'}
                        and r['output_cohort']=='valid_outputs' and r['source_cohort']=='all_sources'
                        and r['eligibility']=='complete_three_way' and r['statistic']=='delta' and r['mean'] is not None):
                    groups[r['task_type']].append(r)
            for task,rows in sorted(groups.items()):
                rows.sort(key=lambda r:int(r['right'].split('_')[1]))
                x=[int(r['right'].split('_')[1]) for r in rows]
                y=[r['mean'] for r in rows]
                ax.plot(x,y,marker='o',label=task)
                for edge,r in zip(x,rows):
                    if r['low'] is not None:
                        ax.vlines(edge,r['low'],r['high'],alpha=.6)
                    ax.annotate(f'n={r["n"]}',(edge,r['mean']),fontsize=7,xytext=(3,5),textcoords='offset points')
            ax.axhline(0,color='gray',lw=.7);ax.set_title(dataset);ax.set_xlabel('Requested long edge')
            ax.set_xticks([768,1152])
            if groups:
                ax.legend(fontsize=6)
            else:
                ax.text(.5,.5,'No eligible/scored paired data',ha='center',transform=ax.transAxes,fontsize=8)
        axes[0].set_ylabel('Paired change from 384')
        fig.suptitle(metric+' | native long edge >= 1152 | source-cluster 95% intervals')
        path=out/(metric+'_resolution.png');fig.savefig(path,dpi=160);plt.close(fig);saved.append(str(path))
    rows=load_records(root)
    pairs=defaultdict(dict)
    for row in rows:
        if row['experiment']==4 and row['condition']=='fact_baseline' and row.get('pair_id'):
            pairs[row['pair_id']][row['native_condition']]=row
    if pair_id is not None and pair_id not in pairs:
        raise ValueError('Pair is absent from this run: '+pair_id)
    selected=[]
    if pair_id:
        selected=[pair_id]
    else:
        # Deterministic examples for each task/outcome stratum, not hand-picked maps.
        mechanisms={r['sample_id']:r for r in read_json(root/'summary/e4_mechanisms.json') if r['condition']=='fact_baseline'}
        seen=set()
        for pid,cells in sorted(pairs.items()):
            if len(cells)!=4 or any(r['status']!='ok' for r in cells.values()):
                continue
            a=cells['factual_original'];b=cells['counterfactual_original']
            status='success' if all(r['scores'].get('task_correct') for r in cells.values()) else 'failure'
            if any(mechanisms.get(r['sample_id'],{}).get('covered_status_failed') for r in cells.values()):
                status='covered_status_failed'
            key=(a['task_type'],status)
            if key not in seen:
                selected.append(pid);seen.add(key)
    order=('factual_original','counterfactual_original','factual_replacement','counterfactual_replacement')
    for pid in selected:
        cells=pairs[pid]
        fig,axes=plt.subplots(2,4,figsize=(16,8),constrained_layout=True)
        for column,name in enumerate(order):
            row=cells.get(name)
            for ax in axes[:,column]:ax.axis('off')
            if not row or row['status']!='ok':
                axes[0,column].set_title(name+'\nNo measured observation');continue
            sample=data.get(row['sample_id']);image=data.image(sample)
            inference=read_json(root/'cache'/(row['request_id']+'.json'))
            with np.load(root/'cache'/inference['attention_file'],allow_pickle=False) as arrays:
                weights=arrays['layer_weights'].mean(axis=0)
            mass=weights.sum()
            heat=project_mass(weights/mass if mass>0 else weights,inference['token_boxes'],image.size)
            # Per-image display scaling is declared; use numeric tables for cross-image comparisons.
            axes[0,column].imshow(image);axes[1,column].imshow(image)
            axes[1,column].imshow(heat,cmap='magma',alpha=.65,vmin=0,vmax=max(float(np.quantile(heat,.995)),1e-12))
            regions=sample.get('intervention_regions') or sample['reference']['regions']
            mask=data.region_mask(dict(sample,reference=dict(sample['reference'],regions=regions,region_kind='mask')))
            if mask is not None and mask.any():
                axes[0,column].contour(mask,levels=[.5],colors=['lime'],linewidths=.8)
            for x1,y1,x2,y2 in row['predicted_boxes']:
                axes[0,column].add_patch(Rectangle((x1,y1),x2-x1,y2-y1,fill=False,edgecolor='cyan'))
            axes[0,column].set_title(name+'\n'+str(row['prediction']['status'])+' | correct='+str(row['scores'].get('task_correct')),fontsize=8)
            axes[1,column].set_title('Prefill attention; per-image display scale',fontsize=8)
        fig.suptitle(pid+'\nGreen: annotated target/replacement region; cyan: prediction. No image registration assumed.',fontsize=9)
        path=out/('pair_'+fingerprint(pid)[:16]+'.png');fig.savefig(path,dpi=160);plt.close(fig);saved.append(str(path))
    write_json(out/'manifest.json',dict(figures=saved,pair_ids=selected,
        selection='Explicit pair ID, or first sorted complete pair in each task/outcome stratum',
        heatmap_display='Per-image 99.5th percentile; not a quantitative cross-image heatmap distance'))
    return out
