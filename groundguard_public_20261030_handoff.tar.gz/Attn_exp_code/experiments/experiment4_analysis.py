"""E4 paired estimands, explicit denominators, and source-cluster uncertainty."""
from collections import defaultdict
from itertools import combinations
from pathlib import Path
import numpy as np
from .common import write_json
from .experiment4 import FACT_CONDITIONS

FACT_CONTRASTS = (
    ('fixed_original_query', 'factual_original', 'counterfactual_original'),
    ('fixed_replacement_query', 'counterfactual_replacement', 'factual_replacement'),
    ('query_change_original_image', 'factual_original', 'factual_replacement'),
    ('query_change_edited_image', 'counterfactual_original', 'counterfactual_replacement'))
ACCURACIES = {'task_correct', 'answer_correct', 'status_correct', 'localization_correct',
              'localization_recall_correct', 'joint_correct'}
METRICS = ('task_correct', 'answer_correct', 'status_correct', 'localization_correct',
    'localization_recall_correct', 'joint_correct', 'false_positive', 'false_existence_assertion',
    'unknown', 'status_box_inconsistent', 'attention_mass', 'attention_enrichment', 'attention_coverage10',
    'region_mass', 'region_enrichment', 'region_coverage10')


def valid(row):
    return bool(row and row.get('status') == 'ok' and row.get('scores', {}).get('format_valid'))


def metric(row, key, cohort='valid_outputs'):
    if not row:
        return None
    if key.startswith(('attention_', 'region_')):
        # Prefill measurements are retained even if generation was invalid.
        if row['status'] != 'ok':
            return None
        a = row.get('attention', {})
        if key.startswith('region_'):
            a = a.get('intervention_region', {})
        suffix = key.split('_', 1)[1]
        if suffix == 'coverage10':
            return a.get('coverage_tie_averaged', {}).get('0.1')
        return a.get(('region_mass' if key.startswith('region_') else 'evidence_mass')
                     if suffix == 'mass' else suffix)
    ref = row.get('reference', {})
    if key.startswith('localization_') and not ref.get('regions'):
        return None
    if key == 'status_correct' and ref.get('answer_type') != 'grounding_presence':
        return None
    if not valid(row):
        return False if cohort == 'all_attempts' and row['status'] != 'skipped' and key in ACCURACIES else None
    scores = row['scores']
    if key == 'joint_correct':
        loc = scores.get('localization_correct') if ref.get('regions') else scores.get('no_target_boxes')
        answer = scores.get('answer_correct')
        return bool(loc and answer and scores['concrete_answer']) if loc is not None and answer is not None else None
    if key == 'unknown':
        return row['prediction']['status'] == 'UNKNOWN'
    return scores.get(key)


def estimate(values, repeats):
    from .analysis import interval
    result = interval(values, repeats)
    if result['source_groups'] < 2:
        result.update(low=None, high=None)
    return result


def quality(rows):
    return dict(planned=len(rows), valid=sum(valid(r) for r in rows),
        not_run=sum(r['status'] == 'not_run' for r in rows),
        errors=sum(r['status'] == 'error' for r in rows),
        skipped=sum(r['status'] == 'skipped' for r in rows),
        invalid=sum(r['status'] == 'ok' and not valid(r) for r in rows))


def task_macro(entries, repeats):
    """Equal task weights, resampling whole source groups shared by all tasks."""
    tasks=sorted({task for _,task,_ in entries})
    sources=sorted({source for source,_,value in entries if value is not None})
    sums=np.zeros((len(sources),len(tasks)));counts=np.zeros_like(sums)
    si={s:i for i,s in enumerate(sources)};ti={t:i for i,t in enumerate(tasks)}
    for source,task,value in entries:
        if value is not None:
            sums[si[source],ti[task]]+=float(value);counts[si[source],ti[task]]+=1
    denominators=counts.sum(axis=0)
    complete=bool(len(tasks)) and bool((denominators>0).all())
    point=float(np.mean(sums.sum(axis=0)/denominators)) if complete else None
    boot=[]
    if complete and len(sources)>1:
        rng=np.random.default_rng(42)
        for _ in range(repeats):
            indices=rng.integers(0,len(sources),len(sources));n=counts[indices].sum(axis=0)
            if (n>0).all():
                boot.append(float(np.mean(sums[indices].sum(axis=0)/n)))
    return dict(mean=point,low=float(np.quantile(boot,.025)) if boot else None,
        high=float(np.quantile(boot,.975)) if boot else None,n=int(counts.sum()),
        source_groups=len(sources),task_types=len(tasks),scored_task_types=int((denominators>0).sum()),
        bootstrap_complete_task_draws=len(boot),bootstrap_repeats=repeats,
        bootstrap_policy='Draw whole sources; macro undefined if a draw has no observations for a task')


def pair_metrics(a, b, cohort):
    result = dict(both_correct=None, stale_answer=None, stale_given_left_correct=None,
        both_status_correct=None, same_status=None, left_status_correct=None)
    va, vb = valid(a), valid(b)
    if cohort == 'valid_outputs' and not (va and vb):
        return result
    x, y = metric(a, 'joint_correct', cohort), metric(b, 'joint_correct', cohort)
    if x is not None and y is not None:
        result['both_correct'] = bool(x and y)
    sa, sb = metric(a, 'status_correct', cohort), metric(b, 'status_correct', cohort)
    if sa is not None and sb is not None:
        result['both_status_correct'] = bool(sa and sb)
    if va and vb:
        same = a['prediction']['status'] == b['prediction']['status']
        result.update(same_status=same, left_status_correct=sa,
            stale_answer=bool(sa and not sb and same),
            stale_given_left_correct=bool(not sb and same) if sa else None)
    return result


def summarize_experiment4(root, rows, config):
    from .analysis import dump_csv, spatial_js
    root = Path(root)
    rows = [r for r in rows if r['experiment'] == 4 and r.get('extra', {}).get('axis') in {'fact', 'resolution'}]
    if not rows:
        return
    repeats = config['bootstrap_repeats']
    threshold = config['experiment4_measurement']['covered_region_fraction']
    indexed, pairs, groups = defaultdict(dict), defaultdict(dict), defaultdict(list)
    mechanisms, geometry, metrics = [], [], []
    for row in rows:
        indexed[(row['subset'], row['sample_id'], row['seed'])][row['condition']] = row
        if row.get('pair_id'):
            pairs[(row['subset'], row['pair_id'], row['seed'])].setdefault(row['condition'], {})[row['native_condition']] = row
        for stratum in ('all', 'target:' + row['reference']['target_status']):
            cohorts = ['available']
            if row['extra'].get('complete_three_way'):
                cohorts.append('complete_three_way')
            for eligibility in cohorts:
                groups[(row['subset'], row['dataset'], row['task_type'], row['reference']['region_kind'],
                    row['condition'], eligibility, stratum)].append(row)
        cov = metric(row, 'attention_coverage10')
        rcov = metric(row, 'region_coverage10')
        covered = None if cov is None else cov >= threshold
        mechanisms.append(dict(subset=row['subset'], dataset=row['dataset'], task_type=row['task_type'],
            sample_id=row['sample_id'], source_group_id=row['source_group_id'], pair_id=row.get('pair_id'),
            condition=row['condition'], native_condition=row['native_condition'], status=row['status'],
            output_valid=valid(row), target_coverage10=cov, intervention_coverage10=rcov,
            target_covered=covered, target_uncovered=None if covered is None else not covered,
            covered_localization_failed=(not metric(row, 'localization_correct'))
                if covered and valid(row) and metric(row, 'localization_correct') is not None else None,
            covered_status_failed=(not metric(row, 'answer_correct'))
                if covered and valid(row) and metric(row, 'answer_correct') is not None else None,
            absent_target_box=metric(row, 'false_positive'),
            absent_region_covered_false_box=(metric(row, 'false_positive'))
                if rcov is not None and rcov >= threshold and valid(row) else None,
            false_existence_assertion=metric(row, 'false_existence_assertion'), unknown=metric(row, 'unknown')))
        if row.get('intervention') or row.get('geometry_baseline'):
            geometry.append(dict(sample_id=row['sample_id'], condition=row['condition'],
                source_group_id=row['source_group_id'], intervention=row.get('intervention'),
                full_view_geometry_baseline=row.get('geometry_baseline')))
    quality_rows,macro_groups = [],defaultdict(list)
    for key, group in sorted(groups.items()):
        dims = dict(zip(('subset','dataset','task_type','region_kind','condition','eligibility','stratum'),key))
        q = quality(group)
        quality_rows.append(dict(dims, **q))
        for cohort in ('all_attempts','valid_outputs'):
            for name in METRICS:
                e = estimate([(r['source_group_id'], metric(r,name,cohort)) for r in group],repeats)
                metrics.append(dict(dims, cohort=cohort, metric=name, **q,
                    excluded_or_unscored=len(group)-e['n'], **e))
                if dims['stratum']=='all':
                    macro_groups[(dims['subset'],dims['dataset'],dims['condition'],dims['eligibility'],cohort,name)].extend(
                        (r['source_group_id'],r['task_type'],metric(r,name,cohort)) for r in group)
    macro=[dict(zip(('subset','dataset','condition','eligibility','cohort','metric'),key),
                **task_macro(values,repeats)) for key,values in sorted(macro_groups.items())]
    # Four-cell contrasts: planned pairs remain rows even when one or both sides failed.
    factual, factual_groups = [], defaultdict(list)
    for (subset, pair_id, seed), conditions in sorted(pairs.items()):
        for condition, cells in sorted(conditions.items()):
            # Native sweeps have image-dependent eligibility. Only shared edges define contrasts.
            for contrast, left, right in FACT_CONTRASTS:
                a, b = cells.get(left), cells.get(right)
                if not a or not b:
                    continue  # Not a shared native edge; common fact baseline is always planned.
                dims = dict(subset=subset, dataset=a['dataset'], task_type=a['task_type'],
                    condition=condition, resolution=a['extra']['resolution'], contrast=contrast)
                entry = dict(dims, pair_id=pair_id, source_group_id=a['source_group_id'], seed=seed,
                    left=left, right=right, left_execution=a['status'], right_execution=b['status'],
                    both_valid=valid(a) and valid(b), left_valid=valid(a), right_valid=valid(b))
                for cohort in ('all_attempts', 'valid_outputs'):
                    values = pair_metrics(a,b,cohort)
                    ma, mb = metric(a,'region_mass'), metric(b,'region_mass')
                    values['region_attention_delta'] = mb-ma if ma is not None and mb is not None else None
                    entry[cohort] = values
                    for name, value in values.items():
                        factual_groups[(*dims.values(),cohort,name)].append((a['source_group_id'],value))
                factual.append(entry)
    factual_summary = []
    for key, values in sorted(factual_groups.items()):
        e=estimate(values,repeats)
        factual_summary.append(dict(zip(('subset','dataset','task_type','condition','resolution','contrast','cohort','metric'),key),
            planned_pairs=len(values), excluded_or_unscored=len(values)-e['n'], **e))
    # Within-image transitions: all resolution pairs plus region/control rescue.
    transitions, transition_groups = [], defaultdict(list)
    for conditions in indexed.values():
        resolutions=sorted((r for r in conditions.values() if r['extra']['axis']=='resolution'),key=lambda r:r['extra']['resolution'])
        contrasts=[(a,b,'resolution') for a,b in combinations(resolutions,2)]
        for left,right in [('fact_baseline','fact_region'),('fact_baseline','fact_control'),('fact_control','fact_region')]:
            if left in conditions and right in conditions:
                contrasts.append((conditions[left],conditions[right],'crop_rescue'))
        baseline=conditions.get('fact_baseline')
        for a,b,axis in contrasts:
            dims=dict(subset=a['subset'],dataset=a['dataset'],task_type=a['task_type'],
                axis=axis,left=a['condition'],right=b['condition'],
                eligibility='complete_three_way' if a['extra'].get('complete_three_way') else 'other_sources')
            entry=dict(dims,sample_id=a['sample_id'],source_group_id=a['source_group_id'],
                pair_id=a.get('pair_id'),native_condition=a['native_condition'],
                left_execution=a['status'],right_execution=b['status'],both_valid=valid(a) and valid(b))
            cohorts=['all_sources']
            if baseline and valid(baseline):
                if metric(baseline,'joint_correct') is False:
                    cohorts.append('baseline_failed')
                # Fixed-query positive->negative comparisons orient the source as the present target.
                counterpart={'counterfactual_original':'factual_original','factual_replacement':'counterfactual_replacement'}.get(a['native_condition'])
                if counterpart:
                    original=pairs[(a['subset'],a['pair_id'],a['seed'])].get('fact_baseline',{}).get(counterpart)
                    if original and valid(original) and metric(original,'joint_correct') is True and metric(baseline,'joint_correct') is False:
                        cohorts.append('fact_update_failed_after_correct_source')
            for output_cohort in ('all_attempts','valid_outputs'):
                for name in METRICS:
                    x,y=metric(a,name,output_cohort),metric(b,name,output_cohort)
                    # Behavior in valid-output contrasts requires both endpoints valid; attention does not.
                    attention=name.startswith(('attention_','region_'))
                    if output_cohort=='valid_outputs' and not attention and not entry['both_valid']:
                        x=y=None
                    values={'delta':float(y)-float(x) if x is not None and y is not None else None}
                    if name in ACCURACIES:
                        values.update(repair=y if x is not None and not x else None,
                                      degrade=(not y) if x and y is not None else None)
                    for cohort in cohorts:
                        for statistic,value in values.items():
                            transition_groups[(*dims.values(),cohort,output_cohort,name,statistic)].append((a['source_group_id'],value))
            entry['attention_spatial_js']=spatial_js(a,b,root) if axis=='resolution' and a['status']==b['status']=='ok' else None
            if axis=='resolution':
                transition_groups[(*dims.values(),'all_sources','measured_prefill','attention_spatial_js','distance')].append((a['source_group_id'],entry['attention_spatial_js']))
            entry['analysis_cohorts']=cohorts
            transitions.append(entry)
    paired=[]
    for key,values in sorted(transition_groups.items()):
        e=estimate(values,repeats)
        paired.append(dict(zip(('subset','dataset','task_type','axis','left','right','eligibility','source_cohort','output_cohort','metric','statistic'),key),
            planned_pairs=len(values),excluded_or_unscored=len(values)-e['n'],**e))
    output=root/'summary'
    mechanism_groups=defaultdict(list)
    for row in mechanisms:
        for name in ('target_uncovered','covered_localization_failed','covered_status_failed',
                     'absent_target_box','absent_region_covered_false_box','false_existence_assertion','unknown'):
            mechanism_groups[(row['subset'],row['dataset'],row['task_type'],row['condition'],name)].append(
                (row['source_group_id'],row[name]))
    mechanism_summary=[]
    for key,values in sorted(mechanism_groups.items()):
        e=estimate(values,repeats)
        mechanism_summary.append(dict(zip(('subset','dataset','task_type','condition','metric'),key),
            planned=len(values),excluded_or_unscored=len(values)-e['n'],**e))
    for name,items in [('e4_metrics',metrics),('e4_task_macro',macro),('e4_output_quality',quality_rows),('e4_fact_pairs',factual),
            ('e4_fact_summary',factual_summary),('e4_transitions',transitions),('e4_paired_changes',paired),
            ('e4_mechanisms',mechanisms),('e4_mechanism_summary',mechanism_summary),('e4_geometry',geometry)]:
        write_json(output/(name+'.json'),items); dump_csv(output/(name+'.csv'),items)
    write_json(output/'e4_analysis_policy.json',dict(version=1,
        primary_tables='e4_*; generic tables are auxiliary legacy summaries',
        coverage_threshold=threshold,coverage_metric='fractional top-10%-area target coverage',
        attention_cohort='all measured prefill, regardless of output validity',
        behavior_cohorts=['valid_outputs','all_attempts'],
        error_policy='Expected error/not_run rows retained; accuracy sensitivity counts them as failures; skips remain missing',
        crop_scope='Annotation-assisted target/replacement inspection, not complete reasoning evidence',
        spatial_distance='Same-source-image resolution pairs only; no unregistered original/edited pixel comparison',
        clustering='source_group_id; tasks and datasets reported separately',synthetic='deferred'))
