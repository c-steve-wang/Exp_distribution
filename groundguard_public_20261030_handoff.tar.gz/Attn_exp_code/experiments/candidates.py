import numpy as np
from PIL import Image, ImageFilter
from .common import fingerprint
from .geometry import full_box, grid_boxes, pixel_bounds, resize_long_edge
from .protocol import final_json, valid_box


def saliency(image):
    """Fixed spectral-residual saliency, computed only from the 384px overview."""
    small = image.convert('L').resize((64, 64), Image.Resampling.BILINEAR)
    array = np.asarray(small, dtype=float)
    spectrum = np.fft.fft2(array)
    log_amplitude = np.log(np.abs(spectrum) + 1e-8)
    mean = sum(np.roll(np.roll(log_amplitude, a, 0), b, 1) for a in [-1, 0, 1] for b in [-1, 0, 1]) / 9
    residual = np.exp(log_amplitude - mean + 1j * np.angle(spectrum))
    values = np.abs(np.fft.ifft2(residual)) ** 2
    values = np.asarray(Image.fromarray(values.astype('float32')).resize(image.size, Image.Resampling.BILINEAR))
    return np.maximum(values, 0)


def proposed_boxes(text, size):
    result = final_json(text)
    boxes = result.get('regions')
    if not isinstance(boxes, list):
        raise ValueError('Proposal response lacks regions')
    if len(boxes) > 8 or any(not valid_box(b) for b in boxes):
        raise ValueError('Proposal response has invalid regions')
    w, h = size
    return [[round(b[0] * w), round(b[1] * h), round(b[2] * w), round(b[3] * h)] for b in boxes]


def build_candidates(image, question_boxes):
    size = image.size
    overview = resize_long_edge(image, 384)
    sal = saliency(overview)
    h, w = sal.shape
    bw, bh = max(1, w // 4), max(1, h // 4)
    suppressed = sal.copy()
    salient = []
    for _ in range(8):
        y, x = np.unravel_index(np.argmax(suppressed), sal.shape)
        left, top = max(0, min(w - bw, x - bw // 2)), max(0, min(h - bh, y - bh // 2))
        salient.append([round(left * size[0] / w), round(top * size[1] / h),
                        round((left + bw) * size[0] / w), round((top + bh) * size[1] / h)])
        suppressed[top:top + bh, left:left + bw] = -1
    grid = [[round(v) for v in b['bbox']] for b in grid_boxes(4, 4, full_box(size))]
    fallback = [b['bbox'] for divisions in [3, 5, 2, 6] for b in grid_boxes(divisions, divisions, full_box(size))]
    pools = dict(grid=grid, saliency=salient, question=list(question_boxes))
    schedule = ['grid', 'grid', 'saliency', 'question'] * 8
    seen, candidates = set(), []
    for desired in schedule:
        source = desired
        box = None
        while pools[desired]:
            candidate = [int(round(v)) for v in pools[desired].pop(0)]
            if tuple(candidate) not in seen and candidate[2] > candidate[0] and candidate[3] > candidate[1]:
                box = candidate
                break
        if box is None:
            source = 'grid_fallback'
            while fallback:
                candidate = [int(round(v)) for v in fallback.pop(0)]
                if tuple(candidate) not in seen and candidate[2] > candidate[0] and candidate[3] > candidate[1]:
                    box = candidate
                    break
        if box is None:
            raise ValueError('Could not construct 32 distinct candidate boxes')
        seen.add(tuple(box))
        sx1, sy1, sx2, sy2 = pixel_bounds([box[0] * w / size[0], box[1] * h / size[1],
                                         box[2] * w / size[0], box[3] * h / size[1]], (w, h))
        candidates.append(dict(index=len(candidates), bbox=box, source=source, scheduled_source=desired,
                               saliency_score=float(sal[sy1:sy2, sx1:sx2].mean())))
    return candidates


def candidate_attention_scores(candidates, heatmap):
    h, w = heatmap.shape
    values = []
    for item in candidates:
        x1, y1, x2, y2 = pixel_bounds(item['bbox'], (w, h))
        area = (x2 - x1) * (y2 - y1)
        values.append(float(heatmap[y1:y2, x1:x2].sum() / (area / (w * h))))
    return values


def coverage(candidates, masks, size, threshold=.9, counts=(8, 16, 32)):
    """Distinguish per-region availability in a pool from one feasible crop.

    Pool coverage may use a different candidate for each annotated instance.
    Single-candidate coverage requires the SAME candidate to cover every one.
    Neither measurement asserts that unannotated context has been acquired.
    """
    fractions = np.zeros((len(candidates), len(masks)), dtype=float)
    for j, mask in enumerate(masks):
        area = int(mask.sum())
        for i, item in enumerate(candidates):
            x1, y1, x2, y2 = pixel_bounds(item['bbox'], size)
            fractions[i, j] = mask[y1:y2, x1:x2].sum() / max(1, area)
    result = []
    for count in counts:
        pool = fractions[:count]
        measurable = bool(len(pool) and len(masks))
        region_hits = pool.max(axis=0) >= threshold if measurable else np.zeros(len(masks), dtype=bool)
        minimum = float(pool.min(axis=1).max()) if measurable else None
        result.append(dict(k=count, threshold=threshold, **candidate_composition(candidates[:count]),
            pool_all_regions_covered=measurable and bool(region_hits.all()),
            fraction_regions_covered=float(region_hits.mean()) if measurable else None,
            single_candidate_all_regions_covered=measurable and minimum >= threshold,
            best_single_candidate_min_region_coverage=minimum))
    return result


def candidate_composition(candidates):
    """Report actual proposal sources separately from their scheduled slots."""
    counts = {source + '_candidates': sum(c.get('source') == source for c in candidates)
              for source in ['grid', 'saliency', 'question', 'grid_fallback']}
    slots = sum(c.get('scheduled_source') == 'question' for c in candidates)
    return dict(candidate_count=len(candidates), question_slots=slots,
                question_shortfall=slots - counts['question_candidates'], **counts)

