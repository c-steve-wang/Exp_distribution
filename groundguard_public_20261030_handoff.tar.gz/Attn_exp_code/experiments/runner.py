"""Four frozen experiments; every observation is independently resumable."""
from pathlib import Path
from collections import defaultdict
from itertools import zip_longest
import math
import traceback
import numpy as np
from .common import read_json, write_json, fingerprint, rng_for, shard_contains
from .geometry import view, box_from_mask, expand_box, matched_control, matched_control_box, top_area_mask, annotation_area
from .candidates import build_candidates, proposed_boxes, candidate_attention_scores, candidate_composition, coverage
from .experiment2_protocol import PROPOSAL_SYSTEM, PROPOSAL_REMINDER
from .engine import synthetic_support

EXPERIMENT1_CONDITIONS = ('overview', 'overview_evidence', 'evidence_only', 'overview_control')


def experiment1_expected(sample, subset, seed):
    conditions = EXPERIMENT1_CONDITIONS if sample['reference']['regions'] else ('not_applicable',)
    return [dict(experiment=1, subset=subset, sample_id=sample['sample_id'], condition=condition,
                 seed=seed, extra={}, source_group_id=sample['source_group_id'], dataset=sample['dataset'],
                 task_type=sample['task_type']) for condition in conditions]


def record_identity(record):
    return {key: record[key] for key in ('experiment', 'subset', 'sample_id', 'condition', 'seed', 'extra')}


def interleave_samples(samples):
    """Schedule whole source groups across datasets without changing membership."""
    datasets = defaultdict(dict)
    for sample in samples:
        datasets[sample['dataset']].setdefault(sample['source_group_id'], []).append(sample)
    ordered = []
    groups = [list(datasets[name].values()) for name in sorted(datasets)]
    for batch in zip_longest(*groups):
        for group in batch:
            if group is not None:
                ordered.extend(group)
    return ordered


def seeds(config, spec, confirm=False):
    return config['confirmation_seeds' if confirm else 'audit_seeds'] if spec['generation']['do_sample'] else [config['seed']]


def proposal_path(data, subset, sample):
    return data.work_root / 'proposals' / subset / (fingerprint(sample['sample_id']) + '.json')


def audit_samples(data, config, subset):
    manifest = read_json(data.work_root / f'audit_{subset}.json')
    if manifest['data_fingerprint'] != data.fingerprint():
        raise ValueError('Audit data fingerprint differs; prepare in a new work directory')
    return [data.get(s) for s in manifest['sample_ids'] + manifest['synthetic_sample_ids']]


def pilot_rows(rows, fraction, seed, subset):
    """Sample source groups per dataset, stratified by their task/status labels.

    All records of a chosen source within that dataset stay together. Sampling
    uses only annotations, is independent of input order, and precedes sharding.
    """
    if not math.isfinite(fraction) or not 0 < fraction <= 1:
        raise ValueError('Pilot fraction must be in (0, 1]')
    datasets = defaultdict(lambda: defaultdict(list))
    for row in rows:
        datasets[row['dataset']][row['source_group_id']].append(row)
    selected = set()
    for name, groups in sorted(datasets.items()):
        count = math.ceil(len(groups) * fraction)
        strata = defaultdict(list)
        for group, records in sorted(groups.items()):
            label = tuple(sorted({(r['task_type'], r['reference']['target_status']) for r in records}))
            strata[label].append(group)
        # Largest-remainder allocation keeps the total at ceil(fraction * N).
        quotas = {label: count * len(ids) // len(groups) for label, ids in strata.items()}
        order = sorted(strata, key=lambda label: (-(count * len(strata[label]) % len(groups)), label))
        for label in order[:count - sum(quotas.values())]:
            quotas[label] += 1
        rng = rng_for(seed, 'pilot', subset, name)
        for label in sorted(strata):
            selected.update((name, group) for group in rng.sample(strata[label], quotas[label]))
    return [r for r in rows if (r['dataset'], r['source_group_id']) in selected]


def select_samples(data, config, experiment, subset, datasets=None, limit=None, shard_index=0, shards=1,
                   pilot_fraction=None, positive_only=False):
    if pilot_fraction is not None and limit is not None:
        raise ValueError('Choose either pilot_fraction or limit')
    rows = audit_samples(data, config, subset) if experiment == 2 else list(data.primary(subset, datasets))
    rows = [s for s in rows if datasets is None or s['dataset'] in datasets]
    if positive_only:
        rows = [s for s in rows if s['reference']['regions']]
    rows.sort(key=lambda s: (s['dataset'], s['source_group_id'], s['sample_id']))
    if pilot_fraction is not None:
        rows = pilot_rows(rows, pilot_fraction, config['seed'], subset)
    # Limit source groups before sharding so different shards partition the same selection.
    groups = list(dict.fromkeys(s['source_group_id'] for s in rows))
    if limit is not None:
        groups = groups[:limit]
    allowed = set(groups)
    return [s for s in rows if s['source_group_id'] in allowed and shard_contains(s['source_group_id'], shard_index, shards)]


def generate_proposals(engine, samples, subset, retry_errors=False):
    data, cfg = engine.data, engine.config
    failures = 0
    for sample in samples:
        path = proposal_path(data, subset, sample)
        identity = dict(data=data.fingerprint(), config=fingerprint(cfg), proposer=engine.backend.lock,
                        sample_id=sample['sample_id'], code=engine.identity['code'])
        if path.exists():
            previous = read_json(path)
            if previous['identity'] != identity:
                raise ValueError('Candidate protocol changed; use a new work directory')
            if previous['status'] == 'ok' or not retry_errors:
                failures += int(previous['status'] != 'ok')
                continue
        try:
            image = data.image(sample)
            overview = view(image, edge=cfg['overview_edge'], label='overview')
            from .experiment2_protocol import proposal_schema
            schema = dict(output_schema=proposal_schema()) if engine.backend.spec.get('structured_output') else {}
            result = engine.infer([overview], sample['question'] + PROPOSAL_REMINDER, sample['question'], PROPOSAL_SYSTEM,
                                  cfg['seed'], capture=False, **schema)
            try:
                boxes, parse_error = proposed_boxes(result['text'], image.size), None
            except ValueError as error:
                boxes, parse_error = [], str(error)
            candidates = build_candidates(image, boxes)
            write_json(path, dict(status='ok', identity=identity, request_id=result['request_id'],
                                 proposer_run=str(engine.run_dir), proposal_parse_error=parse_error,
                                 proposed_question_regions=len(boxes) if parse_error is None else None,
                                 candidate_composition=candidate_composition(candidates), candidates=candidates))
        except Exception as error:
            failures += 1
            write_json(path, dict(status='error', identity=identity, error=repr(error), traceback=traceback.format_exc()))
        print(f'proposal {sample["sample_id"]}', flush=True)
    return failures


def policy_order(policy, candidates, attention, seed, sample_id):
    indices = list(range(len(candidates)))
    if policy == 'attention':
        return sorted(indices, key=lambda i: (-attention[i], i))
    if policy == 'saliency':
        return sorted(indices, key=lambda i: (-candidates[i]['saliency_score'], i))
    if policy == 'random':
        rng_for(seed, 'policy', sample_id).shuffle(indices)
        return indices
    if policy == 'question':
        # A grid box filling a question slot is still a grid box. Use genuine
        # question proposals first, then supplements in their fixed order.
        return sorted(indices, key=lambda i: (candidates[i]['source'] != 'question',
                                              candidates[i]['scheduled_source'] != 'question', i))
    return sorted(indices, key=lambda i: (candidates[i]['scheduled_source'] != 'grid', i))


class Runner:
    def __init__(self, engine, subset='test', retry_errors=False):
        self.engine, self.data, self.cfg = engine, engine.data, engine.config
        self.subset, self.retry_errors = subset, retry_errors

    def job(self, experiment, sample, condition, views, seed=42, extra=None, occlusions=None, skip=None, metadata=None):
        identity = dict(experiment=experiment, subset=self.subset, sample_id=sample['sample_id'],
                        condition=condition, seed=seed, extra=extra or {})
        path = self.engine.run_dir / 'records' / (fingerprint(identity) + '.json')
        if path.exists():
            old = read_json(path)
            dependency_recovered = (experiment == 3 and metadata is not None and self.retry_errors
                                    and old['status'] == 'skipped' and skip is None)
            if not dependency_recovered and (old['status'] != 'error' or not self.retry_errors):
                if experiment == 2 and old['status'] == 'ok':
                    fields = ('source_box', 'source_size', 'input_size', 'label')
                    actual = [{key: v[key] for key in fields} for v in old['views']]
                    requested = [{key: v[key] for key in fields} for v in views]
                    if actual != requested:
                        raise ValueError('Cached action views disagree with the frozen candidate pool')
                return old
        record = dict(identity, source_group_id=sample['source_group_id'], dataset=sample['dataset'],
                      task_type=sample['task_type'], run_id=self.engine.run_id, model=self.engine.model_key)
        if metadata is not None:
            record.update(intervention=metadata, reference=sample['reference'], pair_id=sample.get('pair_id'),
                          native_condition=sample['condition'])
        try:
            if skip:
                record.update(status='skipped', reason=skip)
            else:
                support = synthetic_support(self.data, sample, views, occlusions)
                record.update(self.engine.evaluate(sample, views, seed, support_available=support,
                                                  experiment=experiment), status='ok')
        except Exception as error:
            record.update(status='error', error=repr(error), traceback=traceback.format_exc())
        write_json(path, record)
        return record

    def run(self, experiment, samples):
        from .experiment3 import enabled as e3_enabled, expected as e3_expected
        from .experiment4 import enabled as e4_enabled, expected as e4_expected
        e3 = experiment == 3 and e3_enabled(self.cfg)
        e4 = experiment == 4 and e4_enabled(self.cfg)
        def planned_for(sample):
            if e4:
                return e4_expected(self.data, sample, self.subset, self.cfg['seed'], self.cfg)
            if e3:
                return e3_expected(self.data, sample, self.subset, self.cfg['seed'])
            return experiment1_expected(sample, self.subset, self.cfg['seed'])
        if experiment == 1:
            expected = [r for sample in samples for r in experiment1_expected(sample, self.subset, self.cfg['seed'])]
            write_json(self.engine.run_dir / 'expected' / (fingerprint([self.subset, [s['sample_id'] for s in samples]]) + '.json'),
                       dict(records=expected))
        if e3 or e4:
            planned = [r for s in samples for r in planned_for(s)]
            write_json(self.engine.run_dir / 'expected' / (f'e{experiment}_' + fingerprint([self.subset, [s['sample_id'] for s in samples]]) + '.json'),
                       dict(records=planned))
        source_failures = 0
        for i, sample in enumerate(samples):
            marker = self.engine.run_dir / 'progress' / f'e{experiment}_{fingerprint([self.subset, sample["sample_id"]])}.json'
            write_json(marker, dict(experiment=experiment, subset=self.subset, sample_id=sample['sample_id'], completed=False))
            try:
                getattr(self, f'experiment{experiment}')(sample)
            except Exception as error:
                source_failures += 1
                # A missing baseline/candidate pool is a visible incomplete source, never a silent drop.
                path = self.engine.run_dir / 'source_errors' / f'e{experiment}_{fingerprint([self.subset, sample["sample_id"]])}.json'
                write_json(path, dict(experiment=experiment, subset=self.subset, sample_id=sample['sample_id'],
                                      error=repr(error), traceback=traceback.format_exc()))
                if experiment == 1 or e3 or e4:
                    # Preserve successful conditions; account for every remaining planned condition.
                    expected_rows = planned_for(sample)
                    for planned in expected_rows:
                        record_path = self.engine.run_dir / 'records' / (fingerprint(record_identity(planned)) + '.json')
                        if not record_path.exists() or read_json(record_path)['status'] == 'error':
                            write_json(record_path, dict(planned, run_id=self.engine.run_id, model=self.engine.model_key,
                                status='error', failure_scope='source', error=repr(error), traceback=traceback.format_exc()))
                print(f'ERROR {sample["sample_id"]}: {error}', flush=True)
            else:
                path = self.engine.run_dir / 'source_errors' / f'e{experiment}_{fingerprint([self.subset, sample["sample_id"]])}.json'
                path.unlink(missing_ok=True)
                write_json(marker, dict(experiment=experiment, subset=self.subset, sample_id=sample['sample_id'], completed=True))
            print(f'E{experiment} {i + 1}/{len(samples)} {sample["sample_id"]}', flush=True)
        selected = {s['sample_id'] for s in samples}
        if e3 or e4:
            selected = {r['sample_id'] for s in samples for r in planned_for(s)}
        records = [read_json(path) for path in (self.engine.run_dir / 'records').glob('*.json')]
        failures = sum(r['status'] == 'error' and r['experiment'] == experiment and r['subset'] == self.subset
                       and r['sample_id'] in selected for r in records)
        return dict(source_errors=source_failures, inference_errors=failures)

    def overview(self, image):
        return view(image, edge=self.cfg['overview_edge'], label='overview')

    def evidence_crop(self, image, mask):
        box = expand_box(box_from_mask(mask), image.size, self.cfg['crop_margin'])
        return view(image, box=box, edge=self.cfg['crop_edge'], label='evidence_crop')

    def experiment1(self, sample):
        if not sample['reference']['regions']:
            self.job(1, sample, 'not_applicable', [], skip='No annotated positive region')
            return
        image, mask = self.data.image(sample), self.data.region_mask(sample)
        if mask is None or not mask.any():
            raise ValueError('Positive annotation has no measurable region')
        overview, crop = self.overview(image), self.evidence_crop(image, mask)
        control = matched_control_box(crop['source_box'], mask, rng_for(self.cfg['seed'], 'control_crop', sample['sample_id']))
        for condition, views in [('overview', [overview]), ('overview_evidence', [overview, crop]), ('evidence_only', [crop])]:
            self.job(1, sample, condition, views, self.cfg['seed'])
        self.job(1, sample, 'overview_control', [overview, view(image, control, self.cfg['crop_edge'], label='control_crop')] if control else [],
                 self.cfg['seed'], skip=None if control else 'No same-shape low-overlap control crop')

    def experiment2(self, sample):
        image, mask = self.data.image(sample), self.data.region_mask(sample)
        if mask is None or not mask.any():
            raise ValueError('Action audit requires a measurable positive annotation')
        overview = self.overview(image)
        proposal = read_json(proposal_path(self.data, self.subset, sample))
        if (proposal['status'] != 'ok' or proposal['identity']['config'] != fingerprint(self.cfg)
                or proposal['identity']['sample_id'] != sample['sample_id']
                or proposal['identity']['data'] != self.data.fingerprint() or proposal['identity']['code'] != self.engine.identity['code']):
            raise ValueError('Missing or stale shared candidate manifest')
        candidates = proposal['candidates']
        if len(candidates) != 32 or [c['index'] for c in candidates] != list(range(32)):
            raise ValueError('Expected 32 ordered reference candidates')
        pool_id = bind_candidate_pool(self.engine, self.subset, sample, proposal)
        def job(condition, views, seed, **extra):
            return self.job(2, sample, condition, views, seed, extra=dict(candidate_pool=pool_id, **extra))
        reference = job('overview', [overview], self.cfg['seed'], stage='baseline')
        if reference['status'] != 'ok':
            raise ValueError('Overview attention unavailable; cannot rank candidates')
        attention = candidate_attention_scores(candidates, self.engine.heatmap(reference, image.size))
        audit = dict(sample_id=sample['sample_id'], source_group_id=sample['source_group_id'], dataset=sample['dataset'],
                     subset=self.subset, candidates=candidates, attention_scores=attention,
                     candidate_pool=pool_id, task_type=sample['task_type'], region_kind=sample['reference']['region_kind'],
                     min_instance_area_fraction=min(annotation_area(r) for r in sample['reference']['regions']) / (image.width * image.height),
                     geometry=coverage(candidates, [self.data.region_mask(sample, j) for j in range(len(sample['reference']['regions']))], image.size,
                                       counts=self.cfg['candidate_counts']),
                     proposal_identity=proposal['identity'], proposal_parse_error=proposal['proposal_parse_error'],
                     proposed_question_regions=proposal.get('proposed_question_regions'),
                     candidate_composition=candidate_composition(candidates))
        crops = [view(image, c['bbox'], self.cfg['crop_edge'], label=f'candidate_{c["index"]}') for c in candidates]
        generation_seeds = seeds(self.cfg, self.engine.backend.spec)
        audit['policy_seed'] = self.cfg['seed']
        audit['policy_orders'] = {str(k): {p: policy_order(p, candidates[:k], attention[:k], self.cfg['seed'], sample['sample_id'])
            for p in ['attention', 'saliency', 'question', 'grid', 'random']} for k in self.cfg['candidate_counts']}
        audit['generation_seeds'] = generation_seeds
        audit['confirmation_seeds'] = seeds(self.cfg, self.engine.backend.spec, confirm=True) if self.engine.backend.spec['generation']['do_sample'] else []
        planned = []
        def plan(condition, seed, **extra):
            planned.append(dict(experiment=2, subset=self.subset, sample_id=sample['sample_id'],
                source_group_id=sample['source_group_id'], dataset=sample['dataset'], task_type=sample['task_type'],
                condition=condition, seed=seed, extra=dict(candidate_pool=pool_id, **extra)))
        for seed in generation_seeds:
            plan('overview', seed, stage='baseline')
            plan('oracle_crop', seed, stage='oracle')
            for i in range(32):plan(f'candidate_{i:02d}', seed, stage='candidate', candidate=i)
        for k in self.cfg['candidate_counts']:
            for policy, order in audit['policy_orders'][str(k)].items():
                for budget in [b for b in self.cfg['budgets'] if b>0]:
                    chosen=order[:budget]
                    extra=dict(stage='selected', k=k, policy=policy, budget=budget, chosen=chosen,
                               chosen_sources=[candidates[i]['source'] for i in chosen])
                    for seed in generation_seeds:plan(f'{policy}_k{k}_b{budget}',seed,**extra)
                    if budget==1:
                        for seed in audit['confirmation_seeds']:
                            plan(f'confirm_{policy}_k{k}',seed,**dict(extra,stage='confirmation'))
        for seed in audit['confirmation_seeds']:plan('confirm_overview',seed,stage='confirmation_baseline')
        write_json(self.engine.run_dir/'expected'/('e2_'+fingerprint([self.subset,sample['sample_id']])+'.json'),
                   dict(records=planned))
        facts = dict(h0={}, actions={}, confirmation_h0={}, confirmation_actions={})
        for seed in generation_seeds:
            if sample['dataset'] == 'synthetic':
                # This independent free-observation call sees no original task question.
                facts['h0'][str(seed)] = self.engine.observe_facts([overview], seed)
            job('overview', [overview], seed, stage='baseline')
            job('oracle_crop', [overview, self.evidence_crop(image, mask)], seed, stage='oracle')
            for i, crop in enumerate(crops):
                job(f'candidate_{i:02d}', [overview, crop], seed, stage='candidate', candidate=i)
                if sample['dataset'] == 'synthetic':
                    facts['actions'][f'{seed}:{i}'] = self.engine.observe_facts([overview, crop], seed)
        for k in self.cfg['candidate_counts']:
            for policy in ['attention', 'grid', 'random', 'saliency', 'question']:
                order = policy_order(policy, candidates[:k], attention[:k], self.cfg['seed'], sample['sample_id'])
                for budget in [b for b in self.cfg['budgets'] if b > 0]:
                    chosen = order[:budget]
                    extra = dict(stage='selected', k=k, policy=policy, budget=budget, chosen=chosen,
                                 chosen_sources=[candidates[i]['source'] for i in chosen])
                    for seed in generation_seeds:
                        job(f'{policy}_k{k}_b{budget}', [overview] + [crops[i] for i in chosen], seed, **extra)
                    if self.engine.backend.spec['generation']['do_sample'] and budget == 1:
                        for seed in seeds(self.cfg, self.engine.backend.spec, confirm=True):
                            job('confirm_overview', [overview], seed, stage='confirmation_baseline')
                            job(f'confirm_{policy}_k{k}', [overview, crops[chosen[0]]], seed,
                                **dict(extra, stage='confirmation'))
                            if sample['dataset'] == 'synthetic':
                                facts['confirmation_h0'][str(seed)] = self.engine.observe_facts([overview], seed)
                                facts['confirmation_actions'][f'{seed}:{chosen[0]}'] = self.engine.observe_facts([overview, crops[chosen[0]]], seed)
        audit['facts'] = facts
        write_json(self.engine.run_dir / 'audits' / (fingerprint([self.subset, sample['sample_id']]) + '.json'), audit)

    def experiment3(self, sample):
        from .experiment3 import enabled, run
        if enabled(self.cfg):
            return run(self, sample)
        # Keep both hidden worlds; grouping later verifies equality after the exact view transform.
        worlds = [sample]
        if sample['dataset'] == 'synthetic' and not sample['reference']['global_ambiguous']:
            worlds.append(self.data.pair(sample)['I_minus'])
        elif sample['dataset'] == 'hallusegbench':
            worlds = list(self.data.pair(sample).values())
        for world in worlds:
            image, target = self.data.image(world), self.data.region_mask(world)
            overview = self.overview(image)
            baseline = self.job(3, world, 'visible', [overview], self.cfg['seed'])
            if target is None or not target.any():
                continue
            hidden = self.data.support_mask(world) if world['dataset'] == 'synthetic' else target
            obscured = view(image, edge=self.cfg['overview_edge'], occlusion=hidden, label='hidden_evidence')
            crop = self.evidence_crop(image, hidden)
            self.job(3, world, 'hidden_evidence', [obscured], self.cfg['seed'], occlusions=[hidden])
            self.job(3, world, 'hidden_reveal', [obscured, crop], self.cfg['seed'], occlusions=[hidden, None])
            control = matched_control(hidden, rng_for(self.cfg['seed'], 'control_mask', world['sample_id']),
                                      max_overlap=0 if world['dataset'] == 'synthetic' else .05)
            self.job(3, world, 'hidden_control', [view(image, edge=self.cfg['overview_edge'], occlusion=control, label='hidden_control')] if control is not None else [],
                     self.cfg['seed'], occlusions=[control], skip=None if control is not None else 'No area/shape-matched control mask')
            if baseline['status'] == 'ok':
                high = top_area_mask(self.engine.heatmap(baseline, image.size), int(hidden.sum()))
                self.job(3, world, 'hidden_attention', [view(image, edge=self.cfg['overview_edge'], occlusion=high, label='hidden_attention')],
                         self.cfg['seed'], occlusions=[high])
            else:
                self.job(3, world, 'hidden_attention', [], skip='Overview attention unavailable')

    def experiment4(self, sample):
        from .experiment4 import enabled, run
        if enabled(self.cfg):
            return run(self, sample)
        worlds = list(self.data.pair(sample).values()) if sample['pair_id'] else [sample]
        if sample['dataset'] not in {'synthetic', 'hallusegbench'}:
            worlds = [sample]
        for world in worlds:
            image = self.data.image(world)
            longest = max(image.size)
            edges = [e for e in self.cfg['resolutions'] if e <= longest]
            if longest < max(self.cfg['resolutions']) and longest not in edges:
                edges.append(longest)
            for edge in sorted(edges):
                self.job(4, world, f'resolution_{edge}', [view(image, edge=edge, label=f'resolution_{edge}')], self.cfg['seed'],
                         extra=dict(resolution=edge, complete_three_way=longest >= max(self.cfg['resolutions']), native_long_edge=longest))


def bind_candidate_pool(engine, subset, sample, proposal):
    """Freeze each source's pool before writing any results, including resumes.

    Binding per source allows pilot/full runs and disjoint shards to share a run.
    A changed proposer or geometry requires a separate output root, rather than
    allowing multiple incompatible versions of a source into the same summary.
    """
    payload = dict(identity=proposal['identity'], candidates=proposal['candidates'])
    pool_id = fingerprint(payload)
    path = engine.run_dir / 'candidate_pools' / (fingerprint([subset, sample['sample_id']]) + '.json')
    if path.exists():
        previous = read_json(path)
        if previous['fingerprint'] != pool_id or fingerprint(previous['pool']) != pool_id:
            raise ValueError('Candidate pool changed for this run; use a new output root')
    else:
        # No existing source may acquire a new pool identity retroactively.
        if not hasattr(engine, '_existing_action_sources'):
            records = (read_json(p) for p in (engine.run_dir / 'records').glob('*.json'))
            engine._existing_action_sources = {(r['subset'], r['sample_id']) for r in records if r['experiment'] == 2}
        if (subset, sample['sample_id']) in engine._existing_action_sources:
            raise ValueError('Existing experiment 2 records have no frozen candidate pool; use a new output root')
        write_json(path, dict(fingerprint=pool_id, subset=subset, sample_id=sample['sample_id'], pool=payload))
    return pool_id

