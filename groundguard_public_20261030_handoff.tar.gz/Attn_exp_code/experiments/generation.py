"""Compatibility helpers for the model card's published decoding settings."""
import math


class PresencePenalty:
    """Subtract a constant once for each token present in generated output.

    Same semantics as vLLM's apply_penalties: prompt tokens are excluded and
    repeated occurrences do not increase the penalty. Applied before sampling
    warpers by Transformers' custom logits_processor interface.
    Reference: https://github.com/vllm-project/vllm/blob/main/vllm/model_executor/layers/utils.py
    """
    def __init__(self, penalty, prompt_length):
        if not math.isfinite(penalty) or not -2 <= penalty <= 2:
            raise ValueError('presence_penalty must be finite and in [-2, 2]')
        if prompt_length < 0:
            raise ValueError('Negative prompt length')
        self.penalty, self.prompt_length = float(penalty), prompt_length

    def __call__(self, input_ids, scores):
        generated = input_ids[:, self.prompt_length:]
        if not generated.numel() or self.penalty == 0:
            return scores
        seen = scores.new_zeros(scores.shape)
        seen.scatter_(1, generated, 1.)
        return scores - self.penalty * seen


def native_eos_ids(model_eos, tokenizer_eos):
    """Respect both checkpoint end-of-text and tokenizer end-of-turn markers."""
    ids = list(model_eos) if isinstance(model_eos, (list, tuple)) else ([] if model_eos is None else [model_eos])
    if tokenizer_eos is not None:
        ids.append(tokenizer_eos)
    if not ids:
        raise ValueError('No native end token available')
    return list(dict.fromkeys(ids))


def final_response(raw_text, thinking_enabled):
    """A JSON draft inside unfinished thinking must never become an answer."""
    if not thinking_enabled:
        return raw_text, None
    if '</think>' not in raw_text:
        return '', False
    return raw_text.split('</think>', 1)[1].strip(), True
