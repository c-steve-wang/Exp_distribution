"""Single-action bottlenecks, explicitly separated from pool geometry."""
from collections import defaultdict
import numpy as np
from .metrics import LOCALIZATION_METRICS, rank_correlation, score_value


RECOVERY_COMPONENTS = {'answer_correct', 'detection_correct', 'joint_answer_localization', *LOCALIZATION_METRICS}


def policy_scores(audit, policy, k):
    """Higher means preferred. Preserve score ties; question uses executed order."""
    if policy == 'attention':
        return audit['attention_scores'][:k], 'attention_mass'
    if policy == 'saliency':
        values = [c.get('saliency_score') for c in audit['candidates'][:k]]
        return (values if all(v is not None for v in values) else None), 'saliency_score'
    if policy == 'question':
        from .runner import policy_order
        order = audit.get('policy_orders', {}).get(str(k), {}).get(policy)
        if order is None:
            order = policy_order(policy, audit['candidates'][:k], audit['attention_scores'][:k],
                                 audit.get('policy_seed', 42), audit['sample_id'])
        scores = [0] * k
        for rank, index in enumerate(order):
            scores[index] = k - rank
        return scores, 'proposal_order'
    return None, 'not_defined_for_' + policy


def area_stratum(area):
    return 'unmeasured' if area is None else 'empty' if area == 0 else 'small' if area < .01 else 'medium' if area < .1 else 'large'


def initial_state(score):
    return 'unmeasured' if score is None else 'all_correct' if score == 1 else 'all_incorrect' if score == 0 else 'mixed'


def seed_scores(records, component, expected):
    """A missing/failed replicate never becomes a smaller, biased audit pool."""
    if len(records) != len(expected) or {r['seed'] for r in records} != set(expected):
        return None
    scores = {}
    for row in records:
        score = score_value(row.get('scores', {}), component)
        if row['status'] != 'ok' or score is None:
            return None
        scores[row['seed']] = float(score)
    return scores


def average(scores):
    return float(np.mean(list(scores.values()))) if scores is not None else None


def recovery(before, after):
    if before is None or after is None:
        return None
    failed = [seed for seed, score in before.items() if score == 0]
    return float(np.mean([after[seed] for seed in failed])) if failed else None


def outcomes(audit, records, baseline, actions, confirmation_base, components):
    expected = audit.get('generation_seeds', sorted(r['seed'] for r in baseline))
    confirm_expected = audit.get('confirmation_seeds', sorted(confirmation_base))
    source = next((r for r in baseline if r['status'] == 'ok'), {})
    region_kind = audit.get('region_kind', source.get('reference', {}).get('region_kind', 'unmeasured'))
    area = audit.get('min_instance_area_fraction', source.get('min_instance_area_fraction'))
    initial_detection = initial_state(average(seed_scores(baseline, 'detection_correct', expected)))
    output = []
    for component in components:
        base_scores = seed_scores(baseline, component, expected)
        before = average(base_scores)
        by_action = [seed_scores(actions[i], component, expected) for i in range(len(audit['candidates']))]
        utilities = [average(scores) for scores in by_action]
        complete = before is not None and all(v is not None for v in utilities)
        oracle = seed_scores([r for r in records if r['extra'].get('stage') == 'oracle'], component, expected)
        for geometry in audit['geometry']:
            k = geometry['k']
            selected = [r for r in records if r['extra'].get('stage') == 'selected'
                        and r['extra']['k'] == k and r['extra']['budget'] == 1]
            for policy in sorted({r['extra']['policy'] for r in selected}):
                selected_rows = [r for r in selected if r['extra']['policy'] == policy]
                choices = {tuple(r['extra']['chosen']) for r in selected_rows}
                if len(choices) != 1:
                    raise ValueError('Selected action changed between replicates')
                chosen = next(iter(choices))[0]
                selected_scores = seed_scores(selected_rows, component, expected)
                chosen_mean = average(selected_scores)
                entry = dict(dataset=audit['dataset'], subset=audit['subset'], sample_id=audit['sample_id'],
                    source_group_id=audit['source_group_id'], k=k, policy=policy, component=component,
                    budget=1, gap_scope='single_candidate_action', audit_complete=complete,
                    selection_complete=selected_scores is not None, geometry=geometry,
                    candidate_pool=audit.get('candidate_pool'), region_kind=region_kind,
                    proposal_parse_error=audit.get('proposal_parse_error'),
                    proposed_question_regions=audit.get('proposed_question_regions'),
                    selected_sources=[audit['candidates'][i].get('source') for i in next(iter(choices))],
                    task_type=audit.get('task_type', source.get('task_type', 'unmeasured')),
                    area_stratum=area_stratum(area), initial_detection=initial_detection,
                    initial_outcome=initial_state(before), baseline_score=before,
                    selected_score=chosen_mean, oracle_score=average(oracle),
                    selected_gain=chosen_mean - before if before is not None and chosen_mean is not None else None)
                if component in RECOVERY_COMPONENTS:
                    entry.update(selected_recovery_rate=recovery(base_scores, selected_scores),
                                 oracle_recovery_rate=recovery(base_scores, oracle))
                checks = [r for r in records if r['extra'].get('stage') == 'confirmation'
                          and r['extra']['k'] == k and r['extra']['policy'] == policy]
                confirm_base = seed_scores(list(confirmation_base.values()), component, confirm_expected) if confirm_expected else None
                confirm_after = seed_scores(checks, component, confirm_expected) if confirm_expected else None
                gains = [confirm_after[s] - confirm_base[s] for s in confirm_expected] if confirm_base is not None and confirm_after is not None else []
                entry.update(confirmation_gain_mean=float(np.mean(gains)) if gains else None,
                             confirmation_replicates=len(gains), confirmation_expected=len(confirm_expected))
                if complete:
                    pool = np.array(utilities[:k]) - before
                    ranking, ranking_kind = policy_scores(audit, policy, k)
                    entry.update(spearman=rank_correlation(ranking, pool) if ranking is not None else None,
                        rho_score=ranking_kind, rho_direction='higher_preference_higher_utility',
                        all_equal=bool(np.ptp(pool) == 0), proposal_gap=float(max(utilities) - max(utilities[:k])),
                        best_gain=float(pool.max()), pool_best_score=float(max(utilities[:k])),
                        reference_best_score=float(max(utilities)))
                    if chosen_mean is not None:
                        regret = float(max(utilities[:k]) - chosen_mean)
                        entry.update(selection_gap=regret, best_action_hit=bool(abs(regret) < 1e-12),
                            normalized_regret=regret / float(np.ptp(pool)) if np.ptp(pool) > 0 else None)
                    if component in RECOVERY_COMPONENTS:
                        pool_best = {s: max(scores[s] for scores in by_action[:k]) for s in expected}
                        reference_best = {s: max(scores[s] for scores in by_action) for s in expected}
                        entry.update(pool_recovery_rate=recovery(base_scores, pool_best),
                                     reference_recovery_rate=recovery(base_scores, reference_best))
                output.append(entry)
    return output


ACTION_METRICS = ['proposal_gap', 'selection_gap', 'normalized_regret', 'spearman', 'best_action_hit',
    'all_equal', 'selected_gain', 'best_gain', 'baseline_score', 'selected_score', 'pool_best_score',
    'reference_best_score', 'oracle_score', 'pool_recovery_rate', 'reference_recovery_rate',
    'selected_recovery_rate', 'oracle_recovery_rate', 'confirmation_gain_mean']
GEOMETRY_METRICS = ['pool_all_regions_covered', 'fraction_regions_covered',
    'single_candidate_all_regions_covered', 'best_single_candidate_min_region_coverage',
    'grid_candidates', 'saliency_candidates', 'question_candidates', 'grid_fallback_candidates',
    'question_shortfall']


def action_tables(audits, repeats):
    from .analysis import interval
    dimensions = ['subset', 'dataset', 'region_kind', 'k', 'policy', 'component', 'budget']
    geometry = {}
    for row in audits:
        key = tuple(row[k] for k in ['subset', 'dataset', 'sample_id', 'k'])
        geometry[key] = {**{k: row[k] for k in ['subset', 'dataset', 'sample_id', 'source_group_id',
            'region_kind', 'task_type', 'area_stratum', 'initial_detection']},
            'proposal_parse_error': row.get('proposal_parse_error'),
            'proposed_question_regions': row.get('proposed_question_regions'), **row['geometry']}

    def aggregate(rows, dims, metrics, stratify):
        groups = defaultdict(list)
        for row in rows:
            labels = ['all'] if not stratify else ['task:' + row['task_type'],
                'area:' + row['area_stratum'], 'initial_detection:' + row['initial_detection']]
            if stratify and 'initial_outcome' in row:
                labels.append('initial_outcome:' + row['initial_outcome'])
            for label in labels:
                groups[(*[row[key] for key in dims], label)].append(row)
        result = []
        for key, group in sorted(groups.items()):
            for metric in metrics:
                estimate = interval([(r['source_group_id'], r.get(metric)) for r in group], repeats)
                result.append(dict(zip(dims, key[:-1]), stratum=key[-1], metric=metric,
                    attempted=len(group), unmeasured_or_ineligible=len(group)-estimate['n'], **estimate))
        return result
    geometry_rows = list(geometry.values())
    geometry_dims = ['subset', 'dataset', 'region_kind', 'k']
    return dict(action_summary=aggregate(audits, dimensions, ACTION_METRICS, False),
                action_stratified_summary=aggregate(audits, dimensions, ACTION_METRICS, True),
                candidate_coverage=geometry_rows,
                candidate_coverage_summary=aggregate(geometry_rows, geometry_dims, GEOMETRY_METRICS, False)
                    + aggregate(geometry_rows, geometry_dims, GEOMETRY_METRICS, True))
