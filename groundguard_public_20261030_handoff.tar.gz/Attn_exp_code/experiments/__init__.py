"""GroundGuard analysis experiments. GPU dependencies are imported only by backends."""

