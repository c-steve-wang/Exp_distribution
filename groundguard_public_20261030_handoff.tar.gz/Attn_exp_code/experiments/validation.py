"""Run only on server: compare hooked/unhooked eager outputs and native SDPA."""
from .common import write_json, fingerprint
from .geometry import view, box_from_mask, expand_box
from .protocol import SYSTEM, task_prompt, parse_prediction, allowed_statuses, prediction_contract
from .protocol import prediction_request
from .engine import code_fingerprint
import numpy as np
import hashlib


def validate_backend(backend, data, samples, config, output, generation_override=None, experiment=1):
    checks = []
    effective_generation = dict(backend.spec['generation'], **(generation_override or {}))
    if effective_generation['do_sample']:
        raise ValueError('Adapter validation must use deterministic decoding')
    for sample in samples:
        image = data.image(sample)
        mask = data.region_mask(sample)
        overview = view(image, edge=config['overview_edge'], label='overview')
        groups = [[overview]]
        if mask is not None and mask.any():
            crop = view(image, expand_box(box_from_mask(mask), image.size, config['crop_margin']), config['crop_edge'], label='crop')
            groups += [[overview, crop], [crop]]
        conditions = ['overview', 'overview_crop', 'crop'][:len(groups)]
        if experiment == 3:
            from .experiment3 import observation_set, request, attention_occlusion
            image, mask, observations = observation_set(data, sample, config)
            groups = [views for views, _ in observations.values() if views]
            conditions = [name for name, (views, _) in observations.items() if views]
        if experiment == 4:
            from .experiment4 import observation_set, request
            observations = observation_set(data, sample, config)
            conditions = [name for name, item in observations.items() if item['views']]
            groups = [observations[name]['views'] for name in conditions]
        for condition, views in zip(conditions, groups):
            contract = prediction_contract(config, views, experiment)
            parse_options = dict(strict=contract['strict'], allowed_box_views=contract['allowed_box_views'])
            progress_id = fingerprint(dict(code=code_fingerprint(), config=config,
                sample_id=sample['sample_id'], condition=condition))[:20]
            def check_task_output(result, mode):
                if experiment not in (3, 4):
                    return
                from .experiment3 import box_limit
                prediction = parse_prediction(result['text'], len(views),
                    finish_reason=result.get('finish_reason'), **parse_options)
                valid = (prediction['parse_error'] is None
                    and set(prediction) == {'answer', 'status', 'boxes', 'facts', 'parse_error'}
                    and prediction['status'] in allowed_statuses(sample['dataset'])
                    and len(prediction['boxes']) <= box_limit(sample['dataset'])
                    and len(prediction['facts']) <= 3
                    and all(set(b) == {'view', 'bbox'} for b in prediction['boxes']))
                if not valid:
                    diagnostic_only = experiment == 3
                    path = output/('diagnostics' if diagnostic_only else 'failures')/(progress_id+'_'+mode+'.json')
                    write_json(path, dict(sample_id=sample['sample_id'], condition=condition,
                        mode=mode, text=result['text'], finish_reason=result.get('finish_reason'),
                        output_tokens=result.get('output_tokens'), prediction=prediction,
                        completed_checks=len(checks), code=code_fingerprint(), config=config,
                        blocks_launch=not diagnostic_only))
                    if diagnostic_only:
                        print(f'WARNING: E3 {mode} model output is invalid; retained as a model failure; see ' + str(path), flush=True)
                        return False
                    raise ValueError(f'Experiment {experiment} protocol preflight failed; see ' + str(path))
                return True
            if experiment in (3, 4):
                print(f"E{experiment} preflight start: {sample['sample_id']} / {condition}", flush=True)
            kwargs = dict(views=views, question=sample['question'], seed=config['seed'],
                **prediction_request(sample,views,config,experiment,
                    structured=bool(backend.spec.get('structured_output')),contract=contract))
            if generation_override is not None:
                kwargs['generation_override'] = generation_override
            hooked = backend.infer(**kwargs, capture=True)
            hooked_format_valid = check_task_output(hooked, 'eager_hooked')
            if experiment == 3:
                weights = np.asarray(hooked['layer_weights'])
                if (not hooked['layer_names'] or not hooked['token_boxes']
                        or weights.shape != (len(hooked['layer_names']), len(hooked['token_boxes']))
                        or len(hooked['token_boxes']) != hooked['spatial_visual_tokens']
                        or not np.isfinite(weights).all() or (weights < 0).any()):
                    raise ValueError('Experiment 3 attention measurement is invalid')
            plain = backend.infer(**kwargs, capture=False)
            plain_format_valid = check_task_output(plain, 'eager_plain')
            probe = {k: v for k, v in kwargs.items() if k not in {'seed', 'generation_override', 'output_schema'}}
            hooked_logits = backend.prefill_logits(**probe, capture=True)
            plain_logits = backend.prefill_logits(**probe, capture=False)
            try:
                backend.decoder.set_attn_implementation('sdpa')
                sdpa = backend.infer(**kwargs, capture=False)
                sdpa_format_valid = check_task_output(sdpa, 'sdpa_plain')
                sdpa_logits = backend.prefill_logits(**probe, capture=False)
            finally:
                backend.decoder.set_attn_implementation('eager')
            if experiment == 3 and (hooked_logits.shape != plain_logits.shape
                    or sdpa_logits.shape != plain_logits.shape
                    or not all(np.isfinite(x).all() for x in (hooked_logits, plain_logits, sdpa_logits))):
                raise ValueError('Experiment 3 prefill logits are invalid')
            parse_options = dict(strict=contract['strict'], allowed_box_views=contract['allowed_box_views'])
            prediction = parse_prediction(plain['text'], len(views), finish_reason=plain.get('finish_reason'), **parse_options)
            checks.append(dict(sample_id=sample['sample_id'], condition=condition, views=len(views),
                hook_preserves_tokens=hooked['output_ids'] == plain['output_ids'],
                hook_logits_max_abs_diff=float(np.max(np.abs(hooked_logits - plain_logits))),
                hook_logits_allclose=bool(np.allclose(hooked_logits, plain_logits, rtol=1e-5, atol=1e-5)),
                sdpa_logits_max_abs_diff=float(np.max(np.abs(sdpa_logits - plain_logits))),
                sdpa_logits_mean_abs_diff=float(np.mean(np.abs(sdpa_logits - plain_logits))),
                sdpa_same_tokens=plain['output_ids'] == sdpa['output_ids'],
                hooked_text=hooked['text'], eager_text=plain['text'], sdpa_text=sdpa['text'],
                eager_output_tokens=plain.get('output_tokens'),
                eager_prediction=prediction, prediction_contract=contract,
                sdpa_prediction=parse_prediction(sdpa['text'], len(views), finish_reason=sdpa.get('finish_reason'), **parse_options),
                task_format_valid=prediction['parse_error'] is None and prediction['status'] in allowed_statuses(sample['dataset']),
                visual_tokens=hooked['spatial_visual_tokens'], layer_names=hooked['layer_names'],
                local_layer_names=hooked['local_layer_names'], preprocessing=hooked['preprocessing'],
                token_boxes=hooked['token_boxes'], views_metadata=[{k:v for k,v in x.items() if k not in {'image', '_occlusion'}} for x in views],
                view_pixel_sha256=[hashlib.sha256(v['image'].tobytes()).hexdigest() for v in views],
                query_mode=hooked['query_mode'], query_indices=hooked['query_indices'],
                eager_capture_seconds=hooked['inference_seconds'], eager_plain_seconds=plain['inference_seconds'],
                sdpa_seconds=sdpa['inference_seconds']))
            if experiment == 3:
                checks[-1].update(hooked_task_format_valid=hooked_format_valid,
                    task_format_valid=plain_format_valid, sdpa_task_format_valid=sdpa_format_valid,
                    hooked_finish_reason=hooked.get('finish_reason'), eager_finish_reason=plain.get('finish_reason'),
                    sdpa_finish_reason=sdpa.get('finish_reason'), attention_measurement_valid=True)
            if experiment in (3, 4):
                write_json(output/'progress'/(progress_id+'.json'), checks[-1])
                print(f"E{experiment} preflight checked {len(checks)}: {sample['sample_id']} / {condition}; "
                      f"tokens={plain.get('output_tokens')}; hook_equal={checks[-1]['hook_preserves_tokens']}", flush=True)
                if not (checks[-1]['hook_preserves_tokens'] and checks[-1]['hook_logits_allclose']):
                    raise ValueError('Attention hook changed generated tokens or logits; see ' +
                                     str(output/'progress'/(progress_id+'.json')))
            if experiment == 3 and condition == 'visible' and mask is not None and mask.any():
                from .metrics import project_mass
                weights = hooked['layer_weights'].mean(axis=0)
                heatmap = project_mass(weights, hooked['token_boxes'], image.size)
                high, _ = attention_occlusion(heatmap, mask.sum(), config['seed'], sample['sample_id'])
                if high is not None:
                    conditions.append('hidden_attention')
                    groups.append([view(image, edge=config['overview_edge'], occlusion=high, label='hidden_attention')])
    report = dict(backend=backend.metadata(), checks=checks, validation_generation=effective_generation,
        generation_override=generation_override,
        hook_validation_passed=bool(checks) and all(c['hook_preserves_tokens'] and c['hook_logits_allclose'] for c in checks),
        protocol_validation_passed=bool(checks) and all(c['task_format_valid'] for c in checks),
        format_errors=sum(not c['task_format_valid'] for c in checks),
        format_error_policy='record_as_model_failure_and_continue',
        note='Inspect spatial maps and SDPA/eager differences in a small trial run; all samples remain in the full analysis.')
    identity = dict(code=code_fingerprint(), backend=report['backend'], config=config, data=data.fingerprint(),
                    samples=[sample['sample_id'] for sample in samples], generation_override=generation_override)
    if experiment in (3, 4):
        identity['experiment'] = experiment
        report['format_error_policy'] = f'block_experiment{experiment}_launch'
    if experiment == 3:
        report.update(production_attention='eager',
            preflight_policy='e3_measurement_gate_v2',
            measurement_validation_passed=report['hook_validation_passed'] and all(c['attention_measurement_valid'] for c in checks),
            protocol_validation_passed=bool(checks) and all(c['task_format_valid'] and c['hooked_task_format_valid'] for c in checks),
            format_error_policy='record_as_model_failure_and_continue',
            hooked_format_errors=sum(not c['hooked_task_format_valid'] for c in checks),
            format_error_rate=report['format_errors']/len(checks) if checks else None,
            sdpa_format_errors=sum(not c['sdpa_task_format_valid'] for c in checks),
            sdpa_format_error_policy='record_diagnostic_only_not_used_for_experiment_inference')
    report['identity'] = identity
    path = output / (fingerprint(identity)[:20] + '.json')
    write_json(path, report)
    if not report['hook_validation_passed']:
        raise ValueError('Attention hook changed generated tokens; see ' + str(path))
    if not report['protocol_validation_passed']:
        if experiment == 4:
            raise ValueError(f'Experiment {experiment} protocol preflight failed; see ' + str(path))
        print(f"WARNING: {report['format_errors']}/{len(checks)} smoke outputs violate the task protocol. "
              f"Continue and count invalid outputs as model failures; report: {path}", flush=True)
    return path
