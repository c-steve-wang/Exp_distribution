import json
import math

SYSTEM = '''Analyze only the supplied images. Return your final response as one JSON object:
{"answer": "short answer", "status": "ANSWERED|UNKNOWN|MATCH|NO_MATCH|PRESENT|ABSENT",
 "boxes": [{"view": 0, "bbox": [x1,y1,x2,y2]}], "facts": ["short directly observed fact"]}.
Use fractional coordinates between 0.0 and 1.0 relative to the specified image view:
x is the fraction of image width and y is the fraction of image height.
For example, a box covering the entire supplied image is [0.0, 0.0, 1.0, 1.0].
Never output pixel coordinates or coordinates on a 0-to-1000 scale.
Every box must satisfy 0 <= x1 < x2 <= 1 and 0 <= y1 < y2 <= 1.
Number image views from 0 in their supplied order. Give boxes for all requested targets;
avoid repeating the same object across views. If no target matches, return an empty boxes list.
For a general question use ANSWERED or UNKNOWN. For a referring description use MATCH,
NO_MATCH or UNKNOWN. For an existence query use PRESENT, ABSENT or UNKNOWN.
Use UNKNOWN when the supplied observation cannot determine the answer.
Do not use external knowledge to invent visible objects. Keep the original task semantics.'''

PROPOSAL_SYSTEM = '''Using only this overview image and question, propose up to 8 regions
worth inspecting at higher resolution. Do not answer the question. Return final JSON
{"regions": [[x1,y1,x2,y2], ...]} with normalized coordinates in [0,1].'''

FACT_QUESTION = '''Record visible facts about the contents of a unique black frame, without answering a task question.
Return {"facts": ["count=N", "color=COLOR", "circle_left_of_square=yes|no"]}.
Count symbols only. COLOR is red, blue, cyan or mixed. Only include facts directly discernible;
omit uncertain or inapplicable fields. If no unique frame can be identified, return an empty list.'''
FACT_SYSTEM = 'Describe the supplied views using only the requested fact vocabulary. Return one JSON object.'

FORMAT_REMINDER = '''
Output requirements: Return exactly one JSON object, then stop. Do not repeat it.
Include answer, status, boxes, and facts. Use each JSON key once per object.
For every bbox, BOTH x and y must be decimal fractions between 0.0 and 1.0.
A full-image box is [0.0, 0.0, 1.0, 1.0]. Use x1 < x2 and y1 < y2.
Do not mix fractions with pixels or 0-to-1000 coordinates. Number supplied views
from zero. If no target can be located, use an empty boxes list and the appropriate
task status. Keep facts brief. Close all JSON brackets and braces.'''


def allowed_statuses(dataset):
    if dataset in {'gseval', 'groundingme'}:
        return {'MATCH', 'NO_MATCH', 'UNKNOWN'}
    if dataset == 'hallusegbench':
        return {'PRESENT', 'ABSENT', 'UNKNOWN'}
    return {'ANSWERED', 'UNKNOWN'}


def task_box_limit(dataset):
    """Task-wide generation budget; independent of reference counts and conditions."""
    return 1 if dataset in {'gseval', 'groundingme', 'hallusegbench'} else 64


def box_budget_instruction(limit):
    if limit == 0:
        return 'No image is supplied. Return an empty boxes list.\n'
    if limit == 1:
        return ('Return at most one tight bounding rectangle enclosing the requested target '
                'or target set; do not enumerate other objects or repeat the box across views.\n')
    return (f'Return one box per requested instance, with at most {limit} boxes total. '
            'Do not repeat an identical box or report the same target across multiple views.\n')


def prediction_schema(dataset, views, allowed_box_views=None, max_boxes=None):
    """Shared reference-blind task schema; geometry remains strictly checked after generation."""
    if type(views) is not int or views < 0:
        raise ValueError('View count must be a nonnegative integer')
    indices = list(range(views)) if allowed_box_views is None else list(allowed_box_views)
    if any(type(i) is not int or not 0 <= i < views for i in indices):
        raise ValueError('Allowed box view is not supplied')
    coordinate = dict(type='number', minimum=0, maximum=1)
    box = dict(type='object', properties=dict(view=dict(type='integer', enum=indices or [0]),
        bbox=dict(type='array', items=coordinate, minItems=4, maxItems=4)),
        required=['view', 'bbox'], additionalProperties=False)
    boxes = dict(type='array', items=box)
    if not indices:
        boxes['maxItems'] = 0
    elif max_boxes is not None:
        boxes['maxItems'] = max_boxes
    # maxLength in the pinned xgrammar rejects legal JSON escapes. Do not use it.
    return dict(type='object', properties=dict(answer=dict(type='string'),
        status=dict(type='string', enum=sorted(allowed_statuses(dataset))), boxes=boxes,
        facts=dict(type='array', items=dict(type='string'), maxItems=3)),
        required=['answer', 'status', 'boxes', 'facts'], additionalProperties=False)


def prediction_request(sample, views, config, experiment, structured=False, contract=None):
    """One request path for inference, controls and preflight; retain experiment-specific prompts."""
    if experiment == 3 and config.get('experiment3_measurement', {}).get('version') == 1:
        from .experiment3 import request
        return request(sample, views)
    if experiment == 4 and config.get('experiment4_measurement', {}).get('version') == 1:
        from .experiment4 import request
        return request(sample, views)
    max_boxes = (task_box_limit(sample['dataset']) if views else 0) if experiment in (1, 2) else None
    if experiment == 2 and config.get('experiment2_measurement'):
        from .experiment2_protocol import task_prompt as prompt, task_system
        result = dict(prompt=prompt(sample, len(views)), system=task_system(sample))
        allowed = None
    else:
        contract = contract or prediction_contract(config, views, experiment)
        result = dict(prompt=task_prompt(sample, strict=contract['strict'],
            localization_frame=contract['localization_frame'], max_boxes=max_boxes), system=SYSTEM)
        allowed = contract['allowed_box_views'] if views else None
    if structured:
        result['output_schema'] = prediction_schema(sample['dataset'], len(views), allowed, max_boxes=max_boxes)
    return result


def prediction_contract(config, views, experiment):
    """E1 output coordinates are explicit and do not affect other experiments."""
    if experiment == 4 and config.get('experiment4_measurement', {}).get('version') == 1:
        if not views or views[0]['source_box'] != [0, 0, *views[0]['source_size']]:
            raise ValueError('Experiment 4 requires a full-image coordinate view 0')
        return dict(strict=True, allowed_box_views=[0], localization_frame='overview',
                    protocol='experiment4_v1')
    if experiment == 3 and config.get('experiment3_measurement', {}).get('version') == 1:
        if not views or views[0]['source_box'] != [0, 0, *views[0]['source_size']]:
            raise ValueError('Experiment 3 requires a full-image coordinate view 0')
        return dict(strict=True, allowed_box_views=[0], localization_frame='overview',
                    protocol='experiment3_v1')
    measurement = config.get('experiment1_measurement', {}) if experiment == 1 else {}
    contract = dict(strict=(measurement.get('output_policy') == 'strict_single_json_v2'
                           or bool(config.get('model_defaults', {}).get('structured_output'))),
                    allowed_box_views=None, localization_frame='supplied_views')
    if measurement.get('localization_policy') == 'overview_view0_crop_only_diagnostic':
        if not views:
            raise ValueError('Localization requires a supplied view')
        if views[0].get('label') == 'overview':
            frame = 'overview'
        elif len(views) == 1:
            frame = 'crop_diagnostic'
        else:
            raise ValueError('Experiment 1 multiview input must start with the overview')
        contract.update(allowed_box_views=[0], localization_frame=frame)
    return contract


def task_prompt(sample, strict=False, localization_frame='supplied_views', max_boxes=None):
    task = ('existence query' if sample['dataset'] == 'hallusegbench' else
            'referring description' if sample['dataset'] in {'gseval', 'groundingme'} else 'general question')
    instruction = ''
    if strict:
        statuses = '|'.join(sorted(allowed_statuses(sample['dataset'])))
        instruction = (f'For this task, status must be exactly one of: {statuses}.\n'
                       'Report each physical target once. Do not output duplicate boxes across views.\n'
                       'Keep answer short and facts to at most three short items.\n')
        if localization_frame == 'supplied_views':
            instruction += 'Choose the clearest supplied view for each box.\n'
    if localization_frame == 'overview':
        instruction += ('All boxes MUST use view 0, the full overview image. '
                        'Coordinates must be relative to that overview. '
                        'If additional images are supplied, use them to inspect details, then locate '
                        'the target in view 0. Never report crop-relative boxes or boxes in other views.\n')
    elif localization_frame == 'crop_diagnostic':
        instruction += ('Only one cropped image is supplied. All boxes MUST use view 0 '
                        'with coordinates relative to this supplied crop.\n')
    if max_boxes is not None:
        instruction += box_budget_instruction(max_boxes)
    return f'Task type: {task}\n{instruction}Question:\n{sample["question"]}' + FORMAT_REMINDER


def parse_task_prediction(text, views, dataset, contract, finish_reason=None, schema=None):
    result = parse_prediction(text, views, strict=contract['strict'] or schema is not None,
        finish_reason=finish_reason, allowed_box_views=contract['allowed_box_views'])
    if schema is not None and result['parse_error'] is None:
        limit = schema['properties']['boxes'].get('maxItems')
        if (set(result) != {'answer', 'status', 'boxes', 'facts', 'parse_error'}
                or result['status'] not in allowed_statuses(dataset)
                or len(result['facts']) > 3
                or (limit is not None and len(result['boxes']) > limit)
                or any(set(box) != {'view', 'bbox'} for box in result['boxes'])):
            return dict(answer='', status=None, boxes=[], facts=[], parse_error='Invalid task output schema')
    return result


def json_object_strings(text):
    """Find complete outer objects without promoting nested fragments to answers."""
    tail = text.rsplit('</think>', 1)[-1]
    objects, depth, quoted, escaped, start = [], 0, False, False, None
    for position, char in enumerate(tail):
        if depth == 0:
            if char == '{':
                start, depth = position, 1
            continue
        if quoted:
            if escaped:
                escaped = False
            elif char == '\\':
                escaped = True
            elif char == '"':
                quoted = False
        elif char == '"':
            quoted = True
        elif char == '{':
            depth += 1
        elif char == '}':
            depth -= 1
            if depth == 0:
                objects.append(tail[start:position + 1])
    return objects, depth != 0


def unique_json_keys(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError('Duplicate JSON key: ' + key)
        result[key] = value
    return result


def final_json(text):
    objects, _ = json_object_strings(text)
    if not objects:
        raise ValueError('No complete final JSON object')
    # Choose by position, never by correctness. A complete but invalid final
    # answer must fail instead of falling back to an earlier valid answer.
    return json.loads(objects[-1], object_pairs_hook=unique_json_keys)


def valid_box(box):
    return (isinstance(box, list) and len(box) == 4 and
            all(isinstance(x, (int, float)) and not isinstance(x, bool) and math.isfinite(x) for x in box)
            and 0 <= box[0] < box[2] <= 1 and 0 <= box[1] < box[3] <= 1)


def parse_prediction(text, views, strict=False, finish_reason=None, allowed_box_views=None):
    try:
        if strict:
            if finish_reason == 'length':
                raise ValueError('Output reached the generation limit')
            objects, incomplete = json_object_strings(text)
            if len(objects) > 1:
                raise ValueError('Multiple final JSON objects; repeated generation')
            if incomplete:
                raise ValueError('Incomplete final JSON object')
            payload = text.strip()
            if payload.startswith('```json') and payload.endswith('```'):
                payload = payload[7:-3].strip()
            elif payload.startswith('```') and payload.endswith('```'):
                payload = payload[3:-3].strip()
            result = json.loads(payload, object_pairs_hook=unique_json_keys)
            if not isinstance(result, dict):
                raise ValueError('Final response must be a JSON object')
        else:
            result = final_json(text)
        if not isinstance(result.get('answer'), str):
            raise ValueError('Missing string answer')
        if result.get('status') not in {'ANSWERED', 'UNKNOWN', 'MATCH', 'NO_MATCH', 'PRESENT', 'ABSENT'}:
            raise ValueError('Invalid status')
        if not isinstance(result.get('boxes'), list):
            raise ValueError('Missing boxes list')
        for item in result['boxes']:
            if not isinstance(item, dict) or type(item.get('view')) is not int or not 0 <= item['view'] < views or not valid_box(item.get('bbox')):
                raise ValueError('Invalid normalized box or view index')
            if allowed_box_views is not None and item['view'] not in allowed_box_views:
                raise ValueError(f'Forbidden box view {item["view"]}; allowed views: {allowed_box_views}')
        if not isinstance(result.get('facts', []), list) or not all(isinstance(f, str) for f in result.get('facts', [])):
            raise ValueError('Invalid facts list')
        result['parse_error'] = None
        return result
    except (ValueError, TypeError, KeyError) as error:
        return dict(answer='', status=None, boxes=[], facts=[], parse_error=str(error))
