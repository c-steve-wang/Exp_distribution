from pathlib import Path
from collections import defaultdict
import json
import numpy as np
from PIL import Image
from groundguard_data import Dataset
from .common import fingerprint, rng_for, write_json, read_json, file_hash
from .geometry import annotation_area


class ExperimentData:
    def __init__(self, data_root, work_root, include_synthetic=False):
        self.public = Dataset(data_root)
        self.work_root = Path(work_root)
        self.synthetic_root = self.work_root / 'synthetic'
        self.synthetic = {}
        catalog = self.synthetic_root / 'catalog.jsonl'
        if include_synthetic and catalog.exists():
            self.synthetic = {r['sample_id']: r for r in map(json.loads, catalog.read_text().splitlines())}
        files = [self.public.root / 'build_report.json']
        files += sorted((self.public.root / 'manifests').glob('*.jsonl'))
        files += sorted((self.public.root / 'selections').glob('*.json'))
        self._fingerprint = fingerprint(dict(public={str(p.relative_to(self.public.root)): file_hash(p) for p in files},
                                             synthetic=file_hash(catalog) if include_synthetic and catalog.exists() else None))

    def get(self, sample_id):
        return self.synthetic[sample_id] if sample_id.startswith('synthetic/') else self.public.get(sample_id)

    def primary(self, subset='test', datasets=None):
        for sample in self.public.iter_samples(subset=subset):
            if datasets is None or sample['dataset'] in datasets:
                yield sample
        if datasets is None or 'synthetic' in datasets:
            for sample in sorted(self.synthetic.values(), key=lambda r: r['sample_id']):
                if sample['is_primary'] and sample['analysis_split'] == subset:
                    yield sample

    def image(self, sample):
        if sample['dataset'] != 'synthetic':
            return self.public.load_image(sample)
        with Image.open(self.synthetic_root / sample['image']['path']) as im:
            return im.convert('RGB')

    def region_mask(self, sample, region_index=None):
        if sample['dataset'] != 'synthetic':
            if region_index is None:
                return self.public.region_mask(sample)
            region = sample['reference']['regions'][region_index]
            if region['mask'] is not None:
                return self.public.mask(sample, region_index)
            one = dict(sample, reference=dict(sample['reference'], regions=[region]))
            return self.public.region_mask(one)
        mask = np.zeros((sample['image']['height'], sample['image']['width']), dtype=bool)
        regions = sample['reference']['regions']
        for region in regions if region_index is None else [regions[region_index]]:
            with Image.open(self.synthetic_root / region['mask']['path']) as image:
                mask |= np.asarray(image.convert('L')) > 0
        return mask

    def support_mask(self, sample):
        if sample['dataset'] == 'synthetic':
            with Image.open(self.synthetic_root / sample['support_mask']) as image:
                return np.asarray(image.convert('L')) > 0
        return self.region_mask(sample)

    def pair(self, sample):
        if sample['dataset'] == 'synthetic':
            return {s['condition']: s for s in self.synthetic.values() if s['source_group_id'] == sample['source_group_id']}
        return self.public.get_pair(sample)

    def fingerprint(self):
        return self._fingerprint


def stratified_sources(rows, count, rng, size_strata=False):
    grouped = defaultdict(list)
    for sample in rows:
        grouped[sample['source_group_id']].append(sample)
    representatives = [rng.choice(sorted(grouped[g], key=lambda r: r['sample_id'])) for g in sorted(grouped)]
    strata = defaultdict(list)
    for sample in representatives:
        label = sample['task_type']
        if size_strata:
            area = min(annotation_area(r) for r in sample['reference']['regions']) / (sample['image']['width'] * sample['image']['height'])
            label += ':small' if area < .01 else ':medium' if area < .1 else ':large'
        strata[label].append(sample)
    if len(representatives) < count:
        raise ValueError(f'Only {len(representatives)} sources for quota {count}')
    expected = {k: count * len(v) / len(representatives) for k, v in strata.items()}
    quotas = {k: int(v) for k, v in expected.items()}
    for key in sorted(quotas, key=lambda k: (-(expected[k] - quotas[k]), k))[:count - sum(quotas.values())]:
        quotas[key] += 1
    selected = []
    for key in sorted(strata):
        selected += rng.sample(sorted(strata[key], key=lambda r: r['sample_id']), quotas[key])
    return sorted(s['sample_id'] for s in selected)


def prepare_audit(data, config, subset):
    all_rows = list(data.primary(subset=subset))
    selected = []
    if subset != 'test':
        raise ValueError('All experiment data belongs to test; use a runtime limit for trial runs')
    quotas = config['audit_quotas']
    for key, count in quotas.items():
        name, _, task = key.partition(':')
        rows = [s for s in all_rows if s['dataset'] == name and
                (not task or s['task_type'] == task) and s['reference']['regions']]
        selected += stratified_sources(rows, count, rng_for(config['seed'], 'audit', subset, key), size_strata=name == 'vistaqa')
    synthetic = [s['sample_id'] for s in all_rows if s['dataset'] == 'synthetic'
                 and not s['reference']['global_ambiguous']]
    manifest = dict(schema_version=1, seed=config['seed'], subset=subset,
                    data_fingerprint=data.fingerprint(), sample_ids=sorted(selected),
                    synthetic_sample_ids=sorted(synthetic), quotas=quotas)
    path = data.work_root / f'audit_{subset}.json'
    if path.exists() and read_json(path) != manifest:
        raise ValueError('Existing audit differs; use a new work directory for a changed protocol')
    write_json(path, manifest)
    return manifest

