"""Frozen E3 contracts and interventions; reference labels never enter prompts."""
import hashlib
import numpy as np
from .common import rng_for
from .geometry import view, box_from_mask, expand_box, matched_control
from .metrics import box_matches
from .protocol import SYSTEM, allowed_statuses, prediction_schema

CONDITIONS = ('visible', 'hidden_evidence', 'hidden_reveal', 'hidden_control', 'hidden_attention')


def box_limit(dataset):
    """Task-wide budgets; never inspect an individual sample's reference labels."""
    return 1 if dataset in {'gseval', 'groundingme', 'hallusegbench'} else 64


def enabled(config):
    return config.get('experiment3_measurement', {}).get('version') == 1


def worlds(data, sample):
    if sample['dataset'] == 'hallusegbench':
        return list(data.pair(sample).values())
    if sample['dataset'] == 'synthetic' and not sample['reference']['global_ambiguous']:
        return [sample, data.pair(sample)['I_minus']]
    return [sample]


def expected(data, sample, subset, seed):
    return [dict(experiment=3, subset=subset, sample_id=w['sample_id'], condition=c,
                 seed=seed, extra={}, source_group_id=w['source_group_id'], dataset=w['dataset'],
                 task_type=w['task_type'], pair_id=w.get('pair_id'), native_condition=w['condition'],
                 reference=w['reference'])
            for w in worlds(data, sample)
            for c in (CONDITIONS if w['reference']['regions'] else ('visible',))]


def request(sample, views):
    """Schema and text depend on the task and supplied view count, never annotations."""
    statuses = sorted(allowed_statuses(sample['dataset']))
    limit = box_limit(sample['dataset'])
    box_instruction = ('Return at most one tight bounding rectangle enclosing the requested target '
        'or target set; do not enumerate other objects.\n' if limit == 1 else
        f'Return one box per requested instance, with at most {limit} boxes total.\n')
    system = SYSTEM.replace('ANSWERED|UNKNOWN|MATCH|NO_MATCH|PRESENT|ABSENT', '|'.join(statuses))
    if sample['dataset'] in {'gseval', 'groundingme'}:
        meaning = ('MATCH means an object satisfies the entire description. NO_MATCH means no object '
                   'satisfies that description, not that its entire category is absent.')
    elif sample['dataset'] == 'hallusegbench':
        meaning = 'PRESENT and ABSENT concern the target specified by the full query.'
    else:
        meaning = 'ANSWERED includes a concrete negative answer or a count of zero.'
    system = system.replace('For a general question use ANSWERED or UNKNOWN. For a referring description use MATCH,\n'
                            'NO_MATCH or UNKNOWN. For an existence query use PRESENT, ABSENT or UNKNOWN.', meaning)
    prompt = (f'Question:\n{sample["question"]}\n\n'
              f'For this task, status must be one of: {", ".join(statuses)}. {meaning}\n'
              'Use UNKNOWN if the supplied observations cannot determine the answer. '
              'A hidden region is not proof that a target is absent.\n'
              f'There are {len(views)} images, numbered from 0. Image 0 is the full-image coordinate frame. '
              'Use additional images to inspect details. Every box MUST use view 0 and coordinates '
              'relative to image 0, including when details are visible only in another image. '
              'Locate each requested target once; do not repeat boxes. Never box a crop as a shortcut.\n'
              + box_instruction +
              'Return exactly one JSON object with answer, status, boxes and facts, then stop. '
              'Keep answer short and facts to at most three short observations. '
              'Each box is {"view":0,"bbox":[x1,y1,x2,y2]}, using fractions in [0,1], '
              'with x1 < x2 and y1 < y2. Use an empty boxes list if no target can be located.')
    schema = prediction_schema(sample['dataset'], len(views), allowed_box_views=[0], max_boxes=limit)
    return dict(prompt=prompt, system=system, output_schema=schema)


def scores(prediction, sample, predicted, refs, native):
    valid = native['format_valid']
    negative = sample['reference']['target_status'] in {'absent', 'no_match', 'no_annotated_target'}
    match = box_matches(predicted, refs)
    presence_task = sample['reference']['answer_type'] == 'grounding_presence'
    return dict(
        localization_correct=bool(valid and match['all_boxes_correct']) if refs else None,
        localization_recall_correct=bool(valid and match['all_instances_hit']) if refs else None,
        no_target_boxes=bool(valid and not predicted) if negative else None,
        false_positive=bool(predicted) if valid and negative else None,
        false_positive_scope='author_query_target_annotation_not_category_absence' if negative else None,
        false_existence_assertion=(prediction['status'] in {'MATCH', 'PRESENT'})
            if valid and negative and presence_task else None,
        status_correct=native['answer_correct'] if presence_task else None,
        status_box_inconsistent=bool(predicted and prediction.get('status') in {'NO_MATCH', 'ABSENT'}) if valid else None)


def attention_occlusion(heatmap, pixels, seed, sample_id):
    """Exact area, random membership only at cutoff ties; zero mass is unmeasured."""
    heatmap = np.asarray(heatmap)
    if not np.isfinite(heatmap).all() or (heatmap < 0).any():
        raise ValueError('Invalid attention map')
    if heatmap.sum() <= 0:
        return None, dict(reason='No positive spatial visual attention mass')
    count = min(max(int(pixels), 0), heatmap.size)
    if count == 0:
        return None, dict(reason='No annotated area to match')
    threshold = float(np.partition(heatmap.ravel(), heatmap.size-count)[heatmap.size-count])
    chosen = (heatmap > threshold).ravel()
    tied = np.flatnonzero(heatmap.ravel() == threshold)
    remaining = count - int(chosen.sum())
    # Numpy avoids converting a large pixel plateau to millions of Python integers.
    rng = np.random.default_rng(rng_for(seed, 'e3_attention_cutoff', sample_id).getrandbits(64))
    chosen[rng.choice(tied, remaining, replace=False)] = True
    return chosen.reshape(heatmap.shape), dict(tie_policy='seeded_uniform_cutoff_pixels_v1',
        cutoff=threshold, cutoff_tied_pixels=len(tied), cutoff_selected_pixels=remaining,
        uniform_map=bool(np.ptp(heatmap) == 0))


def observation_set(data, sample, config):
    image = data.image(sample)
    overview = view(image, edge=config['overview_edge'], label='overview')
    observations = {'visible': ([overview], None)}
    target = data.region_mask(sample) if sample['reference']['regions'] else None
    if target is None or not target.any():
        return image, target, observations
    hidden = data.support_mask(sample) if sample['dataset'] == 'synthetic' else target
    obscured = view(image, edge=config['overview_edge'], occlusion=hidden, label='hidden_evidence')
    crop = view(image, expand_box(box_from_mask(hidden), image.size, config['crop_margin']),
                config['crop_edge'], label='evidence_crop')
    control = matched_control(hidden, rng_for(config['seed'], 'control_mask', sample['sample_id']),
                              max_overlap=0 if sample['dataset'] == 'synthetic' else .05)
    observations.update(hidden_evidence=([obscured], [hidden]),
                        hidden_reveal=([obscured, crop], [hidden, None]),
                        hidden_control=([view(image, edge=config['overview_edge'], occlusion=control,
                            label='hidden_control')], [control]) if control is not None else ([], None))
    return image, hidden, observations


def metadata(views, masks, target):
    result = dict(support_scope='natural_annotation_intervention_not_exact_support')
    if target is not None and target.any():
        result['target_pixels'] = int(target.sum())
        if masks and masks[0] is not None:
            mask = masks[0]
            result.update(occluded_pixels=int(mask.sum()),
                target_overlap_fraction=float((mask & target).sum()/target.sum()),
                occlusion_sha256=hashlib.sha256(mask.tobytes()).hexdigest())
        if len(views) > 1:
            x1, y1, x2, y2 = views[-1]['source_box']
            w, h = views[-1]['source_size']
            result.update(crop_image_area_fraction=(x2-x1)*(y2-y1)/(w*h),
                          crop_input_long_edge=max(views[-1]['input_size']))
    return result


def run(runner, sample):
    from .common import write_json, fingerprint
    hidden_hashes = []
    for world in worlds(runner.data, sample):
        image, target, observations = observation_set(runner.data, world, runner.cfg)
        baseline = None
        for condition, (views, masks) in observations.items():
            info = metadata(views, masks, target)
            if world['dataset'] == 'synthetic':
                info['support_scope'] = 'synthetic_geometric_support_not_readability'
            row = runner.job(3, world, condition, views, runner.cfg['seed'], occlusions=masks,
                skip='No area/shape-matched control mask' if not views else None, metadata=info)
            if condition == 'visible':
                baseline = row
            if condition == 'hidden_evidence' and world['dataset'] == 'synthetic':
                hidden_hashes.append(hashlib.sha256(views[0]['image'].tobytes()).hexdigest())
        if target is None or not target.any():
            continue
        high, diagnostics = None, dict(reason='Visible attention unavailable')
        if baseline['status'] == 'ok':
            high, diagnostics = attention_occlusion(runner.engine.heatmap(baseline, image.size),
                                                    target.sum(), runner.cfg['seed'], world['sample_id'])
        views = [view(image, edge=runner.cfg['overview_edge'], occlusion=high,
                      label='hidden_attention')] if high is not None else []
        runner.job(3, world, 'hidden_attention', views, runner.cfg['seed'], occlusions=[high],
                   skip=diagnostics.get('reason'), metadata=dict(metadata(views, [high], target), **diagnostics))
    if len(hidden_hashes) == 2:
        if hidden_hashes[0] != hidden_hashes[1]:
            raise ValueError('Synthetic hidden worlds differ after rendering/resizing')
        write_json(runner.engine.run_dir/'e3_hidden_checks'/(fingerprint(sample['sample_id'])+'.json'),
                   dict(sample_id=sample['sample_id'], rendered_hidden_pixel_hashes=hidden_hashes, equal=True))
