"""Experiment 1 estimands: measurable attention, valid behavior, matched pairs."""
from collections import Counter, defaultdict
from pathlib import Path
import html
import numpy as np
from PIL import Image
from .common import write_json
from .geometry import resize_long_edge
from .candidates import saliency
from .metrics import box_matches
from .attention_association import association

CONDITIONS = ('overview', 'overview_control', 'overview_evidence', 'evidence_only')
BEHAVIOR = ('detection_correct', 'all_instances_hit', 'all_boxes_correct', 'precision', 'recall',
            'answer_correct', 'joint_answer_detection', 'joint_answer_localization')
CONTRASTS = (('overview_control', 'overview_evidence'), ('overview', 'overview_evidence'),
             ('overview', 'evidence_only'))
PRIMARY_ATTENTION = ('enrichment', 'coverage_10_tie_averaged')


def full_view_geometry_baseline(views, reference_boxes):
    """Fixed full-last-view box; no image pixels or model predictions are read."""
    index = len(views)-1
    box = list(views[index]['source_box'])
    return dict(name='full_last_view_box', uses_visual_inference=False,
        prediction=dict(view=index, bbox=[0., 0., 1., 1.]), source_box=box,
        scores=box_matches([box], reference_boxes),
        role='geometry_diagnostic_not_a_valid_model_response_or_answer')


def attention_value(row, key):
    attn = row.get('attention', {})
    if key == 'coverage_10':
        return attn.get('coverage', {}).get('0.1')
    if key == 'coverage_10_tie_averaged':
        return attn.get('coverage_tie_averaged', {}).get('0.1')
    if key == 'overview_view_enrichment':
        return ((attn.get('per_view') or [{}])[0].get('enrichment')
                if row.get('views') and row['views'][0]['label']=='overview' else None)
    return attn.get(key)


def scene_features(image, mask, edge):
    """A frozen low-level saliency proxy, never a label of semantic importance."""
    overview = resize_long_edge(image, edge)
    sal = saliency(overview)
    region = np.asarray(Image.fromarray(mask.astype('float32')).resize(overview.size, Image.Resampling.BILINEAR))
    area = float(region.mean())
    ratio = float((sal * region).sum() / sal.sum() / area) if sal.sum() > 0 and area > 0 else None
    return dict(saliency_proxy='spectral_residual_64_on_overview', saliency_enrichment=ratio,
                saliency_stratum='unmeasured' if ratio is None else 'below_uniform' if ratio < 1 else 'at_or_above_uniform')


def valid(row):
    return row.get('status') == 'ok' and bool(row.get('scores', {}).get('format_valid'))


def behavior(row, key):
    if not valid(row):
        return None
    if key == 'answer_correct' and row['dataset'] in {'gseval', 'groundingme'}:
        return None
    return row['scores'].get(key)


def strata(row):
    area = row.get('min_instance_area_fraction')
    size = 'unmeasured' if area is None else 'small' if area < .01 else 'medium' if area < .1 else 'large'
    count = len(row.get('reference', {}).get('regions', []))
    return ['all', 'area:' + size, 'instances:' + ('multiple' if count > 1 else 'single'),
            'task:' + row['task_type'], 'saliency:' + row.get('measurement_features', {}).get('saliency_stratum', 'unmeasured')]


def invalid_reason(row):
    if row['status'] != 'ok':
        return row['status']
    if valid(row):
        return 'valid'
    error = row.get('prediction', {}).get('parse_error')
    if not error:
        return 'task_status_mismatch'
    if 'generation limit' in error:
        return 'length_truncation'
    if 'Multiple final JSON' in error:
        return 'repeated_final_objects'
    if 'Forbidden box view' in error:
        return 'wrong_localization_view'
    if 'box or view' in error:
        return 'invalid_coordinates_or_view'
    return 'unparseable_or_incomplete_output'


def summarize_experiment1(root, rows, config):
    from .analysis import interval, dump_csv
    root = Path(root)
    rows = [r for r in rows if r['experiment'] == 1 and r.get('extra', {}).get('axis') != 'visual_control']
    if not rows:
        return
    repeats = config['bootstrap_repeats']
    groups, sources = defaultdict(list), defaultdict(dict)
    for r in rows:
        groups[r['dataset'], r['condition']].append(r)
        sources[r['dataset'], r['sample_id'], r['seed']][r['condition']] = r
    quality, metrics, alignment, peak_associations, pair_rows, failure_types = [], [], [], [], [], []
    continuous, geometry = [], []
    for (dataset, condition), group in sorted(groups.items()):
        counts = Counter(invalid_reason(r) for r in group)
        generated = sum(r['status'] == 'ok' for r in group)
        quality.append(dict(dataset=dataset, condition=condition, planned=len(group), generated=generated,
            valid=counts['valid'], invalid_generated=generated-counts['valid'],
            valid_rate=counts['valid']/generated if generated else None, reasons=dict(counts)))
        subgroups = defaultdict(list)
        for r in group:
            for label in strata(r):
                subgroups[label].append(r)
            if r['status'] == 'ok' and condition in CONDITIONS:
                score = r['scores']
                failure_types.append(dict(dataset=dataset, condition=condition, sample_id=r['sample_id'],
                    source_group_id=r['source_group_id'], output_valid=valid(r), invalid_reason=invalid_reason(r),
                    attention_peak_hit=r['attention'].get('peak_hit'),
                    detection_correct=behavior(r, 'detection_correct'),
                    all_targets_found_but_strict_failed=bool(valid(r) and score.get('all_instances_hit') and not score.get('detection_correct')),
                    extra_box_count=max(0, len(r.get('predicted_boxes', []))-len(r['reference']['regions'])),
                    answer_correct=behavior(r, 'answer_correct')))
        for label, subset in sorted(subgroups.items()):
            for key in BEHAVIOR:
                estimate = interval([(r['source_group_id'], behavior(r, key)) for r in subset], repeats)
                metrics.append(dict(dataset=dataset, condition=condition, stratum=label, metric=key,
                    eligible=len(subset), valid_outputs=sum(valid(r) for r in subset),
                    excluded_invalid=sum(r['status']=='ok' and not valid(r) for r in subset), **estimate))
            for key in [*PRIMARY_ATTENTION, 'peak_hit', 'coverage_10', 'peak_plateau_hit_fraction', 'overview_view_enrichment']:
                measured = []
                for r in subset:
                    if r['status'] != 'ok':
                        continue
                    value = attention_value(r, key)
                    measured.append((r['source_group_id'], value))
                alignment.append(dict(dataset=dataset, condition=condition, stratum=label, metric=key,
                    role='primary' if key in PRIMARY_ATTENTION else 'auxiliary',
                    cohort='all_measured_attention_independent_of_output_validity', **interval(measured, repeats)))
            if condition == 'overview':
                for hit in [False, True]:
                    subset_hit = [r for r in subset if valid(r) and r['attention'].get('peak_hit') is hit]
                    for key in ['detection_correct', 'all_instances_hit']:
                        peak_associations.append(dict(dataset=dataset, stratum=label, attention_peak_hit=hit, role='auxiliary',
                            metric=key, **interval([(r['source_group_id'], behavior(r, key)) for r in subset_hit], repeats)))
        if condition == 'overview':
            eligible = [r for r in group if valid(r)]
            observations = [dict(source_group_id=r['source_group_id'], task_type=r['task_type'],
                evidence_area_fraction=r.get('evidence_area_fraction'),
                min_instance_area_fraction=r.get('min_instance_area_fraction'),
                instances=len(r['reference']['regions']),
                **{key: attention_value(r,key) for key in PRIMARY_ATTENTION},
                **{key: behavior(r,key) for key in ['all_instances_hit','detection_correct']}) for r in eligible]
            for feature in PRIMARY_ATTENTION:
                for outcome in ['all_instances_hit','detection_correct']:
                    for adjusted in [False,True]:
                        continuous.append(dict(dataset=dataset, condition='overview', feature=feature,
                            outcome=outcome, adjusted=adjusted, valid_outputs=len(eligible),
                            excluded_invalid=sum(r['status']=='ok' and not valid(r) for r in group),
                            **association(observations,feature,outcome,adjusted,repeats,config['seed'])))
        measured_geometry = [r for r in group if r['status']=='ok' and r.get('geometry_baseline')]
        for cohort in ['all_measured','valid_outputs_matched']:
            selected = measured_geometry if cohort=='all_measured' else [r for r in measured_geometry if valid(r)]
            for key in ['all_instances_hit','all_boxes_correct','precision','recall']:
                fixed = interval([(r['source_group_id'],r['geometry_baseline']['scores'].get(key)) for r in selected],repeats)
                model = interval([(r['source_group_id'],behavior(r,key)) for r in selected],repeats) if cohort=='valid_outputs_matched' else None
                geometry.append(dict(dataset=dataset,condition=condition,cohort=cohort,metric=key,
                    role='nonvisual_geometry_diagnostic',model_mean=model['mean'] if model else None,
                    model_n=model['n'] if model else 0,**fixed))
    for dataset in sorted({r['dataset'] for r in rows}):
        for before, after in CONTRASTS:
            candidates = [c for (ds, _, _), c in sources.items() if ds == dataset and before in c and after in c]
            eligible = [c for c in candidates if c[before]['status'] != 'skipped' and c[after]['status'] != 'skipped']
            paired = [c for c in eligible if valid(c[before]) and valid(c[after])]
            for key in BEHAVIOR:
                changes, repaired, degraded = [], 0, 0
                for c in paired:
                    a, b = behavior(c[before], key), behavior(c[after], key)
                    if a is None or b is None:
                        continue
                    changes.append((c[before]['source_group_id'], float(b)-float(a)))
                    if isinstance(a, bool) and isinstance(b, bool):
                        repaired += int(not a and b)
                        degraded += int(a and not b)
                pair_rows.append(dict(dataset=dataset, baseline=before, condition=after, metric=key,
                    eligible_pairs=len(eligible), both_valid_pairs=len(paired), excluded_pairs=len(eligible)-len(paired),
                    missing_or_inapplicable_pairs=len(candidates)-len(eligible), unscored_valid_pairs=len(paired)-len(changes),
                    repaired=repaired, degraded=degraded, **interval(changes, repeats)))
    output = root/'summary'
    tables = dict(e1_output_quality=quality, e1_valid_metrics=metrics, e1_attention_alignment=alignment,
        e1_attention_detection=continuous, e1_attention_peak_diagnostic=peak_associations,
        e1_geometry_baseline=geometry, e1_paired_valid_changes=pair_rows, e1_failure_types=failure_types)
    for name, table in tables.items():
        write_json(output/(name+'.json'), table)
        dump_csv(output/(name+'.csv'), table)
    policy = dict(main_behavior='valid outputs only; UNKNOWN is valid, not automatically correct',
        main_pairs='both conditions valid, on identical sample/seed pairs; exclusions reported',
        attention='all successfully measured prefill attention, independent of final output validity',
        primary_attention=list(PRIMARY_ATTENTION),
        attention_association='Overview only; unadjusted and partial rank correlations, controlling union area, minimum instance area, annotation instance count, and task type; source-group bootstrap. No causal interpretation.',
        uncertainty='Report signed effect, interval and sample count together. Crossing zero is uncertainty, not evidence of no relationship. Direction consistency is descriptive, not independent replication.',
        coverage='Primary top-10% coverage gives fractional membership to exact cutoff ties; legacy row-major coverage and single-pixel peak are auxiliary.',
        localization=config.get('experiment1_measurement',{}).get('localization_policy','legacy_supplied_views'),
        crop_only='Diagnostic condition with crop-relative boxes; do not pool with overview-coordinate localization.',
        geometry_baseline='Fixed full-last-view box, without looking at image content; scored separately. Its model_n is zero in the all_measured cohort. Oracle crop locations are supplied information.',
        legacy_metrics='metrics.json and paired_changes.json remain all-attempt sensitivity diagnostics',
        interpretation='Peak/coverage changes across crop geometries are not evidence of attention causality. Use area-corrected enrichment and separate overview-view results.',
        saliency='Fixed spectral-residual proxy; not human salience or decisive-evidence ground truth',
        answer_scoring='Pending VistaQA semantic judgments stay missing, never zero accuracy',
        confidence_intervals='95% source-group bootstrap, descriptive pilot analysis',
        selected_samples=len(sources), inference_errors=sum(r['status']=='error' for r in rows),
        not_run=sum(r['status']=='not_run' for r in rows),
        semantic_judgments_pending=sum(valid(r) and r['dataset']=='vistaqa' and behavior(r,'answer_correct') is None for r in rows))
    write_json(output/'e1_analysis_policy.json', policy)
    render_report(output, quality, metrics, pair_rows, policy, continuous, geometry)


def render_report(output, quality, metrics, pairs, policy, continuous, geometry):
    """Static scientific artifact with visible denominators and pending outcomes."""
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    datasets = sorted({r['dataset'] for r in quality})
    fig, axes = plt.subplots(1, 2, figsize=(12, 4.8), constrained_layout=True)
    x = np.arange(len(datasets))
    for i, condition in enumerate(CONDITIONS):
        selected = [next((r for r in metrics if r['dataset']==d and r['condition']==condition
            and r['stratum']=='all' and r['metric']=='detection_correct'), None) for d in datasets]
        means = [100*r['mean'] if r and r['mean'] is not None else np.nan for r in selected]
        axes[0].bar(x+(i-1.5)*.19, means, width=.19, label=condition)
    axes[0].set(xticks=x, xticklabels=datasets, ylabel='Detection correct (%)', title='Valid-output localization')
    axes[0].legend(fontsize=7)
    selected = [next(r for r in pairs if r['dataset']==d and r['baseline']=='overview_control'
        and r['condition']=='overview_evidence' and r['metric']=='detection_correct') for d in datasets]
    for i, r in enumerate(selected):
        if r['mean'] is not None:
            axes[1].errorbar(100*r['mean'], i, xerr=[[100*max(0,r['mean']-r['low'])], [100*max(0,r['high']-r['mean'])]], fmt='o')
            axes[1].annotate(f"n={r['n']}; excluded={r['excluded_pairs']}", (100*r['mean'], i), xytext=(4,7), textcoords='offset points', fontsize=7)
    axes[1].axvline(0, color='gray', linestyle='--')
    axes[1].set(yticks=x, yticklabels=datasets, xlabel='Change (percentage points)', title='Evidence crop − matched control (95% CI)')
    fig.savefig(output/'e1_detection.png', dpi=180)
    plt.close(fig)
    fig, axes = plt.subplots(1, 2, figsize=(12, 4.8), constrained_layout=True)
    for ax, feature in zip(axes, PRIMARY_ATTENTION):
        for i, dataset in enumerate(datasets):
            for adjusted, offset, color in [(False,-.12,'#969fa8'),(True,.12,'#2865a8')]:
                r = next((r for r in continuous if r['dataset']==dataset and r['feature']==feature
                    and r['outcome']=='all_instances_hit' and r['adjusted']==adjusted), None)
                if r is None:
                    continue
                if r['effect'] is not None:
                    if r['low'] is not None:
                        ax.plot([r['low'],r['high']],[i+offset]*2,color=color)
                    ax.scatter(r['effect'],i+offset,color=color,
                        label=('Adjusted' if adjusted else 'Unadjusted') if i==0 else None)
                if adjusted:
                    ax.text(.98,i+.23,f"n={r['n']}",ha='right',fontsize=8)
        ax.axvline(0,color='black',linestyle='--',linewidth=.6)
        ax.set(xlim=(-1.02,1.02),ylim=(-.5,max(len(datasets)-.4,.6)),yticks=x,yticklabels=datasets,
               xlabel='Rank correlation with all-target hit (95% CI)',title=feature)
        if ax.get_legend_handles_labels()[0]:
            ax.legend(fontsize=8)
    fig.savefig(output/'e1_attention_association.png',dpi=180)
    plt.close(fig)
    def cell(v):
        return html.escape('pending / unmeasured' if v is None else str(v))
    rows = ''.join('<tr>'+''.join('<td>'+cell(r[k])+'</td>' for k in ['dataset','condition','generated','valid','invalid_generated'])+'</tr>' for r in quality)
    policy_text = ''.join('<li>'+html.escape(k)+': '+cell(v)+'</li>' for k,v in policy.items())
    document = '<!doctype html><meta charset="utf-8"><title>Experiment 1 results</title><style>body{font:16px system-ui;max-width:1150px;margin:32px auto}td,th{padding:8px;border-bottom:1px solid #ddd}img{width:100%}li{margin:8px}</style>'
    document += '<h1>Experiment 1 — attention and evidence detection</h1><p>Signed effects, uncertainty and sample counts are reported together. An interval crossing zero does not establish absence of a relationship. Associations are descriptive, not causal effects.</p><img src="e1_attention_association.png" alt="Primary continuous attention associations"><ul>'+policy_text+'</ul><h2>Localization and crop diagnostics</h2><img src="e1_detection.png" alt="Detection rates and paired effects"><h2>Output availability</h2><table><tr><th>Dataset</th><th>Condition</th><th>Generated</th><th>Valid</th><th>Invalid</th></tr>'+rows+'</table>'
    baseline_rows = [r for r in geometry if r['metric']=='all_instances_hit' and r['cohort']=='valid_outputs_matched']
    document += '<h2>Nonvisual full-view geometry baseline</h2><p>This predicts the full last supplied view. Crop geometry already contains location information; this baseline is not a model response or answer score. Values below use identical valid-output samples.</p><table><tr><th>Dataset</th><th>Condition</th><th>n</th><th>Fixed box hit rate</th><th>Model hit rate</th></tr>'
    document += ''.join('<tr>'+''.join('<td>'+cell(r[k])+'</td>' for k in ['dataset','condition','n','mean','model_mean'])+'</tr>' for r in baseline_rows)+'</table>'
    document += '<p>Complete values and exclusions: <a href="e1_valid_metrics.csv">valid metrics</a>, <a href="e1_paired_valid_changes.csv">paired changes</a>, <a href="e1_attention_alignment.csv">attention alignment</a>, <a href="e1_attention_detection.csv">primary attention–detection associations</a>, <a href="e1_attention_peak_diagnostic.csv">auxiliary peak diagnostic</a>, <a href="e1_geometry_baseline.csv">geometry baseline</a>, <a href="e1_failure_types.csv">failure categories</a>.</p>'
    (output/'e1_report.html').write_text(document)
