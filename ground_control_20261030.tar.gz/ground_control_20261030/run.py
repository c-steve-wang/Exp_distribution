"""Same fixed 20% cohort, new common prompt, independent component scoring."""
import argparse
import os
from pathlib import Path
import shutil
import socket
import sys
from types import SimpleNamespace

STAGE=Path(__file__).resolve().parent
SOURCE=STAGE/'source'
sys.path.insert(0,str(SOURCE))
from backend_core.common import read_json,write_json,file_hash
from controlled import runner as r
from controlled.metrics import make_summary
MODELS=['qwen35_9b','internvl35_8b','gemma4_e4b']


def selected_rows():
    plan=read_json(STAGE/'selection.json')
    rows=[row for row in r.rows_at(SOURCE/'data') if row['sample_id'] in set(plan['sample_ids'])]
    assert len(rows)==160 and len({row['source_group_id'] for row in rows})==40
    return rows


def one_run(root,model):
    paths=list((root/'runs'/model).glob('*/run.json'))
    assert len(paths)==1,(model,paths)
    return paths[0].parent


def summarize(run,rows,cfg):
    records=[read_json(path) for path in sorted((run/'records').glob('*.json'))]
    report,observations,pairs=make_summary(rows,records,cfg['attention_enrichment_threshold'])
    report['scope']='pilot20_fixed_40_groups_v2_scoring'
    report['completeness']['pilot_complete']=report['completeness']['full_dataset_complete']
    report['completeness']['full_dataset_complete']=False
    report['scoring_version']='independent_answer_localization_format_v2'
    report['selection_sha256']=read_json(STAGE/'selection.json')['selection_sha256']
    write_json(run/'summary.json',report)
    for name,items in [('observations',observations),('pairs',pairs),('difficulty',report['difficulty_cells']),
                       ('joint_attention_localization_answer_format',report['joint'])]:
        r.write_csv(run/'tables'/(name+'.csv'),items)
    return report


def options(model,root):
    return SimpleNamespace(model=model,data_root=SOURCE/'data',output_root=root,
        lock_file=SOURCE/'configs/models.lock.json',allow_format_failures=True,
        limit_groups=None,shard_index=0,shards=1,retry_errors=False)


def collect(rows,cfg):
    reports={}
    comparisons=[]
    for model in MODELS:
        run=one_run(STAGE/'outputs',model)
        before=one_run(STAGE/'baseline_rescored',model)
        report=summarize(run,rows,cfg)
        baseline=read_json(before/'summary.json')
        records=[read_json(path) for path in (run/'records').glob('*.json')]
        assert len(records)==160 and {rec['sample_id'] for rec in records}=={row['sample_id'] for row in rows}
        assert all(rec['status']=='ok' and (run/rec['attention_file']).is_file() for rec in records)
        assert read_json(run/'server_validation.json')['measurement_status']=='passed'
        assert read_json(run/'run.json')['system']==r.SYSTEM
        old_records={rec['sample_id']:rec for rec in [read_json(path) for path in (before/'records').glob('*.json')]}
        changes=[]
        for rec in records:
            prior=old_records[rec['sample_id']]
            item=dict(sample_id=rec['sample_id'],condition=rec['condition'],task=rec['task'],
                      old_answer=prior['scores']['normalized_answer'],new_answer=rec['scores']['normalized_answer'])
            for key in ['answer_correct','localization_correct','format_valid','answer_status_valid']:
                item['old_'+key]=prior['scores'][key]
                item['new_'+key]=rec['scores'][key]
            changes.append(item)
        r.write_csv(run/'tables/prompt_before_after.csv',changes)
        reports[model]=dict(complete=True,before=baseline,after=report,run_dir=str(run),
                            token_limit_hits=sum(rec['inference'].get('finish_reason')=='length' for rec in records))
        for condition in ['I_plus','I_minus','I_zero','I_hidden']:
            comparisons.append(dict(model=model,condition=condition,n=40,
                old_answer_accuracy=baseline['conditions'][condition]['answer_accuracy'],
                new_answer_accuracy=report['conditions'][condition]['answer_accuracy'],
                old_localization_accuracy=baseline['conditions'][condition]['localization_accuracy'],
                new_localization_accuracy=report['conditions'][condition]['localization_accuracy'],
                old_format_valid_rate=baseline['conditions'][condition]['format_valid_rate'],
                new_format_valid_rate=report['conditions'][condition]['format_valid_rate']))
    write_json(STAGE/'results.json',dict(all_three_complete=True,groups_per_model=40,images_per_model=160,
               inference_change='Uniform explicit gray occluder explanation; same selected images and generation settings.',
               scoring='Independent answer/localization/format applied identically to both prompt versions.',models=reports))
    r.write_csv(STAGE/'comparison.csv',comparisons)
    print('COMPLETE: 20% on all three models, independent scores, matched prompt comparison.',flush=True)
    for model,value in reports.items():
        print(model,'hidden UNKNOWN:',value['before']['paired']['hidden_unknown'],'->',value['after']['paired']['hidden_unknown'],
              'content pair accuracy:',value['before']['paired']['cpc'],'->',value['after']['paired']['cpc'],flush=True)


def main():
    assert os.environ.get('SLURM_JOB_ID') and socket.gethostname().split('.')[0]==os.environ.get('SLURMD_NODENAME','').split('.')[0]
    parser=argparse.ArgumentParser()
    parser.add_argument('command',choices=['smoke','run','collect'])
    parser.add_argument('model',nargs='?',choices=MODELS)
    cli=parser.parse_args()
    plan=read_json(STAGE/'selection.json')
    assert file_hash(STAGE/'run.py')==plan['driver_sha256']
    for name,sha in plan['source_files'].items():
        assert file_hash(SOURCE/name)==sha,name
    assert r.dataset_hash(SOURCE/'data')==plan['dataset_sha256']
    cfg=read_json(SOURCE/'configs/protocol.json')
    rows=selected_rows()
    if cli.command=='collect':
        collect(rows,cfg)
        return
    assert cli.model
    if cli.command=='smoke':
        r.smoke(options(cli.model,STAGE/'validation'),cfg,r.rows_at(SOURCE/'data'))
        return
    verified=one_run(STAGE/'validation',cli.model)
    assert read_json(verified/'server_validation.json')['measurement_status']=='passed'
    destination=STAGE/'outputs/runs'/cli.model/verified.name
    destination.mkdir(parents=True,exist_ok=True)
    shutil.copy2(verified/'server_validation.json',destination/'server_validation.json')
    r.summarize=summarize
    r.run_model(options(cli.model,STAGE/'outputs'),cfg,rows)
    assert one_run(STAGE/'outputs',cli.model)==destination


if __name__=='__main__':
    main()
