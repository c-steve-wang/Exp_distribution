ground_control_20261030 — 更新版代码（v2）

已更新：
1. 答案正确、定位正确、格式合法分别统计，再用于联合分析。
   框格式错误不再使正确答案计错；答案/状态不一致单独记录。
   坐标不修补，重复框不删除；无效JSON、重复键、截断输出不补救。
2. 对所有样本使用同一个新提示：灰色面板是遮住原有内容的遮挡物，
   不能把遮挡物的灰色当作原物体颜色，也不能把看不见当作数量为0。
   关键信息被遮住、不能确定时应回答UNKNOWN。

包含代码、完整输入数据（200组800张图及标注）、固定20%样本表、测试和环境版本。
不包含实验结果或模型权重。已有结果压缩包是旧提示结果，不代表新提示已跑完。
本次重跑仍为原来40组160张图/模型，三个模型；selection.json 样本选择不变。
生成上限1024 tokens，输入边长384，最多8框和重复框检查保持不变。
29项测试已在计算节点通过；旧480条预测已用新评分重算，无需重新推理。

合作者使用：
在解包后的 ground_control_20261030 目录中，设置自己的Python和模型缓存：
  export CD_PYTHON=/绝对路径/venv/bin/python
  export HF_HOME=/绝对路径/huggingface缓存
模型仓库与锁定版本见 source/configs/models.lock.json。
环境版本见 environment.freeze.txt 和 environment.versions.json。
默认运行固定20%；按自己集群修改分区、账户、GPU参数：
  sbatch --partition=GPU分区 --account=账户 --gres=gpu:1 --cpus-per-task=4 --mem=64G --time=01:00:00 collaborator.slurm qwen35_9b
  sbatch --partition=GPU分区 --account=账户 --gres=gpu:1 --cpus-per-task=4 --mem=64G --time=01:00:00 collaborator.slurm internvl35_8b
  sbatch --partition=GPU分区 --account=账户 --gres=gpu:1 --cpus-per-task=4 --mem=64G --time=01:00:00 collaborator.slurm gemma4_e4b
脚本先在当前设备做测量验证，再运行；验证输出与正式160条样本结果分开存储。
输出在 outputs/runs；每个模型结束时自动生成 summary.json 和 tables/。
格式失败如实记录，测量验证必须通过；允许诊断运行不代表严格格式验证成功。
仅在合作者决定做全量时才在模型名后加200。本机不会自动跑全量。

所有计算必须通过sbatch在计算节点执行；登录节点只提交和查询。
run.py collect 用于新旧提示对照，需要本次新输出和另行提供的 baseline_rescored 结果。
代码包不附带该结果目录；只运行单个提示时查看各模型自动生成的summary即可。
原始旧版本结果不能当成新提示的续跑缓存。
