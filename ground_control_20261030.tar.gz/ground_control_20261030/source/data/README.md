# 受控视觉诊断测试集 v1

200 个独立场景组，800 张 1024×1024 RGB PNG；全部为 test，没有训练或开发划分。
颜色识别 68 组 / 272 张；计数 66 组 / 264 张；左右关系 66 组 / 264 张。
每组固定同一问题，四种条件：I_plus 基础图，I_minus 目标事实变化，I_zero 无关背景变化，I_hidden 完全隐藏框内内容。

## 使用

按 catalog.jsonl 逐行读取，用本目录拼接 image.path。模型输入只有图像和 question。
不要把文件名、condition、参数、reference、world_reference 或预览图里的答案传给模型。
所有模型使用同一批图像、同一问题和同一套评分规则。样本排列可在推理时固定种子打乱。
families.jsonl 每行是一组，包含组参数和四条件答案；provenance 与 annotations 是评估元数据。

目标边长/直径 24、48、96 px；框外干扰物 4、24 个。18 个任务×大小×干扰组合各 11 或 12 组。
黑框外尺寸始终 400×320，边框 4 px；位置分四象限均衡抽样，形状大小独立于框大小。
颜色 red↔blue，计数 2↔3，空间 yes↔no，基础答案在每个任务内严格平衡。
计数只增减一个圆，其余圆位置不变；左右关系交换圆与方块的位置。
I_zero 使用 warm/cool/checker 三种背景，目标、整个框及干扰物保持不变，每组一种背景控制。
I_hidden 保留黑色边框，框内固定填充 RGB(128,128,128)。同组正反两图隐藏后像素完全相同。

## 标注语义

- reference.answer：当前实际图片的正确回答；hidden 为 UNKNOWN，不是 0/no/目标不存在。
- reference.regions：当前可见目标的逐对象 mask、半开 xyxy bbox、面积、形状及颜色。
- reference.localization_scorable：hidden 为 false，其参考可见目标区域为空。
- world_reference：隐藏前世界的事实，仅供评估；hidden 记录以 I_plus 为底图的潜在世界。
- annotations.target_mask：实际可见目标的联合区域；hidden 是空 mask。
- annotations.reference_mask：只有黑色边框，不包括白色内区，也不是完整框的实心矩形。
- annotations.interior_mask / support_mask：整个框内区，作为确定的遮挡/证据区域；不等于目标 mask。
- annotations.occlusion_mask：实际遮挡区，仅 hidden 非空。
- annotations.latent_target_mask：隐藏前的目标位置，不能拿来要求模型定位不可见对象。
- annotations.factual_edit_mask：同组 plus/minus 真正改变的像素。
- bbox 坐标约定 [x1,y1,x2,y2)，PNG mask 为 0/255、与原图同尺寸。

## 结果计算

以 source_group_id / pair_id 连接四张图；独立场景单位是 200 组，不能把四张衍生图当四个独立场景。
CPC 要求 plus 与 minus 两端答案都正确。I0 同时报告答案一致率与两端正确率，避免把一起答错算成功。
hidden 统计 UNKNOWN 比例。定位和颜色/数量/关系判断分开报告。
大小变化会改变目标面积，跨大小比较注意力需同时报告目标原始质量和基于实际 token footprint 的面积校正值。
本数据只有图像、标签及配对验证，没有任何 VLM 结果，也没有验证具体模型 processor 的输入张量。
这些直接属性任务不能单凭答案错误证明“模型已独立识别事实但未使用该事实”。

## 文件与复现

images/ 为 800 张正式输入；masks/ 为自动标签；previews/ 仅供人工查看，不能作为模型输入。
generation.json 记录种子、依赖版本及生成器哈希；validation.json 为已保存文件的校验结果。
生成器只依赖 Pillow 和 NumPy，不调用图像生成模型；保持记录的依赖版本可精确复现。

```bash
python -m pip install -r requirements.txt
python generate_dataset.py --output /path/to/new_dataset --seed 42
python generate_dataset.py --output /path/to/existing_dataset --validate-only
```

新生成必须使用尚不存在的目录，不覆盖已有数据。tests/ 或服务器推理入口不由该生成器修改。
