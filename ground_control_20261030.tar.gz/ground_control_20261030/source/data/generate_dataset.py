"""Generate and audit the fixed 200-family controlled visual test set (CPU only).

Standalone: Python 3.11+, Pillow and NumPy. No model or existing runner required.
"""
import argparse
from collections import Counter, defaultdict
import hashlib
import json
from pathlib import Path
import random
import shutil
import sys

import numpy as np
from PIL import Image, ImageDraw, ImageFont, __version__ as pillow_version

VERSION = "controlled-diagnostic-v1"
TASK_COUNTS = {"attribute": 68, "counting": 66, "spatial": 66}
SIZES = [24, 48, 96]
CLUTTER = [4, 24]
CONDITIONS = ["I_plus", "I_minus", "I_zero", "I_hidden"]
PALETTE = {"red": (215, 35, 35), "blue": (30, 80, 210),
           "cyan": (25, 155, 170), "green": (30, 130, 80),
           "purple": (155, 90, 155), "gray": (130, 130, 130)}
BASE_BG = (235, 235, 225)
HIDDEN_RGB = (128, 128, 128)
QUESTIONS = {
    "attribute": "What color is the square inside the black frame? Answer red or blue. "
                 "If its color cannot be determined from the visible image, answer UNKNOWN.",
    "counting": "How many circles are inside the black frame? Answer with the number. "
                "If the number cannot be determined from the visible image, answer UNKNOWN.",
    "spatial": "Inside the black frame, is the circle to the left of the square? Answer yes or no. "
               "If the relation cannot be determined from the visible image, answer UNKNOWN.",
}


def check(condition, message):
    if not condition:
        raise ValueError(message)


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def rng_for(seed, *parts):
    raw = json.dumps([seed, *parts], separators=(",", ":")).encode()
    return random.Random(int(hashlib.sha256(raw).hexdigest()[:16], 16))


def write_json(path, value):
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n")


def mask_box(mask):
    yy, xx = np.nonzero(mask)
    return [int(xx.min()), int(yy.min()), int(xx.max() + 1), int(yy.max() + 1)] if len(xx) else None


def blank_mask():
    return np.zeros((1024, 1024), dtype=bool)


def rect_mask(box):
    mask = blank_mask()
    x1, y1, x2, y2 = box
    mask[y1:y2, x1:x2] = True
    return mask


def paint(draw, shape, box, color):
    x1, y1, x2, y2 = box
    getattr(draw, shape)((x1, y1, x2 - 1, y2 - 1), fill=color)


def object_spec(ident, shape, cx, cy, size, color):
    x, y = cx - size // 2, cy - size // 2
    return dict(id=ident, shape=shape, bbox_xyxy=[x, y, x + size, y + size], color=color)


def object_mask(spec):
    mask = Image.new("L", (1024, 1024), 0)
    paint(ImageDraw.Draw(mask), spec["shape"], spec["bbox_xyxy"], 255)
    return np.asarray(mask) > 0


def save_mask(root, relative, mask):
    path = root / relative
    path.parent.mkdir(parents=True, exist_ok=True)
    Image.fromarray(mask.astype("uint8") * 255).save(path)
    return str(relative)


def overlaps(a, b, gap=0):
    return a[0] < b[2] + gap and a[2] > b[0] - gap and a[1] < b[3] + gap and a[3] > b[1] - gap


def background(style):
    colors = {"base": BASE_BG, "warm": (242, 220, 224), "cool": (218, 232, 246),
              "checker": (233, 233, 228)}
    image = Image.new("RGB", (1024, 1024), colors[style])
    if style == "checker":
        draw = ImageDraw.Draw(image)
        for y in range(0, 1024, 32):
            for x in range(0, 1024, 32):
                if (x // 32 + y // 32) % 2:
                    draw.rectangle((x, y, x + 31, y + 31), fill=(212, 216, 217))
    return image


def render(frame, distractors, objects, style="base"):
    image = background(style)
    draw = ImageDraw.Draw(image)
    for spec in distractors:
        paint(draw, spec["shape"], spec["bbox_xyxy"], PALETTE[spec["color"]])
    paint(draw, "rectangle", frame, "black")
    interior = [frame[0] + 4, frame[1] + 4, frame[2] - 4, frame[3] - 4]
    paint(draw, "rectangle", interior, "white")
    for spec in objects:
        paint(draw, spec["shape"], spec["bbox_xyxy"], PALETTE[spec["color"]])
    return image


def specifications(seed):
    """All 18 cells have 11 families; attribute adds one small/low and large/high."""
    for task, total in TASK_COUNTS.items():
        cells = []
        for cell, (size, clutter) in enumerate((s, c) for s in SIZES for c in CLUTTER):
            count = 11 + int(task == "attribute" and cell in (0, 5))
            for j in range(count):
                cells.append(dict(target_size_px=size, distractor_count=clutter,
                                  baseline_flip=bool((j + cell) % 2),
                                  background_control=["warm", "cool", "checker"][(j + cell) % 3]))
        rng_for(seed, task, "cell_order").shuffle(cells)
        quadrants = [i % 4 for i in range(total)]
        rng_for(seed, task, "position_order").shuffle(quadrants)
        check(len(cells) == total, "Bad task allocation")
        for index, (cell, quadrant) in enumerate(zip(cells, quadrants)):
            yield task, index, dict(cell, position_quadrant=quadrant)


def scene(seed, task, index, config):
    rng = rng_for(seed, task, index, "scene")
    q = config["position_quadrant"]
    x = rng.randint(40, 311) if q % 2 == 0 else rng.randint(313, 584)
    y = rng.randint(40, 351) if q // 2 == 0 else rng.randint(353, 664)
    frame = [x, y, x + 400, y + 320]
    distractors = []
    for attempt in range(10000):
        if len(distractors) == config["distractor_count"]:
            break
        side = rng.choice([20, 28, 40])
        dx, dy = rng.randint(12, 1012 - side), rng.randint(12, 1012 - side)
        box = [dx, dy, dx + side, dy + side]
        if overlaps(box, frame, 12) or any(overlaps(box, d["bbox_xyxy"], 8) for d in distractors):
            continue
        distractors.append(dict(id=f"d{len(distractors)}", shape=rng.choice(["ellipse", "rectangle"]),
                                bbox_xyxy=box, color=rng.choice(list(PALETTE))))
    check(len(distractors) == config["distractor_count"], "Could not place distractors")
    size, flip = config["target_size_px"], config["baseline_flip"]
    cx, cy = x + 200 + rng.randint(-12, 12), y + 160 + rng.randint(-40, 40)
    if task == "attribute":
        colors = ["blue", "red"] if flip else ["red", "blue"]
        objects = [[object_spec("square", "rectangle", cx, cy, size, color)] for color in colors]
        answers = colors
    elif task == "counting":
        pool = [object_spec(f"circle_{j}", "ellipse", cx + (j - 1) * 112,
                            cy + rng.randint(-18, 18), size, "cyan") for j in range(3)]
        omitted = rng.randrange(3)
        two = [s for j, s in enumerate(pool) if j != omitted]
        objects, answers = ([pool, two], ["3", "2"]) if flip else ([two, pool], ["2", "3"])
    else:
        objects = []
        answers = ["no", "yes"] if flip else ["yes", "no"]
        for answer in answers:
            left, right = cx - 95, cx + 95
            circle_x, square_x = (left, right) if answer == "yes" else (right, left)
            objects.append([object_spec("circle", "ellipse", circle_x, cy, size, "green"),
                            object_spec("square", "rectangle", square_x, cy, size, "purple")])
    return frame, distractors, objects, answers


def generate(root, seed):
    check(not root.exists(), f"Output already exists; choose a new directory: {root}")
    root.mkdir(parents=True)
    empty = save_mask(root, Path("masks/empty.png"), blank_mask())
    records, families = [], []
    for task, index, config in specifications(seed):
        family = f"controlled_v1/{task}/{index:04d}"
        prefix = Path(task) / f"{index:04d}"
        frame, distractors, object_sets, answers = scene(seed, task, index, config)
        interior = [frame[0] + 4, frame[1] + 4, frame[2] - 4, frame[3] - 4]
        interior_mask = rect_mask(interior)
        frame_mask = rect_mask(frame) & ~interior_mask
        frame_path = save_mask(root, Path("masks/reference") / prefix.with_suffix(".png"), frame_mask)
        interior_path = save_mask(root, Path("masks/interior") / prefix.with_suffix(".png"), interior_mask)
        images = {"I_plus": render(frame, distractors, object_sets[0]),
                  "I_minus": render(frame, distractors, object_sets[1]),
                  "I_zero": render(frame, distractors, object_sets[0], config["background_control"])}
        hidden = images["I_plus"].copy()
        hidden.paste(HIDDEN_RGB, tuple(interior))
        images["I_hidden"] = hidden
        changed = np.any(np.asarray(images["I_plus"]) != np.asarray(images["I_minus"]), axis=2)
        edit_path = save_mask(root, Path("masks/factual_edit") / prefix.with_suffix(".png"), changed)
        refs, target_paths = [], []
        for condition, specs, answer in zip(CONDITIONS[:2], object_sets, answers):
            regions, target = [], blank_mask()
            for spec in specs:
                mask = object_mask(spec)
                target |= mask
                path = save_mask(root, Path("masks/objects") / prefix / f"{condition}_{spec['id']}.png", mask)
                regions.append(dict(spec, area=int(mask.sum()),
                                    mask=dict(encoding="binary_png", path=path, size=[1024, 1024])))
            target_paths.append(save_mask(root, Path("masks/target") / prefix / f"{condition}.png", target))
            facts = ({"color": answer, "count": 1} if task == "attribute" else
                     {"count": int(answer)} if task == "counting" else
                     {"circle_left_of_square": answer == "yes", "count": 2})
            refs.append(dict(answer=answer, answer_type="text", region_kind="mask", target_status="present",
                             localization_scorable=True, facts=facts, regions=regions))
        family_record = dict(source_group_id=family, task_type=task, parameters=config,
                             frame_bbox_xyxy=frame, interior_bbox_xyxy=interior,
                             distractors=distractors, answers=dict(zip(CONDITIONS, [*answers, answers[0], "UNKNOWN"])))
        families.append(family_record)
        for condition in CONDITIONS:
            hidden_condition = condition == "I_hidden"
            reference = refs[1] if condition == "I_minus" else refs[0]
            if hidden_condition:
                reference = dict(answer="UNKNOWN", answer_type="text", region_kind="none",
                                 target_status="unobservable", localization_scorable=False,
                                 facts={}, regions=[], possible_world_answers=sorted(answers))
            relative = Path("images") / prefix / f"{condition}.png"
            (root / relative).parent.mkdir(parents=True, exist_ok=True)
            images[condition].save(root / relative)
            sample_id = family + "/" + condition
            records.append(dict(schema_version=1, dataset=VERSION, domain="controlled", task_type=task,
                sample_id=sample_id, unit_id=sample_id, source_group_id=family, pair_id=family,
                condition=condition, is_primary=condition == "I_plus", official_split="generated",
                analysis_split="test", question=QUESTIONS[task],
                image=dict(path=str(relative), width=1024, height=1024, byte_sha256=digest(root / relative)),
                reference=reference, world_reference=refs[1] if condition == "I_minus" else refs[0],
                support_mask=interior_path,
                annotations=dict(target_mask=empty if hidden_condition else target_paths[int(condition == "I_minus")],
                                 reference_mask=frame_path, interior_mask=interior_path,
                                 occlusion_mask=interior_path if hidden_condition else empty,
                                 factual_edit_mask=edit_path,
                                 latent_target_mask=target_paths[int(condition == "I_minus")]),
                provenance=dict(generator=VERSION, seed=seed, family_index=index, parameters=config,
                                hidden_source="I_plus" if hidden_condition else None,
                                frame_bbox_xyxy=frame, interior_bbox_xyxy=interior)))
    (root / "catalog.jsonl").write_text("".join(json.dumps(r, ensure_ascii=False) + "\n" for r in records))
    (root / "families.jsonl").write_text("".join(json.dumps(r, ensure_ascii=False) + "\n" for r in families))
    write_json(root / "generation.json", dict(generator=VERSION, seed=seed, families=200, images=800,
        task_family_counts=TASK_COUNTS, target_sizes_px=SIZES, distractor_counts=CLUTTER,
        image_size=[1024, 1024], frame_size=[400, 320], frame_stroke_px=4,
        condition_order=CONDITIONS, split="test", background_controls=["warm", "cool", "checker"],
        source_sha256=digest(__file__), pillow_version=pillow_version, numpy_version=np.__version__,
        catalog_sha256=digest(root / "catalog.jsonl")))
    return records, families


def load_mask(root, path):
    with Image.open(root / path) as im:
        check(im.size == (1024, 1024), "Bad mask dimensions")
        a = np.asarray(im)
        check(set(np.unique(a)).issubset({0, 255}), "Mask is not binary")
        return a > 0


def audit(root):
    generation = json.loads((root / "generation.json").read_text())
    check(digest(root / "catalog.jsonl") == generation["catalog_sha256"], "Catalog checksum mismatch")
    check(digest(root / "generate_dataset.py") == generation["source_sha256"], "Generator checksum mismatch")
    records = [json.loads(line) for line in (root / "catalog.jsonl").read_text().splitlines()]
    families = {r["source_group_id"]: r for r in map(json.loads, (root / "families.jsonl").read_text().splitlines())}
    check(len(records) == 800 and len(families) == 200, "Wrong dataset count")
    check(len(list((root / "images").rglob("*.png"))) == 800, "Unexpected image files")
    check(len({r["sample_id"] for r in records}) == 800, "Duplicate sample IDs")
    grouped, checks = defaultdict(dict), Counter()
    for r in records:
        grouped[r["source_group_id"]][r["condition"]] = r
    check(Counter(f["task_type"] for f in families.values()) == Counter(TASK_COUNTS), "Wrong task counts")
    cells, directions, controls = Counter(), Counter(), Counter()
    for group_id, variants in grouped.items():
        check(set(variants) == set(CONDITIONS), "Incomplete quartet")
        check(len({r["question"] for r in variants.values()}) == 1, "Question changes within quartet")
        check(all(r["analysis_split"] == "test" for r in variants.values()), "Unexpected split")
        family = families[group_id]
        task, parameters = family["task_type"], family["parameters"]
        cells[(task, parameters["target_size_px"], parameters["distractor_count"])] += 1
        directions[(task, variants["I_plus"]["reference"]["answer"])] += 1
        controls[(task, parameters["background_control"])] += 1
        frame, interior = family["frame_bbox_xyxy"], family["interior_bbox_xyxy"]
        check(frame[2] - frame[0] == 400 and frame[3] - frame[1] == 320, "Frame size changed")
        check(len(family["distractors"]) == parameters["distractor_count"], "Wrong clutter count")
        check(all(not overlaps(d["bbox_xyxy"], frame, 12) for d in family["distractors"]), "Distractor overlaps frame")
        pixels, target_masks = {}, {}
        for condition, r in variants.items():
            path = root / r["image"]["path"]
            check(digest(path) == r["image"]["byte_sha256"], "Image checksum mismatch")
            with Image.open(path) as image:
                check(image.size == (1024, 1024) and image.mode == "RGB", "Image format mismatch")
                pixels[condition] = np.asarray(image)
            masks = {k: load_mask(root, v) for k, v in r["annotations"].items()}
            check(np.array_equal(masks["interior_mask"], rect_mask(interior)), "Interior mask mismatch")
            check(np.array_equal(masks["reference_mask"], rect_mask(frame) & ~rect_mask(interior)), "Frame mask mismatch")
            check(np.all(pixels[condition][masks["reference_mask"]] == 0), "Frame not black")
            check(not (masks["target_mask"] & masks["reference_mask"]).any(), "Target/frame masks overlap")
            target_masks[condition] = masks["target_mask"]
            reference = r["reference"]
            check(reference["answer"] == family["answers"][condition], "Family/row label mismatch")
            union = blank_mask()
            for region in reference["regions"]:
                mask = load_mask(root, region["mask"]["path"])
                check(mask_box(mask) == region["bbox_xyxy"] and int(mask.sum()) == region["area"], "Region geometry mismatch")
                check(np.array_equal(mask, object_mask(region)), "Region rasterization mismatch")
                check(not (mask & ~masks["interior_mask"]).any() and not (mask & union).any(), "Objects overlap or escape frame")
                check(np.all(pixels[condition][mask] == PALETTE[region["color"]]), "Object color mismatch")
                box = region["bbox_xyxy"]
                check(box[2] - box[0] == box[3] - box[1] == parameters["target_size_px"], "Target size mismatch")
                union |= mask
            check(np.array_equal(union, masks["target_mask"]), "Target union mismatch")
            if condition == "I_hidden":
                check(reference["answer"] == "UNKNOWN" and not reference["localization_scorable"], "Hidden label wrong")
                check(np.all(pixels[condition][masks["occlusion_mask"]] == HIDDEN_RGB), "Incomplete hiding")
            else:
                answer, regions = reference["answer"], reference["regions"]
                if task == "attribute":
                    check(len(regions) == 1 and regions[0]["color"] == answer, "Color answer mismatch")
                elif task == "counting":
                    check(len(regions) == int(answer), "Count answer mismatch")
                else:
                    check(len(regions) == 2, "Spatial scene needs two objects")
                    left = regions[0]["bbox_xyxy"][0] < regions[1]["bbox_xyxy"][0]
                    check(answer == ("yes" if left else "no"), "Spatial answer mismatch")
            checks["image_and_annotation_checks"] += 1
        plus, minus, zero, hidden = [pixels[c] for c in CONDITIONS]
        edited = np.any(plus != minus, axis=2)
        allowed = target_masks["I_plus"] | target_masks["I_minus"]
        check(edited.any() and not (edited & ~allowed).any(), "Fact edit outside target union")
        check(np.array_equal(edited, load_mask(root, variants["I_plus"]["annotations"]["factual_edit_mask"])), "Edit mask mismatch")
        check(np.array_equal(plus[rect_mask(frame)], zero[rect_mask(frame)]) and not np.array_equal(plus, zero), "Invalid I0")
        check(variants["I_plus"]["reference"] == variants["I_zero"]["reference"], "I0 labels changed")
        check(variants["I_plus"]["reference"]["answer"] != variants["I_minus"]["reference"]["answer"], "Fact answer unchanged")
        hidden_pair = []
        for original in (plus, minus):
            masked = original.copy()
            masked[rect_mask(interior)] = HIDDEN_RGB
            check(np.array_equal(masked, hidden), "Hidden worlds differ")
            hidden_pair.append(Image.fromarray(masked))
        for edge in (384, 768):
            check(hidden_pair[0].resize((edge, edge), Image.Resampling.LANCZOS).tobytes() ==
                  hidden_pair[1].resize((edge, edge), Image.Resampling.LANCZOS).tobytes(), "Resized hidden worlds differ")
            checks["hidden_pair_equal_after_resize"] += 1
        checks["verified_quartets"] += 1
        if task == "counting":
            objects = [{r["id"]: r for r in variants[c]["reference"]["regions"]} for c in CONDITIONS[:2]]
            shared = set(objects[0]) & set(objects[1])
            check(len(shared) == 2 and all({k: v for k, v in objects[0][i].items() if k != "mask"} ==
                                          {k: v for k, v in objects[1][i].items() if k != "mask"} for i in shared),
                  "Counting moves existing objects")
            checks["counting_add_remove_only"] += 1
    check(len(cells) == 18 and all(v in (11, 12) for v in cells.values()), "Unbalanced difficulty cells")
    for task in TASK_COUNTS:
        check(len({v for (t, a), v in directions.items() if t == task}) == 1, "Answer direction imbalance")
    report = dict(status="passed", scope="saved_images_labels_and_pairing_cpu_only", families=200, images=800,
                  family_counts=TASK_COUNTS, split="test", checks=dict(checks),
                  difficulty_cells=[dict(task=t, size_px=s, distractors=c, families=n) for (t, s, c), n in sorted(cells.items())],
                  baseline_answers={t: {a: n for (task, a), n in directions.items() if task == t} for t in TASK_COUNTS},
                  background_controls={t: {a: n for (task, a), n in controls.items() if task == t} for t in TASK_COUNTS},
                  model_inference_run=False, processor_tensor_equality_verified=False)
    write_json(root / "validation.json", report)
    return records, report


def previews(root, records):
    out = root / "previews"
    out.mkdir(exist_ok=True)
    font = ImageFont.load_default(size=18)
    title = ImageFont.load_default(size=24)
    primary = [r for r in records if r["condition"] == "I_plus"]
    chosen = [next(r for r in primary if r["task_type"] == task and
                   r["provenance"]["parameters"]["target_size_px"] == 48 and
                   r["provenance"]["parameters"]["distractor_count"] == 24) for task in TASK_COUNTS]
    by_id = {r["sample_id"]: r for r in records}
    canvas = Image.new("RGB", (1328, 1276), "white")
    draw = ImageDraw.Draw(canvas)
    draw.text((16, 12), "Controlled diagnostic: 200 families / 800 images", font=title, fill="black")
    draw.text((16, 45), "Examples only. Labels shown below images are NOT part of model inputs.", font=font, fill="black")
    for row, base in enumerate(chosen):
        y = 86 + row * 392
        draw.text((16, y), f"{base['task_type']} | 48 px target | 24 distractors | {base['source_group_id']}", font=font, fill="black")
        for col, condition in enumerate(CONDITIONS):
            r = by_id[base["source_group_id"] + "/" + condition]
            x = 16 + col * 328
            draw.text((x, y + 26), condition, font=font, fill="black")
            with Image.open(root / r["image"]["path"]) as im:
                canvas.paste(im.resize((312, 312), Image.Resampling.LANCZOS), (x, y + 50))
            draw.text((x, y + 363), "Label: " + r["reference"]["answer"], font=font, fill="black")
    canvas.save(out / "overview.png")
    crops = Image.new("RGB", (1264, 1160), "white")
    draw = ImageDraw.Draw(crops)
    draw.text((16, 12), "Target-size examples: native 400 x 320 frame crops (preview only)", font=title, fill="black")
    for row, task in enumerate(TASK_COUNTS):
        for col, size in enumerate(SIZES):
            r = next(r for r in primary if r["task_type"] == task and
                     r["provenance"]["parameters"]["target_size_px"] == size and
                     r["provenance"]["parameters"]["distractor_count"] == 24)
            x, y = 16 + col * 416, 62 + row * 364
            draw.text((x, y), f"{task} | {size} px | {r['reference']['answer']}", font=font, fill="black")
            with Image.open(root / r["image"]["path"]) as im:
                crops.paste(im.crop(tuple(r["provenance"]["frame_bbox_xyxy"])), (x, y + 28))
    crops.save(out / "target_sizes.png")


README = """# 受控视觉诊断测试集 v1

200 个独立场景组，800 张 1024×1024 RGB PNG；全部为 test，没有训练或开发划分。
颜色识别 68 组 / 272 张；计数 66 组 / 264 张；左右关系 66 组 / 264 张。
每组固定同一问题，四种条件：I_plus 基础图，I_minus 目标事实变化，I_zero 无关背景变化，I_hidden 完全隐藏框内内容。

## 使用

按 catalog.jsonl 逐行读取，用本目录拼接 image.path。模型输入只有图像和 question。
不要把文件名、condition、参数、reference、world_reference 或预览图里的答案传给模型。
所有模型使用同一批图像、同一问题和同一套评分规则。样本排列可在推理时固定种子打乱。
families.jsonl 每行是一组，包含组参数和四条件答案；provenance 与 annotations 是评估元数据。

目标边长/直径 24、48、96 px；框外干扰物 4、24 个。18 个任务×大小×干扰组合各 11 或 12 组。
黑框外尺寸始终 400×320，边框 4 px；位置分四象限均衡抽样，形状大小独立于框大小。
颜色 red↔blue，计数 2↔3，空间 yes↔no，基础答案在每个任务内严格平衡。
计数只增减一个圆，其余圆位置不变；左右关系交换圆与方块的位置。
I_zero 使用 warm/cool/checker 三种背景，目标、整个框及干扰物保持不变，每组一种背景控制。
I_hidden 保留黑色边框，框内固定填充 RGB(128,128,128)。同组正反两图隐藏后像素完全相同。

## 标注语义

- reference.answer：当前实际图片的正确回答；hidden 为 UNKNOWN，不是 0/no/目标不存在。
- reference.regions：当前可见目标的逐对象 mask、半开 xyxy bbox、面积、形状及颜色。
- reference.localization_scorable：hidden 为 false，其参考可见目标区域为空。
- world_reference：隐藏前世界的事实，仅供评估；hidden 记录以 I_plus 为底图的潜在世界。
- annotations.target_mask：实际可见目标的联合区域；hidden 是空 mask。
- annotations.reference_mask：只有黑色边框，不包括白色内区，也不是完整框的实心矩形。
- annotations.interior_mask / support_mask：整个框内区，作为确定的遮挡/证据区域；不等于目标 mask。
- annotations.occlusion_mask：实际遮挡区，仅 hidden 非空。
- annotations.latent_target_mask：隐藏前的目标位置，不能拿来要求模型定位不可见对象。
- annotations.factual_edit_mask：同组 plus/minus 真正改变的像素。
- bbox 坐标约定 [x1,y1,x2,y2)，PNG mask 为 0/255、与原图同尺寸。

## 结果计算

以 source_group_id / pair_id 连接四张图；独立场景单位是 200 组，不能把四张衍生图当四个独立场景。
CPC 要求 plus 与 minus 两端答案都正确。I0 同时报告答案一致率与两端正确率，避免把一起答错算成功。
hidden 统计 UNKNOWN 比例。定位和颜色/数量/关系判断分开报告。
大小变化会改变目标面积，跨大小比较注意力需同时报告目标原始质量和基于实际 token footprint 的面积校正值。
本数据只有图像、标签及配对验证，没有任何 VLM 结果，也没有验证具体模型 processor 的输入张量。
这些直接属性任务不能单凭答案错误证明“模型已独立识别事实但未使用该事实”。

## 文件与复现

images/ 为 800 张正式输入；masks/ 为自动标签；previews/ 仅供人工查看，不能作为模型输入。
generation.json 记录种子、依赖版本及生成器哈希；validation.json 为已保存文件的校验结果。
生成器只依赖 Pillow 和 NumPy，不调用图像生成模型；保持记录的依赖版本可精确复现。

```bash
python -m pip install -r requirements.txt
python generate_dataset.py --output /path/to/new_dataset --seed 42
python generate_dataset.py --output /path/to/existing_dataset --validate-only
```

新生成必须使用尚不存在的目录，不覆盖已有数据。tests/ 或服务器推理入口不由该生成器修改。
"""


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--validate-only", action="store_true")
    args = parser.parse_args()
    root = args.output.resolve()
    if not args.validate_only:
        records, _ = generate(root, args.seed)
        previews(root, records)
        (root / "README.md").write_text(README)
        (root / "requirements.txt").write_text(f"Pillow=={pillow_version}\nnumpy=={np.__version__}\n")
        shutil.copy2(__file__, root / "generate_dataset.py")
    _, report = audit(root)
    print(json.dumps(dict(output=str(root), status=report["status"], families=report["families"],
                         images=report["images"], checks=report["checks"]), indent=2), flush=True)


if __name__ == "__main__":
    main()
