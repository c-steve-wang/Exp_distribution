"""CPU tests use temporary synthetic outputs, never reported as VLM results."""
import contextlib
import io
import json
from pathlib import Path
import tempfile
import unittest
from types import SimpleNamespace
from unittest.mock import patch
import numpy as np
from backend_core.common import read_json, write_json
from backend_core.backends import question_indices, gemma_token_boxes
from controlled.metrics import attention, score, make_summary
from controlled import runner

ROOT=Path(__file__).resolve().parents[1]
ROWS=runner.rows_at(ROOT/'data')


def text(answer,status='ANSWERED',boxes=None):
    return json.dumps(dict(answer=answer,status=status,boxes=boxes or [],facts=[]))


class ScoringTest(unittest.TestCase):
    def setUp(self):
        group=ROWS[0]['source_group_id']
        self.rows=[r for r in ROWS if r['source_group_id']==group]

    def test_correct_color_and_exact_localization(self):
        row=self.rows[0]
        boxes=[dict(view=0,bbox=[v/1024 for v in r['bbox_xyxy']]) for r in row['reference']['regions']]
        result=score(row,text(row['reference']['answer'],boxes=boxes))
        self.assertTrue(result['answer_correct'])
        self.assertTrue(result['localization_correct'])

    def test_hidden_is_unknown_not_absence(self):
        row=next(r for r in self.rows if r['condition']=='I_hidden')
        self.assertTrue(score(row,text('UNKNOWN','UNKNOWN'))['answer_correct'])
        self.assertFalse(score(row,text('red'))['answer_correct'])
        self.assertFalse(score(row,text('0'))['answer_correct'])
        self.assertIsNone(score(row,text('UNKNOWN','UNKNOWN'))['localization_correct'])

    def test_inconsistent_unknown_and_format_failures(self):
        row=self.rows[0]
        for raw in [text('red','UNKNOWN'),text('UNKNOWN'),'{not json}',text('UNKNOWN','UNKNOWN',[dict(view=0,bbox=[0,0,1,1])])]:
            self.assertFalse(score(row,raw)['format_valid'])
            self.assertFalse(score(row,raw)['strict_answer_correct'])

    def test_extra_box_is_localization_failure(self):
        row=self.rows[0]
        boxes=[dict(view=0,bbox=[v/1024 for v in r['bbox_xyxy']]) for r in row['reference']['regions']]
        boxes.append(dict(view=0,bbox=[0,0,.1,.1]))
        result=score(row,text(row['reference']['answer'],boxes=boxes))
        self.assertTrue(result['answer_correct'])
        self.assertFalse(result['localization_correct'])

    def test_count_word_normalization(self):
        row=next(r for r in ROWS if r['task_type']=='counting' and r['reference']['answer']=='2')
        self.assertTrue(score(row,text('Two.'))['answer_correct'])

    def test_invariance_cannot_count_two_wrong_answers_as_success(self):
        records=[dict(sample_id=r['sample_id'],status='ok',scores=score(r,text('green')),attention={}) for r in self.rows]
        summary,_,pairs=make_summary(self.rows,records)
        self.assertEqual(summary['paired']['cpc'],0)
        self.assertEqual(summary['paired']['invariance_same_answer'],1)
        self.assertEqual(summary['paired']['invariance_both_correct'],0)
        self.assertIsNone(summary['paired']['stale_rate_given_baseline_correct'])
        self.assertEqual(len(pairs),1)

    def test_missing_and_runtime_error_denominators(self):
        error=dict(sample_id=self.rows[0]['sample_id'],status='error',error='test only')
        summary,observations,pairs=make_summary(self.rows,[error])
        self.assertEqual(summary['completeness']['missing_images'],3)
        self.assertEqual(summary['completeness']['runtime_errors'],1)
        self.assertEqual(summary['scope'],'partial_attempted_only')
        self.assertEqual(summary['conditions']['I_plus']['accuracy'],0)
        self.assertEqual(len(pairs),0)
        self.assertIsNone(observations[0]['target_enrichment'])


class AttentionTest(unittest.TestCase):
    def test_area_baseline_is_not_uniform_token_baseline(self):
        boxes=[dict(view=0,bbox=[0,0,256,1024]),dict(view=0,bbox=[256,0,1024,1024])]
        mask=np.zeros((1024,1024),dtype=bool)
        mask[:,:256]=True
        result=attention(np.array([[.25,.75]]),boxes,mask)
        self.assertAlmostEqual(result['region_mass'],.25)
        self.assertAlmostEqual(result['area_baseline'],.25)
        self.assertAlmostEqual(result['enrichment'],1)

    def test_overlapping_thumbnail_retains_uniform_spatial_reference(self):
        boxes=[dict(view=0,bbox=[0,0,256,1024]),dict(view=0,bbox=[256,0,1024,1024]),dict(view=0,bbox=[0,0,1024,1024])]
        mask=np.zeros((1024,1024),dtype=bool)
        mask[:,:256]=True
        result=attention(np.array([[.125,.375,.5]]),boxes,mask)
        self.assertAlmostEqual(result['enrichment'],1)

    def test_empty_target_and_zero_attention_are_not_imputed(self):
        boxes=[dict(view=0,bbox=[0,0,1024,1024])]
        empty=np.zeros((1024,1024),dtype=bool)
        self.assertIsNone(attention(np.ones((1,1)),boxes,empty)['enrichment'])
        self.assertIsNone(attention(np.zeros((1,1)),boxes,~empty)['enrichment'])

    def test_question_tokens_and_causal_fallback(self):
        self.assertEqual(question_indices([9,9,3,4],[3,4],[0,1])[0],[2,3])
        self.assertEqual(question_indices([3,4,9,9,5],[3,4],[2,3]),([4],'last_prompt_token_causal_fallback'))
        with self.assertRaises(ValueError):
            question_indices([9,9,3,4],[7,8],[0,1])

    def test_gemma_pooling_geometry(self):
        positions=[[[x,y] for y in range(4) for x in range(4)]]
        boxes,grids=gemma_token_boxes(positions,2,[dict(source_box=[0,0,1024,1024])])
        self.assertEqual(grids,[[2,2]])
        self.assertEqual(boxes[0]['bbox'],[0,0,512,512])
        with self.assertRaises(ValueError):
            gemma_token_boxes([list(reversed(positions[0]))],2,[dict(source_box=[0,0,1024,1024])])


class FakeBackend:
    """Fixed invalid-color answer; this is only a cache/IO fixture, not a model."""
    def __init__(self):
        self.calls=0
    def metadata(self):
        return dict(kind='UNIT_TEST_FAKE_NOT_A_MODEL')
    def infer(self,**kwargs):
        self.calls+=1
        assert set(kwargs)=={'views','prompt','question','system','seed','capture','output_schema'}
        return dict(text=text('green'),layer_weights=np.array([[.25,.75]]),
                    local_layer_weights=np.empty((0,2)),head_weights=np.array([[[.25,.75]]]),
                    token_boxes=[dict(view=0,bbox=[0,0,256,1024]),dict(view=0,bbox=[256,0,1024,1024])])


class WorkflowTest(unittest.TestCase):
    def test_trial_resume_and_missing_array_recovery(self):
        backend=FakeBackend()
        cfg=read_json(ROOT/'configs/protocol.json')
        with tempfile.TemporaryDirectory() as tmp:
            args=SimpleNamespace(data_root=ROOT/'data',output_root=Path(tmp),model='fixture',
                                 limit_groups=3,shard_index=0,shards=1,retry_errors=False)
            run=runner.run_context(args,cfg,backend)
            write_json(run/'server_validation.json',dict(status='passed',scope='unit_test_fixture_only'))
            with patch.object(runner,'load_backend',return_value=backend),contextlib.redirect_stdout(io.StringIO()):
                runner.run_model(args,cfg,ROWS)
                self.assertEqual(backend.calls,12)
                self.assertEqual(read_json(run/'summary.json')['completeness']['attempted_complete_groups'],3)
                runner.run_model(args,cfg,ROWS)
                self.assertEqual(backend.calls,12)
                record=read_json(next((run/'records').glob('*.json')))
                (run/record['attention_file']).unlink()
                runner.run_model(args,cfg,ROWS)
                self.assertEqual(backend.calls,13)
            self.assertEqual(len(list((run/'records').glob('*.json'))),12)


if __name__=='__main__':
    unittest.main()
