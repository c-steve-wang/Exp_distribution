import json
import unittest
from backend_core.protocol import parse_prediction, prediction_schema, MAX_BOXES
from controlled.metrics import score
from controlled.runner import ROOT, rows_at, call_args
from backend_core.common import read_json


class ServerProtocolTest(unittest.TestCase):
    def setUp(self):
        self.box = dict(view=0, bbox=[0.1, 0.2, 0.3, 0.4])
        self.prediction = dict(answer='2', status='ANSWERED', boxes=[self.box], facts=[])

    def test_duplicate_box_is_rejected_without_silent_deduplication(self):
        self.prediction['boxes'] *= 2
        self.assertIn('Duplicate', parse_prediction(json.dumps(self.prediction), 1)['parse_error'])

    def test_repeated_json_and_duplicate_keys_are_rejected(self):
        raw = json.dumps(self.prediction)
        self.assertIsNotNone(parse_prediction(raw + raw, 1)['parse_error'])
        self.assertIsNotNone(parse_prediction(raw.replace('"answer": "2"', '"answer":"2","answer":"3"'), 1)['parse_error'])

    def test_multiple_distinct_objects_remain_allowed(self):
        self.prediction['boxes'].append(dict(view=0, bbox=[0.5, 0.6, 0.7, 0.8]))
        self.assertIsNone(parse_prediction(json.dumps(self.prediction), 1)['parse_error'])

    def test_budget_overflow_and_nonfinite_geometry_fail(self):
        self.prediction['boxes'] *= MAX_BOXES + 1
        self.assertIsNotNone(parse_prediction(json.dumps(self.prediction), 1)['parse_error'])
        self.prediction['boxes'] = [dict(view=0, bbox=[0, 0, float('nan'), 1])]
        self.assertIsNotNone(parse_prediction(json.dumps(self.prediction), 1)['parse_error'])

    def test_truncated_response_cannot_be_a_correct_answer(self):
        row = rows_at(ROOT / 'data')[0]
        self.prediction['answer'] = row['reference']['answer']
        self.assertFalse(score(row, json.dumps(self.prediction), finish_reason='length')['format_valid'])

    def test_all_tasks_conditions_have_identical_reference_blind_schema(self):
        cfg = read_json(ROOT / 'configs/protocol.json')
        rows = rows_at(ROOT / 'data')
        for task in ['attribute', 'counting', 'spatial']:
            for condition in ['I_plus', 'I_minus', 'I_zero', 'I_hidden']:
                row = next(r for r in rows if r['task_type'] == task and r['condition'] == condition)
                # Request construction must not access annotations or answers.
                row = {k: v for k, v in row.items() if k not in {'reference', 'annotations', 'provenance'}}
                request = call_args(ROOT / 'data', row, cfg)
                self.assertEqual(request['output_schema'], prediction_schema())
                self.assertEqual(request['question'], row['question'])
        self.assertEqual(cfg['model_defaults']['generation']['max_new_tokens'], 1024)
        self.assertEqual(cfg['input_edge'], 384)


if __name__ == '__main__':
    unittest.main()
