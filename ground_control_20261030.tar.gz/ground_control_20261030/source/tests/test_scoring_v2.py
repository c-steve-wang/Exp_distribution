import json
import unittest
from controlled import runner as r
from controlled.metrics import score, make_summary


class IndependentScoringTest(unittest.TestCase):
    def setUp(self):
        self.rows = r.rows_at(r.ROOT/'data')
        self.row = next(row for row in self.rows if row['condition']=='I_plus')
        self.boxes = [dict(view=0,bbox=[v/1024 for v in region['bbox_xyxy']]) for region in self.row['reference']['regions']]
        self.value = dict(answer=self.row['reference']['answer'],status='ANSWERED',boxes=self.boxes,facts=[])

    def result(self, value=None, row=None):
        return score(row or self.row,json.dumps(self.value if value is None else value))

    def test_correct_answer_survives_invalid_geometry(self):
        self.value['boxes'] = [dict(view=0,bbox=[1,1,1,1])]
        out = self.result()
        self.assertTrue(out['answer_correct'])
        self.assertFalse(out['format_valid'])
        self.assertFalse(out['localization_correct'])

    def test_exact_boxes_survive_missing_answer_and_bad_facts(self):
        del self.value['answer']
        self.value['facts'] = 123
        out = self.result()
        self.assertTrue(out['localization_correct'])
        self.assertFalse(out['answer_correct'])
        self.assertFalse(out['format_valid'])

    def test_duplicate_boxes_remain_extras(self):
        self.value['boxes'] = self.boxes+self.boxes[:1]
        out = self.result()
        self.assertTrue(out['answer_correct'])
        self.assertFalse(out['format_valid'])
        self.assertFalse(out['localization_correct'])
        self.assertEqual(len(out['predicted_boxes']),len(self.boxes)+1)

    def test_answer_content_and_status_separate(self):
        self.value['status'] = 'UNKNOWN'
        out = self.result()
        self.assertTrue(out['answer_correct'])
        self.assertTrue(out['localization_correct'])
        self.assertFalse(out['answer_status_valid'])
        self.assertFalse(out['format_valid'])

    def test_hidden_answer_survives_extraneous_boxes(self):
        hidden = next(row for row in self.rows if row['condition']=='I_hidden')
        out = self.result(dict(answer='UNKNOWN',status='UNKNOWN',boxes=self.boxes,facts=[]),hidden)
        self.assertTrue(out['answer_correct'])
        self.assertTrue(out['unknown'])
        self.assertFalse(out['format_valid'])
        self.assertIsNone(out['localization_correct'])

    def test_invalid_json_and_truncation_not_salvaged(self):
        text = json.dumps(self.value)
        for raw, finish in [(text+text,None),(text,'length'),(text.replace('"answer":', '"answer":"bad","answer":'),None)]:
            out = score(self.row,raw,finish_reason=finish)
            self.assertFalse(out['answer_correct'])
            self.assertFalse(out['localization_correct'])
            self.assertFalse(out['format_valid'])

    def test_pair_metrics_and_joint_keep_independent_dimensions(self):
        rows = [row for row in self.rows if row['source_group_id']==self.row['source_group_id']]
        records = []
        for row in rows:
            value = dict(answer=row['reference']['answer'],status='UNKNOWN' if row['condition']=='I_hidden' else 'ANSWERED',
                         boxes=[dict(view=0,bbox=[1,1,1,1])],facts=[])
            records.append(dict(sample_id=row['sample_id'],status='ok',scores=score(row,json.dumps(value)),
                                attention=dict(target=dict(enrichment=2))))
        report, _, _ = make_summary(rows,records)
        self.assertEqual(report['paired']['cpc'],1)
        self.assertEqual(report['paired']['invariance_same_answer'],1)
        self.assertTrue(all(not item['format_valid'] and item['answer_correct'] for item in report['joint']))

    def test_uniform_occlusion_prompt_is_reference_blind(self):
        cfg = r.read_json(r.ROOT/'configs/protocol.json')
        prompts = set()
        for condition in ['I_plus','I_minus','I_zero','I_hidden']:
            row = next(row for row in self.rows if row['condition']==condition)
            row = {k:v for k,v in row.items() if k not in ['reference','annotations','provenance']}
            prompts.add(r.call_args(r.ROOT/'data',row,cfg)['system'])
        self.assertEqual(len(prompts),1)
        self.assertIn('opaque occluder',prompts.pop())
