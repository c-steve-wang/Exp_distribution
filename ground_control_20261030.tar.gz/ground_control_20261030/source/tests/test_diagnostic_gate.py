"""Verify diagnostic mode cannot bypass failed measurement or forgive bad boxes."""
import contextlib
import io
from pathlib import Path
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch
from backend_core.common import read_json, write_json
from controlled import runner
from test_controlled import FakeBackend, ROWS, ROOT, text
from controlled.metrics import score


class DiagnosticGateTest(unittest.TestCase):
    def test_measurement_failure_still_blocks_and_format_failure_stays_invalid(self):
        cfg = read_json(ROOT / 'configs/protocol.json')
        backend = FakeBackend()
        with tempfile.TemporaryDirectory() as tmp:
            args = SimpleNamespace(data_root=ROOT/'data', output_root=Path(tmp), model='fixture',
                                   limit_groups=3, shard_index=0, shards=1, retry_errors=False,
                                   allow_format_failures=True)
            run = runner.run_context(args, cfg, backend)
            check = run / 'server_validation.json'
            write_json(check, dict(status='failed', measurement_status='failed'))
            with patch.object(runner, 'load_backend', return_value=backend):
                with self.assertRaises(RuntimeError):
                    runner.run_model(args, cfg, ROWS)
                self.assertEqual(backend.calls, 0)
                write_json(check, dict(status='failed', measurement_status='passed', output_format_status='failed'))
                with contextlib.redirect_stdout(io.StringIO()):
                    runner.run_model(args, cfg, ROWS)
                self.assertEqual(backend.calls, 12)
                self.assertEqual(read_json(check)['status'], 'failed')
            invalid = score(ROWS[0], text(ROWS[0]['reference']['answer'], boxes=[dict(view=0, bbox=[1,1,1,1])]))
            self.assertFalse(invalid['format_valid'])
            self.assertTrue(invalid['answer_correct'])
            self.assertFalse(invalid['localization_correct'])

    def test_strict_mode_never_accepts_failed_smoke(self):
        cfg = read_json(ROOT / 'configs/protocol.json')
        with tempfile.TemporaryDirectory() as tmp:
            args = SimpleNamespace(data_root=ROOT/'data', output_root=Path(tmp), model='fixture',
                                   limit_groups=3, shard_index=0, shards=1, retry_errors=False)
            backend = FakeBackend()
            run = runner.run_context(args, cfg, backend)
            write_json(run / 'server_validation.json', dict(status='failed', measurement_status='passed'))
            with patch.object(runner, 'load_backend', return_value=backend), self.assertRaises(RuntimeError):
                runner.run_model(args, cfg, ROWS)
