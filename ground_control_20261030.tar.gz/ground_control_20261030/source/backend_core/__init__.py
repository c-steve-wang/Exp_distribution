"""Adapters reused from the main experiments; server GPU validation is required."""
