"""Native HF adapters; torch is imported only when a server model is loaded."""
from contextlib import nullcontext
import math
import time
import numpy as np
from .geometry import grid_boxes, map_box


def question_indices(input_ids, question_ids, visual_indices):
    if not visual_indices:
        raise ValueError('No visual tokens')
    matches = [i for i in range(len(input_ids) - len(question_ids) + 1)
               if input_ids[i:i + len(question_ids)] == question_ids]
    if not question_ids or not matches:
        raise ValueError('Original question tokens not located; refusing a tokenization proxy')
    indices = list(range(matches[-1], matches[-1] + len(question_ids)))
    visible = [i for i in indices if i > max(visual_indices)]
    if visible:
        return visible, 'question_tokens_after_images'
    if len(input_ids) - 1 <= max(visual_indices):
        raise ValueError('No text query can attend to every image')
    return [len(input_ids) - 1], 'last_prompt_token_causal_fallback'


def aligned_question_indices(tokenizer, input_ids, question, visual_indices):
    """Locate the actual input tokens without changing the model's prompt.

    Preserve exact matches. At whitespace/token boundaries, use character
    offsets only after verifying that decoded text re-encodes to the exact
    processor input IDs. Never substitute a different query or include a
    neighboring instruction in a boundary token.
    """
    question_ids = tokenizer.encode(question, add_special_tokens=False)
    try:
        return question_indices(input_ids, question_ids, visual_indices)
    except ValueError:
        if not visual_indices or not question.strip():
            raise
    text = tokenizer.decode(input_ids, skip_special_tokens=False, clean_up_tokenization_spaces=False)
    encoded = tokenizer(text, add_special_tokens=False, return_offsets_mapping=True)
    if list(encoded['input_ids']) != input_ids:
        raise ValueError('Question alignment cannot verify the actual processor token sequence')
    start = text.rfind(question)
    if start < 0:
        raise ValueError('Original question text not located in the verified processor input')
    end = start + len(question)
    while start < end and text[start].isspace():
        start += 1
    while end > start and text[end - 1].isspace():
        end -= 1
    indices = []
    for i, (a, b) in enumerate(encoded['offset_mapping']):
        if a < end and b > start:
            outside = text[a:start] if a < start else ''
            outside += text[end:b] if b > end else ''
            if outside.strip():
                raise ValueError('Question boundary token also contains a neighboring instruction')
            indices.append(i)
    if not indices:
        raise ValueError('No question tokens overlap the verified question span')
    visible = [i for i in indices if i > max(visual_indices)]
    if visible:
        return visible, 'question_tokens_after_images_verified_offsets'
    if len(input_ids) - 1 <= max(visual_indices):
        raise ValueError('No text query can attend to every image')
    return [len(input_ids) - 1], 'last_prompt_token_causal_fallback'


def gemma_token_boxes(position_ids, pooling, views):
    """Gemma4 positions are unpooled (x,y); -1 positions are padding."""
    if len(position_ids) != len(views):
        raise ValueError('Gemma image count differs from views')
    boxes, grids = [], []
    for i, positions in enumerate(position_ids):
        valid = np.asarray(positions)
        valid = valid[(valid >= 0).all(axis=-1)]
        width, height = (valid.max(axis=0) + 1).tolist()
        expected = np.array([(x, y) for y in range(height) for x in range(width)])
        if not np.array_equal(valid, expected) or width % pooling or height % pooling:
            raise ValueError('Unverified Gemma patch order or pooling dimensions')
        grids.append([height // pooling, width // pooling])
        boxes += grid_boxes(height // pooling, width // pooling, views[i]['source_box'], i)
    return boxes, grids


class AttentionCapture:
    """Reduce prefill matrices at each text layer; never retain the N×N stack."""
    def __init__(self, decoder, queries, visual, prompt_length):
        self.decoder, self.queries, self.visual = decoder, queries, visual
        self.prompt_length = prompt_length
        self.handles, self.layers, self.weights, self.heads, self.types = [], [], {}, {}, {}
        self.per_head = {}

    def __enter__(self):
        for name, module in self.decoder.named_modules():
            if name.endswith('.self_attn') and hasattr(module, 'q_proj'):
                self.layers.append(name)
                self.types[name] = getattr(module, 'layer_type', None) or 'full_attention'
                self.handles.append(module.register_forward_hook(self._hook(name)))
        if not self.layers:
            raise ValueError('No supported text self-attention modules found')
        return self

    def _hook(self, name):
        def capture(module, args, output):
            if not isinstance(output, tuple) or len(output) < 2:
                raise ValueError('Unsupported attention output: ' + name)
            weights = output[1]
            if weights is not None and weights.ndim == 4 and weights.shape[-2] == self.prompt_length:
                if name in self.weights:
                    raise ValueError('Repeated prefill capture: ' + name)
                selected = weights[0, :, self.queries, :][:, :, self.visual]
                if tuple(selected.shape) != (weights.shape[1], len(self.queries), len(self.visual)):
                    raise ValueError('Unexpected head/query/visual indexing layout: ' + name)
                self.weights[name] = selected.float().mean(dim=(0, 1)).detach().cpu().numpy()
                self.per_head[name] = selected.float().mean(dim=1).detach().cpu().numpy()
                self.heads[name] = int(weights.shape[1])
            # Only the diagnostic matrix is removed; the computed activation is untouched.
            return (output[0], None, *output[2:])
        return capture

    def __exit__(self, *args):
        for handle in self.handles:
            handle.remove()

    def result(self):
        missing = set(self.layers) - set(self.weights)
        if missing:
            raise ValueError('Missing attention weights: ' + ', '.join(sorted(missing)))
        full = [n for n in self.layers if self.types[n] == 'full_attention']
        local = [n for n in self.layers if self.types[n] == 'sliding_attention']
        if not full or len(full) + len(local) != len(self.layers):
            raise ValueError('Unknown attention layer types or no global layers')
        return dict(layer_weights=np.stack([self.weights[n] for n in full]), layer_names=full,
                    head_weights=np.stack([self.per_head[n] for n in full]),
                    local_layer_weights=np.stack([self.weights[n] for n in local]) if local else np.empty((0, len(self.visual))),
                    local_layer_names=local, heads_per_layer=self.heads, layer_types=self.types)


class VisionBackend:
    def __init__(self, spec, locked_model):
        import torch
        import transformers
        self.torch, self.transformers = torch, transformers
        if not torch.cuda.is_available():
            raise RuntimeError('Model inference requires an allocated server CUDA GPU')
        self.spec, self.lock = spec, locked_model
        if len(locked_model['revision']) != 40 or locked_model['repo_id'] != spec['repo_id']:
            raise ValueError('A matching checkpoint lock with a resolved 40-character revision is required')
        path = locked_model.get('local_path') or spec['repo_id']
        kwargs = dict(revision=locked_model['revision'])
        self.dtype = getattr(torch, spec.get('dtype', 'bfloat16'))
        self.processor = transformers.AutoProcessor.from_pretrained(path, **kwargs, **spec.get('processor_kwargs', {}))
        self.tokenizer = self.processor.tokenizer
        self.model = transformers.AutoModelForImageTextToText.from_pretrained(
            path, **kwargs, dtype=self.dtype, device_map=spec.get('device_map', 'auto'),
            attn_implementation=({'text_config': 'eager', 'vision_config': 'sdpa', 'audio_config': 'eager'}
                                 if spec['adapter'] == 'gemma4' else 'sdpa')).eval()
        if self.model.config.model_type not in spec['expected_model_types']:
            raise ValueError('Checkpoint architecture differs from configured adapter')
        self.decoder = self.model.model.language_model
        self.decoder.set_attn_implementation('eager')
        self.device = self.model.get_input_embeddings().weight.device

    def _inputs(self, views, prompt, system):
        content = [{'type': 'image', 'image': v['image']} for v in views] + [{'type': 'text', 'text': prompt}]
        messages = [{'role': 'system', 'content': system}, {'role': 'user', 'content': content}]
        text = self.processor.apply_chat_template(messages, tokenize=False, add_generation_prompt=True,
                                                 **self.spec.get('template_kwargs', {}))
        batch = self.processor(text=[text], images=[v['image'] for v in views], return_tensors='pt',
                               **self.spec.get('image_kwargs', {}))
        processor = self.processor.image_processor
        adapter = self.spec['adapter']
        boxes, extra = [], {}
        if adapter == 'qwen':
            grids = batch['image_grid_thw'].tolist()
            merge = self.model.config.vision_config.spatial_merge_size
            if len(grids) != len(views):
                raise ValueError('Qwen image/view count mismatch')
            for i, (t, h, w) in enumerate(grids):
                if t != 1 or h % merge or w % merge:
                    raise ValueError('Unsupported Qwen temporal or merge grid')
                boxes += grid_boxes(h // merge, w // merge, views[i]['source_box'], i)
            extra.update(image_grid_thw=grids, spatial_merge_size=merge)
        elif adapter == 'gemma4':
            positions = batch['image_position_ids'].tolist()
            boxes, grids = gemma_token_boxes(positions, processor.pooling_kernel_size, views)
            extra.update(pooled_grids=grids, pooling_kernel_size=processor.pooling_kernel_size)
        elif adapter == 'internvl':
            from transformers.models.got_ocr2.image_processing_got_ocr2 import get_optimal_tiled_canvas
            tile_h, tile_w = processor.size['height'], processor.size['width']
            grid = math.isqrt(self.processor.image_seq_length)
            if grid * grid != self.processor.image_seq_length:
                raise ValueError('InternVL tile tokens are not square')
            tiles = []
            for i, v in enumerate(views):
                cols, rows = get_optimal_tiled_canvas((v['image'].height, v['image'].width),
                    (tile_h, tile_w), self.spec['image_kwargs']['min_patches'], self.spec['image_kwargs']['max_patches'])
                rectangles = [t['bbox'] for t in grid_boxes(rows, cols, [0, 0, 1, 1])]
                if len(rectangles) > 1:
                    rectangles.append([0, 0, 1, 1])
                for j, rectangle in enumerate(rectangles):
                    source = map_box(rectangle, v['source_box'])
                    boxes += grid_boxes(grid, grid, source, i)
                    tiles.append(dict(view=i, source_box=source, thumbnail=cols * rows > 1 and j == cols * rows))
            if len(tiles) != batch['pixel_values'].shape[0]:
                raise ValueError('InternVL native tile count disagrees with spatial mapping')
            extra.update(tiles=tiles, tile_grid=[grid, grid])
        else:
            raise ValueError('Unknown adapter: ' + adapter)
        visual_id = self.model.config.image_token_id
        ids = batch['input_ids'][0].tolist()
        runs, previous = [], -2
        for index, token in enumerate(ids):
            if token == visual_id:
                if index != previous + 1:
                    runs.append(0)
                runs[-1] += 1
                previous = index
        # InternVL uses one contiguous image-token run across a view's tiles.
        expected = [sum(b['view'] == i for b in boxes) for i in range(len(views))]
        if runs != expected:
            raise ValueError(f'Per-view token order/count mismatch: {runs} versus {expected}')
        batch = {k: v.to(self.device, dtype=self.dtype) if v.is_floating_point() else v.to(self.device)
                 for k, v in batch.items()}
        extra['tensor_shapes'] = {k: list(v.shape) for k, v in batch.items()}
        extra['tensor_dtypes'] = {k: str(v.dtype) for k, v in batch.items()}
        return batch, boxes, visual_id, dict(processor=processor.to_dict(), **extra)

    def infer(self, views, prompt, question, system, seed, capture=True, generation_override=None, output_schema=None):
        torch = self.torch
        self.transformers.set_seed(seed)
        for i in range(torch.cuda.device_count()):
            torch.cuda.reset_peak_memory_stats(i)
        started = time.perf_counter()
        batch, boxes, visual_id, preprocessing = self._inputs(views, prompt, system)
        ids = batch['input_ids'][0].tolist()
        if len(ids) > self.spec['max_input_tokens']:
            raise ValueError('Input exceeds attention memory bound; views were not truncated')
        visual = [i for i, token in enumerate(ids) if token == visual_id]
        queries, mode = aligned_question_indices(self.tokenizer, ids, question, visual)
        generation = dict(self.spec['generation'])
        generation.update(generation_override or {})
        generation.update(output_attentions=False, return_dict_in_generate=False)
        eos = generation.get('eos_token_id', self.model.generation_config.eos_token_id)
        eos = list(eos) if isinstance(eos, (list, tuple)) else [eos]
        eos = list(dict.fromkeys(i for i in eos + [self.tokenizer.eos_token_id] if i is not None))
        if not eos:
            raise ValueError('No native end token available')
        generation['eos_token_id'] = eos
        generate_kwargs = dict(generation)
        if output_schema is not None:
            from .structured import StructuredDecoder, structured_metadata
            if structured_metadata(self.spec) is None:
                raise ValueError('Output schema requires structured decoding')
            if getattr(self, '_structured_decoder_key', None) != tuple(eos):
                self._structured_decoder = StructuredDecoder(
                    self.tokenizer, self.model.get_output_embeddings().weight.shape[0], eos)
                self._structured_decoder_key = tuple(eos)
            generate_kwargs['logits_processor'] = self.transformers.LogitsProcessorList(
                [self._structured_decoder.processor(output_schema)])
        collector = AttentionCapture(self.decoder, queries, visual, len(ids)) if capture else None
        for i in range(torch.cuda.device_count()):
            torch.cuda.synchronize(i)
        input_seconds = time.perf_counter() - started
        started = time.perf_counter()
        with torch.inference_mode(), collector if collector else nullcontext():
            sequence = self.model.generate(**batch, **generate_kwargs)
        for i in range(torch.cuda.device_count()):
            torch.cuda.synchronize(i)
        output_ids = sequence[0, len(ids):]
        stopped = bool(len(output_ids)) and int(output_ids[-1]) in eos
        result = dict(text=self.tokenizer.decode(output_ids, skip_special_tokens=True),
            finish_reason='eos' if stopped else 'length' if len(output_ids) >= generation['max_new_tokens'] else 'other',
            reached_token_limit=len(output_ids) >= generation['max_new_tokens'],
            output_schema=output_schema,

            input_tokens=len(ids), output_tokens=len(output_ids), output_ids=output_ids.tolist(),
            input_seconds=input_seconds, inference_seconds=time.perf_counter() - started,
            peak_allocated_bytes=[int(torch.cuda.max_memory_allocated(i)) for i in range(torch.cuda.device_count())],
            query_mode=mode, query_indices=queries, visual_indices=visual, spatial_visual_tokens=len(visual),
            preprocessing=preprocessing, token_boxes=boxes, checkpoint_revision=self.lock['revision'], generation=generation)
        if capture:
            result.update(collector.result(), attention_stage='prefill', attention_implementation='text_eager_vision_sdpa')
        return result

    def metadata(self):
        return dict(model=self.spec, lock=self.lock, torch=self.torch.__version__,
                    transformers=self.transformers.__version__, cuda=self.torch.version.cuda,
                    devices=[self.torch.cuda.get_device_name(i) for i in range(self.torch.cuda.device_count())],
                    model_config=self.model.config.to_dict(),
                    checkpoint_generation_config=self.model.generation_config.to_dict(),
                    tokenizer_eos_token_id=self.tokenizer.eos_token_id,
                    structured_output=__import__('backend_core.structured', fromlist=['structured_metadata']).structured_metadata(self.spec))

    def prefill_logits(self, views, prompt, question, system, capture):
        """Numerical adapter check only; these logits are not experimental confidence scores."""
        batch, boxes, visual_id, _ = self._inputs(views, prompt, system)
        ids = batch['input_ids'][0].tolist()
        visual = [i for i, token in enumerate(ids) if token == visual_id]
        queries, _ = aligned_question_indices(self.tokenizer, ids, question, visual)
        collector = AttentionCapture(self.decoder, queries, visual, len(ids)) if capture else None
        with self.torch.inference_mode(), collector if collector else nullcontext():
            output = self.model(**batch, use_cache=False, logits_to_keep=1)
        if collector:
            collector.result()
        return output.logits[0, -1].float().cpu().numpy()
