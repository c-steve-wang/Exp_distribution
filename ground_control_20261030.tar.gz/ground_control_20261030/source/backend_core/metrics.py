"""Required helpers extracted from the existing main-experiment implementation."""
import math
import re
import unicodedata
import numpy as np


def iou(a, b):
    intersection = max(0, min(a[2], b[2]) - max(a[0], b[0])) * max(0, min(a[3], b[3]) - max(a[1], b[1]))
    union = (a[2] - a[0]) * (a[3] - a[1]) + (b[2] - b[0]) * (b[3] - b[1]) - intersection
    return intersection / union if union > 0 else 0.


def box_matches(predicted, reference, threshold=.5):
    """Maximum bipartite cardinality matching, not order-dependent greedy matching."""
    owners = {}
    edges = [[j for j, target in enumerate(reference) if iou(box, target) >= threshold] for box in predicted]
    def assign(i, seen):
        for j in edges[i]:
            if j in seen:
                continue
            seen.add(j)
            if j not in owners or assign(owners[j], seen):
                owners[j] = i
                return True
        return False
    count = sum(assign(i, set()) for i in range(len(predicted)))
    return dict(matches=count, precision=count / len(predicted) if predicted else 0.,
                recall=count / len(reference) if reference else None,
                all_instances_hit=bool(reference) and count == len(reference),
                all_boxes_correct=bool(reference) and count == len(reference) == len(predicted))


def normalize_answer(text):
    return re.sub(r'\s+', ' ', unicodedata.normalize('NFKC', str(text)).casefold()).strip().rstrip('.。')


def project_mass(weights, token_boxes, size):
    weights = np.asarray(weights, dtype=np.float64)
    if len(weights) != len(token_boxes) or not np.isfinite(weights).all() or (weights < 0).any():
        raise ValueError('Invalid spatial attention weights')
    out = np.zeros((size[1], size[0]), dtype=np.float64)
    for mass, item in zip(weights, token_boxes):
        x1, y1, x2, y2, overlap = cell_overlap(item['bbox'], size)
        out[y1:y2, x1:x2] += mass * overlap
    return out


def cell_overlap(box, size):
    """Integrate continuous token cells over pixels, including subpixel cells."""
    a, b, c, d = box
    x1, y1, x2, y2 = max(0, math.floor(a)), max(0, math.floor(b)), min(size[0], math.ceil(c)), min(size[1], math.ceil(d))
    xx, yy = np.arange(x1, x2), np.arange(y1, y2)
    dx = np.maximum(0, np.minimum(xx + 1, c) - np.maximum(xx, a))
    dy = np.maximum(0, np.minimum(yy + 1, d) - np.maximum(yy, b))
    overlap = dy[:, None] * dx[None, :]
    if overlap.sum() <= 0:
        raise ValueError('Visual token has no image support')
    return x1, y1, x2, y2, overlap / overlap.sum()


def token_mask_fractions(token_boxes, mask, size):
    fractions = []
    for item in token_boxes:
        x1, y1, x2, y2, overlap = cell_overlap(item['bbox'], size)
        fractions.append(float((overlap * mask[y1:y2, x1:x2]).sum()))
    return np.asarray(fractions)
