"""Required helpers extracted from the existing main-experiment implementation."""
import numpy as np
from PIL import Image


def full_box(size):
    return [0, 0, size[0], size[1]]


def resize_long_edge(image, edge):
    if edge is None:
        return image.copy()
    ratio = edge / max(image.size)
    return image.resize(tuple(max(1, round(v * ratio)) for v in image.size), Image.Resampling.LANCZOS)


def view(image, box=None, edge=None, occlusion=None, label='image'):
    box = [int(round(v)) for v in (box or full_box(image.size))]
    canvas = image.copy()
    if occlusion is not None:
        if occlusion.shape != (image.height, image.width):
            raise ValueError('Occlusion dimensions differ from source')
        canvas.paste((128, 128, 128), (0, 0, image.width, image.height),
                     Image.fromarray(occlusion.astype('uint8') * 255))
    cropped = canvas.crop(tuple(box))
    output = resize_long_edge(cropped, edge)
    result = dict(image=output, source_box=box, source_size=list(image.size),
                  input_size=list(output.size), requested_long_edge=edge, label=label,
                  occluded_pixels=int(occlusion.sum()) if occlusion is not None else 0)
    if occlusion is not None:
        result['_occlusion'] = occlusion
    return result


def grid_boxes(rows, cols, box, view_index=0):
    x1, y1, x2, y2 = box
    return [dict(view=view_index, bbox=[x1 + c * (x2 - x1) / cols,
                                      y1 + r * (y2 - y1) / rows,
                                      x1 + (c + 1) * (x2 - x1) / cols,
                                      y1 + (r + 1) * (y2 - y1) / rows])
            for r in range(rows) for c in range(cols)]


def map_box(normalized, source_box):
    x1, y1, x2, y2 = source_box
    a, b, c, d = normalized
    return [x1 + a * (x2 - x1), y1 + b * (y2 - y1),
            x1 + c * (x2 - x1), y1 + d * (y2 - y1)]
