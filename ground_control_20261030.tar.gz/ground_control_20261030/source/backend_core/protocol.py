"""Reference-blind structured output for the controlled diagnostic."""
import json
import math

# A common safety budget, not the annotated object count or a per-condition cap.
MAX_BOXES = 8


def prediction_schema():
    coordinate = dict(type='number', minimum=0, maximum=1)
    box = dict(type='object', properties=dict(view=dict(type='integer', enum=[0]),
        bbox=dict(type='array', items=coordinate, minItems=4, maxItems=4)),
        required=['view', 'bbox'], additionalProperties=False)
    return dict(type='object', properties=dict(answer=dict(type='string'),
        status=dict(type='string', enum=['ANSWERED', 'UNKNOWN']),
        boxes=dict(type='array', items=box, maxItems=MAX_BOXES),
        facts=dict(type='array', items=dict(type='string'), maxItems=3)),
        required=['answer', 'status', 'boxes', 'facts'], additionalProperties=False)


def unique_json_keys(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError('Duplicate JSON key: ' + key)
        result[key] = value
    return result


def final_json(text):
    # Do not promote nested fragments or take the last of repeated responses.
    result = json.loads(text.strip(), object_pairs_hook=unique_json_keys)
    if not isinstance(result, dict):
        raise ValueError('Expected exactly one JSON object')
    return result


def valid_box(box):
    return (isinstance(box, list) and len(box) == 4 and
            all(isinstance(x, (int, float)) and not isinstance(x, bool) and math.isfinite(x) for x in box)
            and 0 <= box[0] < box[2] <= 1 and 0 <= box[1] < box[3] <= 1)


def parse_prediction(text, views, finish_reason=None):
    try:
        if finish_reason == 'length':
            raise ValueError('Output reached the generation limit')
        result = final_json(text)
        if set(result) != {'answer', 'status', 'boxes', 'facts'}:
            raise ValueError('Unexpected or missing JSON fields')
        if not isinstance(result['answer'], str) or not result['answer'].strip():
            raise ValueError('Missing nonempty string answer')
        if result['status'] not in {'ANSWERED', 'UNKNOWN'}:
            raise ValueError('Invalid status')
        if not isinstance(result['boxes'], list) or len(result['boxes']) > MAX_BOXES:
            raise ValueError('Invalid boxes list or box budget exceeded')
        seen = set()
        for item in result['boxes']:
            if (not isinstance(item, dict) or set(item) != {'view', 'bbox'} or
                    type(item['view']) is not int or not 0 <= item['view'] < views or
                    not valid_box(item['bbox'])):
                raise ValueError('Invalid normalized box or view index')
            identity = (item['view'], *item['bbox'])
            if identity in seen:
                raise ValueError('Duplicate predicted box')
            seen.add(identity)
        if (not isinstance(result['facts'], list) or len(result['facts']) > 3 or
                not all(isinstance(f, str) for f in result['facts'])):
            raise ValueError('Invalid facts list')
        result['parse_error'] = None
        return result
    except (ValueError, TypeError, KeyError) as error:
        return dict(answer='', status=None, boxes=[], facts=[], parse_error=str(error))
