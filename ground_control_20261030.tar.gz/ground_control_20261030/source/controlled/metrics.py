"""Closed-label scoring and area-weighted, footprint-aware attention measurements."""
from collections import Counter, defaultdict
import numpy as np
from backend_core.protocol import parse_prediction
from backend_core.metrics import box_matches, normalize_answer, token_mask_fractions


from .scoring import score


def attention(values, boxes, mask):
    values = np.asarray(values, dtype=np.float64)
    if values.ndim != 2 or not values.shape[0] or values.shape[1] != len(boxes):
        raise ValueError('Attention shape differs from mapped visual tokens')
    if not np.isfinite(values).all() or (values < 0).any():
        raise ValueError('Invalid attention values')
    bounds = np.asarray([b['bbox'] for b in boxes], dtype=float)
    areas = (bounds[:, 2] - bounds[:, 0]) * (bounds[:, 3] - bounds[:, 1])
    if (areas <= 0).any() or (bounds < 0).any() or (bounds > 1024).any():
        raise ValueError('Invalid original-image token footprint')
    result = dict(visual_mass=float(values.mean(axis=0).sum()), annotation_pixels=int(mask.sum()))
    if not mask.any() or result['visual_mass'] <= 0:
        return dict(result, region_mass=None, area_baseline=None, enrichment=None, per_layer_region_mass=[])
    fractions = token_mask_fractions(boxes, mask, (1024, 1024))
    raw = values.mean(axis=0)
    mass = float((raw / raw.sum()) @ fractions)
    baseline = float((areas / areas.sum()) @ fractions)
    return dict(result, region_mass=mass, area_baseline=baseline,
                enrichment=mass / baseline if baseline > 0 else None,
                per_layer_region_mass=[float(v @ fractions / v.sum()) if v.sum() > 0 else None for v in values])


def mean(items):
    items = [x for x in items if x is not None]
    return float(np.mean(items)) if items else None


def make_summary(rows, records, threshold=1.):
    by_id = {r['sample_id']: r for r in records}
    expected_ids = {r['sample_id'] for r in rows}
    if not set(by_id).issubset(expected_ids):
        raise ValueError('Output contains samples outside the frozen catalog')
    groups = defaultdict(dict)
    observations, joint = [], Counter()
    for row in rows:
        record = by_id.get(row['sample_id'])
        groups[row['source_group_id']][row['condition']] = (row, record)
        if record is None:
            continue
        ok = record['status'] == 'ok'
        scores = record.get('scores', {})
        target = record.get('attention', {}).get('target', {})
        reference = record.get('attention', {}).get('reference', {})
        hidden = row['condition'] == 'I_hidden'
        item = dict(sample_id=row['sample_id'], source_group_id=row['source_group_id'],
                    task=row['task_type'], condition=row['condition'], status=record['status'],
                    size_px=row['provenance']['parameters']['target_size_px'],
                    distractors=row['provenance']['parameters']['distractor_count'],
                    correct=bool(ok and scores.get('answer_correct')),
                    format_valid=bool(ok and scores.get('format_valid')),
                    answer_field_valid=bool(ok and scores.get('answer_field_valid')),
                    answer_status_valid=bool(ok and scores.get('answer_status_valid')),
                    unknown=bool(ok and scores.get('unknown')),
                    localization_correct=scores.get('localization_correct') if ok else (None if hidden else False),
                    target_mass=target.get('region_mass'), target_enrichment=target.get('enrichment'),
                    reference_mass=reference.get('region_mass'), reference_enrichment=reference.get('enrichment'))
        observations.append(item)
        if not hidden and item['target_enrichment'] is not None:
            joint[(item['task'], item['target_enrichment'] >= threshold,
                   bool(item['localization_correct']), item['correct'], item['format_valid'])] += 1
    pairs = []
    for group_id, members in groups.items():
        if any(record is None for _, record in members.values()):
            continue
        p, m, z, h = [members[k][1] for k in ('I_plus', 'I_minus', 'I_zero', 'I_hidden')]
        row = members['I_plus'][0]
        good = lambda r: r['status'] == 'ok' and r['scores']['answer_correct']
        valid = lambda r: r['status'] == 'ok' and r['scores']['answer_field_valid']
        same = lambda a,b: valid(a) and valid(b) and a['scores']['normalized_answer'] == b['scores']['normalized_answer']
        pairs.append(dict(source_group_id=group_id, task=row['task_type'],
                          size_px=row['provenance']['parameters']['target_size_px'],
                          distractors=row['provenance']['parameters']['distractor_count'],
                          cpc=bool(good(p) and good(m)),
                          invariance_both_correct=bool(good(p) and good(z)),
                          valid_invariance_pair=bool(valid(p) and valid(z)),
                          answer_same_under_I0=bool(same(p,z)),
                          baseline_correct=bool(good(p)),
                          stale_after_correct_baseline=bool(good(p) and same(p,m)),
                          hidden_unknown=bool(good(h)),
                          all_four_correct=bool(all(good(r) for r in (p,m,z,h)))))
    def observation_metrics(items):
        return dict(n=len(items), accuracy=mean([i['correct'] for i in items]),
                    answer_accuracy=mean([i['correct'] for i in items]),
                    answer_field_valid_rate=mean([i['answer_field_valid'] for i in items]),
                    answer_status_valid_rate=mean([i['answer_status_valid'] for i in items]),
                    format_valid_rate=mean([i['format_valid'] for i in items]),
                    unknown_rate=mean([i['unknown'] for i in items]),
                    localization_accuracy=mean([i['localization_correct'] for i in items]),
                    attention_available=sum(i['target_enrichment'] is not None for i in items),
                    target_enrichment_mean=mean([i['target_enrichment'] for i in items]),
                    reference_enrichment_mean=mean([i['reference_enrichment'] for i in items]))
    def pair_metrics(items):
        return dict(n=len(items), cpc=mean([i['cpc'] for i in items]),
                    invariance_both_correct=mean([i['invariance_both_correct'] for i in items]),
                    valid_invariance_pairs=sum(i['valid_invariance_pair'] for i in items),
                    invariance_same_answer=mean([i['answer_same_under_I0'] for i in items if i['valid_invariance_pair']]),
                    baseline_correct_n=sum(i['baseline_correct'] for i in items),
                    stale_rate_given_baseline_correct=mean([i['stale_after_correct_baseline'] for i in items if i['baseline_correct']]),
                    hidden_unknown=mean([i['hidden_unknown'] for i in items]),
                    all_four_correct=mean([i['all_four_correct'] for i in items]))
    task_names = sorted({r['task_type'] for r in rows})
    strata = []
    for task in task_names:
        for size in [24,48,96]:
            for clutter in [4,24]:
                subset = [p for p in pairs if (p['task'],p['size_px'],p['distractors']) == (task,size,clutter)]
                strata.append(dict(task=task,size_px=size,distractors=clutter,**pair_metrics(subset)))
    completeness = dict(expected_images=len(rows), attempted_images=len(observations),
                        successful_inferences=sum(r['status']=='ok' for r in records),
                        runtime_errors=sum(r['status']=='error' for r in records),
                        missing_images=len(rows)-len(observations), expected_groups=len(groups),
                        attempted_complete_groups=len(pairs), full_dataset_complete=len(observations)==len(rows))
    report = dict(completeness=completeness,
                  scope='full_test' if completeness['full_dataset_complete'] else 'partial_attempted_only',
                  conditions={c:observation_metrics([i for i in observations if i['condition']==c])
                              for c in ('I_plus','I_minus','I_zero','I_hidden')},
                  paired=pair_metrics(pairs), by_task={t:pair_metrics([i for i in pairs if i['task']==t]) for t in task_names},
                  difficulty_cells=strata,
                  joint=[dict(task=t,attention_enriched=a,localization_correct=l,answer_correct=c,format_valid=f,n=n)
                         for (t,a,l,c,f),n in sorted(joint.items())],
                  attention_enrichment_threshold=threshold,
                  denominator_note='Partial runs summarize attempted rows and fully attempted quartets only. Runtime failures count as unsuccessful. Answer correctness, localization and format are independent; invalid JSON or truncation is not salvaged. Missing attention is never zero-filled.')
    return report, observations, pairs
