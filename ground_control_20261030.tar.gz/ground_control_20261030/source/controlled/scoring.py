"""Score answer, geometry and full output validity independently."""
from backend_core.protocol import final_json, parse_prediction, valid_box
from backend_core.metrics import box_matches, normalize_answer


def score(row, text, threshold=.5, finish_reason=None):
    prediction = parse_prediction(text, 1, finish_reason)
    raw, json_error = {}, None
    try:
        if finish_reason == 'length':
            raise ValueError('Output reached the generation limit')
        raw = final_json(text)
    except (ValueError, TypeError) as exc:
        json_error = str(exc)
    answer_valid = isinstance(raw.get('answer'), str) and bool(raw['answer'].strip())
    answer = normalize_answer(raw['answer']) if answer_valid else ''
    if row['task_type'] == 'counting':
        answer = {'two': '2', 'three': '3'}.get(answer, answer)
    status = raw.get('status')
    answer_status_valid = bool(answer_valid and
        ((status == 'UNKNOWN' and answer == 'unknown') or (status == 'ANSWERED' and answer != 'unknown')))
    hidden = row['condition'] == 'I_hidden'
    correct = bool(answer_valid and answer == normalize_answer(row['reference']['answer']))
    format_valid = bool(prediction['parse_error'] is None and answer_status_valid and
                        not (status == 'UNKNOWN' and raw.get('boxes')))
    # Geometry is assessed without gating on answer/status/facts. Invalid
    # coordinates are never repaired or dropped; duplicate boxes remain extras.
    boxes_raw = raw.get('boxes')
    boxes_valid = isinstance(boxes_raw, list) and all(
        isinstance(item, dict) and type(item.get('view')) is int and item['view'] == 0
        and valid_box(item.get('bbox')) for item in boxes_raw)
    boxes = [[1024*v for v in item['bbox']] for item in boxes_raw] if boxes_valid else []
    references = [region['bbox_xyxy'] for region in row['reference']['regions']]
    matches = box_matches(boxes, references, threshold) if boxes_valid and not hidden else None
    localization_correct = None if hidden else bool(matches and matches['all_boxes_correct'])
    return dict(scoring_version='independent_answer_localization_format_v2', prediction=prediction,
                normalized_answer=answer, predicted_boxes=boxes, json_error=json_error,
                answer_field_valid=bool(answer_valid), answer_status_valid=answer_status_valid,
                boxes_geometry_valid=bool(boxes_valid), format_valid=format_valid, answer_correct=correct,
                concrete_answer=bool(answer_valid and answer != 'unknown'),
                unknown=bool(answer_valid and answer == 'unknown'),
                status_correct=bool(status == ('UNKNOWN' if hidden else 'ANSWERED')),
                strict_answer_correct=bool(format_valid and correct and status == ('UNKNOWN' if hidden else 'ANSWERED')),
                localization_correct=localization_correct, localization=matches)
