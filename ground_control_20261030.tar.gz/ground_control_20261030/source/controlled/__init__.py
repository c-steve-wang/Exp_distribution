"""Fixed controlled diagnostic supplement for experiments 3 and 4."""
