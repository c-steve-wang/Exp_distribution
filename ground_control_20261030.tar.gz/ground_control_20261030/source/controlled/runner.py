"""Portable CPU preparation and CUDA model verification/run CLI."""
import argparse
import csv
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import sys
import tempfile
import time
import numpy as np
from PIL import Image, ImageDraw
from backend_core.common import fingerprint, file_hash, write_json, read_json, shard_contains
from backend_core.protocol import prediction_schema
from backend_core.geometry import view
from backend_core.backends import VisionBackend
from backend_core.metrics import project_mass
from .metrics import score, attention, make_summary

ROOT = Path(__file__).resolve().parents[1]
SYSTEM = '''Use only the supplied image. A solid gray panel inside the black frame, when present, is an opaque occluder covering original content. The gray is the cover color, not the color of the covered objects; the absence of visible objects under the panel does not mean there were zero objects. Answer about the original content using only visible evidence. If the requested fact is hidden by the panel and cannot be determined, return answer UNKNOWN, status UNKNOWN, and boxes [].
Return one JSON object with this structure:
{"answer":"short answer","status":"ANSWERED or UNKNOWN","boxes":[{"view":0,"bbox":[x1,y1,x2,y2]}],"facts":[]}.
Coordinates must be normalized to [0,1] in the supplied image. Return one box for each shape
inside the black frame; do not box the frame or objects outside it. Use status ANSWERED for
a concrete answer. If the queried fact cannot be determined from the visible image, use
answer UNKNOWN, status UNKNOWN, and boxes []. Do not infer hidden contents from prior knowledge.
Return exactly one JSON object, then stop. Use each key once. Return each physical shape
only once; do not repeat identical boxes or enumerate multiple boxes for the same shape.
Use at most 8 boxes total and at most 3 brief facts. This is a common output budget,
not the number of shapes in the image. Never use pixel or 0-to-1000 coordinates.'''


def rows_at(data):
    rows = [json.loads(line) for line in (data/'catalog.jsonl').read_text().splitlines()]
    if len(rows) != 800 or len({r['source_group_id'] for r in rows}) != 200:
        raise ValueError('Expected the fixed 200-group / 800-image dataset')
    return rows


def mask_at(data, relative):
    with Image.open(data/relative) as im:
        return np.asarray(im)>0


def observed(data, row, edge):
    path = data/row['image']['path']
    if file_hash(path) != row['image']['byte_sha256']:
        raise ValueError('Image hash mismatch: '+str(path))
    with Image.open(path) as im:
        return [view(im.convert('RGB'), edge=edge, label=row['condition'])]


def dataset_hash(data):
    files = [data/'catalog.jsonl', data/'families.jsonl']
    files += sorted((data/'images').rglob('*.png')) + sorted((data/'masks').rglob('*.png'))
    return fingerprint({str(p.relative_to(data)):file_hash(p) for p in files})


def code_hash():
    files = list((ROOT/'controlled').glob('*.py'))+list((ROOT/'backend_core').glob('*.py'))
    return fingerprint({str(p.relative_to(ROOT)):file_hash(p) for p in sorted(files)})


def model_spec(cfg, key):
    spec = dict(cfg['model_defaults'])
    spec.update(cfg['models'][key])
    return spec


def load_backend(args, cfg):
    try:
        locks = read_json(args.lock_file)
        if args.model not in locks:
            raise ValueError('Lock this model first with lock-models')
        return VisionBackend(model_spec(cfg,args.model), locks[args.model])
    except Exception as error:
        write_json(args.output_root/'validation'/args.model/'load_error.json',
                   dict(status='failed',stage='model_loading',model=args.model,error=repr(error)))
        raise


def run_context(args,cfg,backend):
    identity = dict(protocol=cfg, model_key=args.model, backend=backend.metadata(),
                    code_sha256=code_hash(), dataset_sha256=dataset_hash(args.data_root), system=SYSTEM,
                    validation_gate=('measurement_only_keep_format_failures' if getattr(args, 'allow_format_failures', False)
                                     else 'strict_measurement_and_format'))
    run = args.output_root/'runs'/args.model/fingerprint(identity)[:20]
    write_json(run/'run.json', identity)
    return run


def record_path(run,row):
    return run/'records'/(fingerprint(row['sample_id'])[:24]+'.json')


def save_arrays(path,arrays):
    path.parent.mkdir(parents=True,exist_ok=True)
    fd,tmp=tempfile.mkstemp(suffix='.npz',dir=path.parent)
    os.close(fd)
    try:
        np.savez_compressed(tmp,**arrays)
        os.replace(tmp,path)
    finally:
        if os.path.exists(tmp):
            os.unlink(tmp)


def store_inference(run,data,row,result,cfg):
    result = dict(result)
    arrays = {k:result.pop(k) for k in list(result) if isinstance(result[k],np.ndarray)}
    path=record_path(run,row)
    array_path=run/'attention'/(path.stem+'.npz')
    save_arrays(array_path,arrays)
    measurements={}
    for label,field in [('target','target_mask'),('reference','reference_mask'),('occluded_region','occlusion_mask')]:
        measurements[label]=attention(arrays['layer_weights'],result['token_boxes'],mask_at(data,row['annotations'][field]))
    record=dict(sample_id=row['sample_id'],source_group_id=row['source_group_id'],condition=row['condition'],
                task=row['task_type'],status='ok',scores=score(row,result['text'],cfg['localization_iou'],result.get('finish_reason')),
                attention=measurements,attention_file=str(array_path.relative_to(run)),inference=result,
                input_view=dict(source_size=[1024,1024],edge=cfg['input_edge'],source_image=row['image']['path']))
    write_json(path,record)
    return record


def call_args(data,row,cfg):
    return dict(views=observed(data,row,cfg['input_edge']),prompt=row['question'],question=row['question'],
                system=SYSTEM,seed=cfg['seed'],output_schema=prediction_schema())


def selected_groups(rows,limit=None):
    # Interleave tasks so a 3-group trial includes one family per task.
    tasks=sorted({r['task_type'] for r in rows})
    pools={t:sorted({r['source_group_id'] for r in rows if r['task_type']==t}) for t in tasks}
    groups=[pools[t][i] for i in range(max(map(len,pools.values()))) for t in tasks if i<len(pools[t])]
    return groups[:limit] if limit is not None else groups


def tensor_description(batch):
    import torch
    result={}
    for key,value in batch.items():
        tensor=value.detach().contiguous().cpu()
        raw=tensor.reshape(-1).view(torch.uint8).numpy().tobytes()
        result[key]=dict(shape=list(tensor.shape),dtype=str(tensor.dtype),sha256=hashlib.sha256(raw).hexdigest())
    return result


def verify_data(args):
    spec=importlib.util.spec_from_file_location('dataset_generator',args.data_root/'generate_dataset.py')
    module=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    _,report=module.audit(args.data_root)
    print(json.dumps(dict(status=report['status'],families=report['families'],images=report['images'],checks=report['checks']),indent=2))


def lock_models(args,cfg):
    from huggingface_hub import HfApi,snapshot_download
    locks=read_json(args.lock_file) if args.lock_file.exists() else {}
    for key in args.models:
        spec=model_spec(cfg,key)
        if key not in locks:
            info=HfApi().model_info(spec['repo_id'],revision=args.revision)
            locks[key]=dict(repo_id=spec['repo_id'],revision=info.sha)
        if locks[key]['repo_id']!=spec['repo_id']:
            raise ValueError('Lock/config repository mismatch')
        if args.download:
            locks[key]['local_path']=snapshot_download(spec['repo_id'],revision=locks[key]['revision'])
        write_json(args.lock_file,locks)
        print(key,locks[key]['revision'],flush=True)


def smoke(args,cfg,rows):
    backend=load_backend(args,cfg)
    run=run_context(args,cfg,backend)
    report=dict(status='running',model=args.model,checks=[],hidden_processor_checks=[],run_dir=str(run))
    report_path=run/'server_validation.json'
    write_json(report_path,report)
    try:
        by_id={r['sample_id']:r for r in rows}
        chosen=[]
        for task,size in [('attribute',24),('counting',48),('spatial',96)]:
            chosen.append(next(r for r in rows if r['task_type']==task and r['condition']=='I_plus' and
                              r['provenance']['parameters']['target_size_px']==size and
                              r['provenance']['parameters']['distractor_count']==24))
        for base in chosen:
            for condition in ['I_plus','I_hidden']:
                row=by_id[base['source_group_id']+'/'+condition]
                kwargs=call_args(args.data_root,row,cfg)
                captured=backend.infer(**kwargs,capture=True)
                plain=backend.infer(**kwargs,capture=False)
                logits_args={k:v for k,v in kwargs.items() if k not in {'seed','output_schema'}}
                hooked_logits=backend.prefill_logits(**logits_args,capture=True)
                plain_logits=backend.prefill_logits(**logits_args,capture=False)
                record=store_inference(run,args.data_root,row,captured,cfg)
                check=dict(sample_id=row['sample_id'],hook_same_tokens=captured['output_ids']==plain['output_ids'],
                           hook_logits_max_abs_diff=float(np.max(np.abs(hooked_logits-plain_logits))),
                           hook_logits_allclose=bool(np.allclose(hooked_logits,plain_logits,rtol=1e-5,atol=1e-5)),
                           format_valid=record['scores']['format_valid'],visual_tokens=captured['spatial_visual_tokens'],
                           global_layers=len(captured['layer_names']),query_mode=captured['query_mode'],
                           input_tensor_shapes=captured['preprocessing']['tensor_shapes'])
                if condition=='I_plus':
                    try:
                        backend.decoder.set_attn_implementation('sdpa')
                        sdpa=backend.prefill_logits(**logits_args,capture=False)
                    finally:
                        backend.decoder.set_attn_implementation('eager')
                    check['sdpa_logits_max_abs_diff']=float(np.max(np.abs(sdpa-plain_logits)))
                    check['sdpa_logits_mean_abs_diff']=float(np.mean(np.abs(sdpa-plain_logits)))
                report['checks'].append(check)
                write_json(report_path,report)
                print('smoke',row['sample_id'],check,flush=True)
            batches=[]
            for condition in ['I_plus','I_minus','I_hidden']:
                row=by_id[base['source_group_id']+'/'+condition]
                with Image.open(args.data_root/row['image']['path']) as im:
                    im=im.convert('RGB')
                if condition!='I_hidden':
                    im.paste((128,128,128),tuple(row['provenance']['interior_bbox_xyxy']))
                views=[view(im,edge=cfg['input_edge'],label='hidden')]
                batch,_,_,_=backend._inputs(views,row['question'],SYSTEM)
                batches.append(tensor_description(batch))
                del batch
            report['hidden_processor_checks'].append(dict(source_group_id=base['source_group_id'],
                exact_tensor_equality=batches[0]==batches[1]==batches[2],tensor_manifest=batches[0]))
        passed=all(c['hook_same_tokens'] and c['hook_logits_allclose'] and c['format_valid'] for c in report['checks'])
        passed=passed and all(c['exact_tensor_equality'] for c in report['hidden_processor_checks'])
        report['measurement_status'] = 'passed' if (
            len(report['checks']) == 6 and len(report['hidden_processor_checks']) == 3 and
            all(c['hook_same_tokens'] and c['hook_logits_allclose'] for c in report['checks']) and
            all(c['exact_tensor_equality'] for c in report['hidden_processor_checks'])) else 'failed'
        report['output_format_status'] = 'passed' if all(c['format_valid'] for c in report['checks']) else 'failed'
        report['format_failures'] = [c['sample_id'] for c in report['checks'] if not c['format_valid']]
        report['diagnostic_only'] = bool(not passed and getattr(args, 'allow_format_failures', False))
        report['status']='passed' if passed else 'failed'
        write_json(report_path,report)
        render_outputs(run,args.data_root,rows,limit=6)
        if not passed and not (getattr(args, 'allow_format_failures', False) and report['measurement_status'] == 'passed'):
            raise RuntimeError('Server smoke failed; inspect '+str(report_path))
        print('Smoke status:', report['status'], 'measurement:', report['measurement_status'],
              'format:', report['output_format_status'], 'diagnostic_only:', report['diagnostic_only'], 'run:', run)
    except Exception as error:
        report.update(status='failed',error=repr(error))
        write_json(report_path,report)
        raise


def run_model(args,cfg,rows):
    backend=load_backend(args,cfg)
    run=run_context(args,cfg,backend)
    check=run/'server_validation.json'
    validation = read_json(check) if check.exists() else {}
    diagnostic_ok = (getattr(args, 'allow_format_failures', False) and
                     validation.get('measurement_status') == 'passed')
    if validation.get('status') != 'passed' and not diagnostic_ok:
        raise RuntimeError('Run smoke with this model and configuration first: '+str(check))
    if validation.get('status') != 'passed':
        print('DIAGNOSTIC ONLY: strict output validation failed; retain and score every format failure.')
    groups=set(g for g in selected_groups(rows,args.limit_groups) if shard_contains(g,args.shard_index,args.shards))
    queue=[r for r in rows if r['source_group_id'] in groups]
    queue.sort(key=lambda r:fingerprint([cfg['seed'],r['sample_id']]))
    errors=0
    for i,row in enumerate(queue):
        path=record_path(run,row)
        if path.exists():
            previous=read_json(path)
            valid_cache=previous['status']=='ok' and (run/previous['attention_file']).exists()
            if valid_cache or (previous['status']=='error' and not args.retry_errors):
                errors+=int(previous['status']=='error')
                continue
        try:
            result=backend.infer(**call_args(args.data_root,row,cfg),capture=True)
            store_inference(run,args.data_root,row,result,cfg)
        except Exception as error:
            errors+=1
            write_json(path,dict(sample_id=row['sample_id'],source_group_id=row['source_group_id'],
                                 condition=row['condition'],task=row['task_type'],status='error',error=repr(error)))
            print('ERROR',row['sample_id'],repr(error),flush=True)
        print(f'{i+1}/{len(queue)} {row["sample_id"]}',flush=True)
    print('Run directory:',run)
    if args.shards==1:
        summarize(run,rows,cfg)
    if errors:
        raise RuntimeError(f'{errors} inference errors; inspect records and use --retry-errors after fixing')


def write_csv(path,rows):
    path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('w',newline='') as stream:
        if rows:
            writer=csv.DictWriter(stream,fieldnames=list(rows[0]))
            writer.writeheader()
            writer.writerows(rows)


def summarize(run,rows,cfg):
    records=[read_json(p) for p in sorted((run/'records').glob('*.json'))]
    report,observations,pairs=make_summary(rows,records,cfg['attention_enrichment_threshold'])
    write_json(run/'summary.json',report)
    write_csv(run/'tables/observations.csv',observations)
    write_csv(run/'tables/pairs.csv',pairs)
    write_csv(run/'tables/difficulty.csv',report['difficulty_cells'])
    write_csv(run/'tables/joint_attention_localization_answer.csv',report['joint'])
    print(json.dumps(dict(scope=report['scope'],completeness=report['completeness'],paired=report['paired']),indent=2))


def render_outputs(run,data,rows,limit):
    lookup={r['sample_id']:r for r in rows}
    paths=sorted((run/'records').glob('*.json'))
    done=0
    for path in paths:
        r=read_json(path)
        if r['status']!='ok':
            continue
        row=lookup[r['sample_id']]
        with Image.open(data/row['image']['path']) as im:
            original=im.convert('RGB')
        with np.load(run/r['attention_file'],allow_pickle=False) as arrays:
            weights=arrays['layer_weights'].mean(axis=0)
        if weights.sum()<=0:
            continue
        heat=project_mass(weights/weights.sum(),r['inference']['token_boxes'],(1024,1024))
        heat=heat/max(float(heat.max()),1e-20)
        pixels=np.asarray(original).astype(float)
        alpha=.65*heat[...,None]
        overlay=Image.fromarray(np.clip(pixels*(1-alpha)+np.array([255,30,0])*alpha,0,255).astype('uint8'))
        draw=ImageDraw.Draw(overlay)
        for box in r['scores']['predicted_boxes']:
            draw.rectangle(tuple(box),outline=(0,100,255),width=3)
        canvas=Image.new('RGB',(1040,566),'white')
        canvas.paste(original.resize((512,512)),(4,40))
        canvas.paste(overlay.resize((512,512)),(524,40))
        ImageDraw.Draw(canvas).text((8,8),row['sample_id']+' | answer='+r['scores']['normalized_answer'],fill='black')
        out=run/'previews'/f'{path.stem}.png'
        out.parent.mkdir(exist_ok=True)
        canvas.save(out)
        done+=1
        if done>=limit:
            break


def main():
    import socket
    if (not os.environ.get('SLURM_JOB_ID') or not os.environ.get('SLURMD_NODENAME') or
            socket.gethostname().split('.')[0] != os.environ['SLURMD_NODENAME'].split('.')[0]):
        raise RuntimeError('Submit computation to a Slurm compute node; login-node execution is forbidden')
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--data-root',type=Path,default=ROOT/'data')
    parser.add_argument('--output-root',type=Path,default=ROOT/'outputs')
    parser.add_argument('--config',type=Path,default=ROOT/'configs/protocol.json')
    parser.add_argument('--lock-file',type=Path,default=ROOT/'configs/models.lock.json')
    subs=parser.add_subparsers(dest='command',required=True)
    subs.add_parser('verify-data')
    subs.add_parser('plan')
    lock=subs.add_parser('lock-models')
    lock.add_argument('--models',nargs='+',required=True)
    lock.add_argument('--revision',default='main')
    lock.add_argument('--download',action='store_true')
    smoke_parser=subs.add_parser('smoke')
    smoke_parser.add_argument('--model',required=True)
    smoke_parser.add_argument('--allow-format-failures',action='store_true',
                             help='Diagnostic only: keep strict smoke failure but proceed if all measurement checks pass')
    run=subs.add_parser('run')
    run.add_argument('--model',required=True)
    run.add_argument('--allow-format-failures',action='store_true',
                     help='Diagnostic only: permit measurement-verified runs; retain invalid outputs as failures')
    run.add_argument('--limit-groups',type=int)
    run.add_argument('--shards',type=int,default=1)
    run.add_argument('--shard-index',type=int,default=0)
    run.add_argument('--retry-errors',action='store_true')
    summary=subs.add_parser('summarize')
    summary.add_argument('--run-dir',type=Path,required=True)
    rendering=subs.add_parser('render')
    rendering.add_argument('--run-dir',type=Path,required=True)
    rendering.add_argument('--limit',type=int,default=12)
    args=parser.parse_args()
    args.data_root=args.data_root.resolve()
    cfg=read_json(args.config)
    if args.command=='verify-data':
        return verify_data(args)
    if args.command=='lock-models':
        return lock_models(args,cfg)
    rows=rows_at(args.data_root)
    if args.command=='plan':
        print(json.dumps(dict(families=200,images=800,split='test',input_edge=cfg['input_edge'],
              models=cfg['primary_models'],basic_inferences=800*len(cfg['primary_models']),
              task_groups={'attribute':68,'counting':66,'spatial':66}),indent=2))
    elif args.command=='smoke':
        smoke(args,cfg,rows)
    elif args.command=='run':
        if not 0<=args.shard_index<args.shards or (args.limit_groups is not None and args.limit_groups<1):
            raise ValueError('Invalid shard or group limit')
        run_model(args,cfg,rows)
    else:
        saved=read_json(args.run_dir/'run.json')
        if saved['dataset_sha256']!=dataset_hash(args.data_root):
            raise ValueError('Run dataset differs from this dataset')
        if args.command=='summarize':
            summarize(args.run_dir,rows,saved['protocol'])
        else:
            render_outputs(args.run_dir,args.data_root,rows,args.limit)


if __name__=='__main__':
    main()
