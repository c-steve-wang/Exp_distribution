#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
source scripts/require_compute_node.sh
python -m pip install -r requirements-cpu.txt
python scripts/verify_delivery.py
python -m unittest discover -s tests -v
python -m controlled verify-data
python -m controlled plan
