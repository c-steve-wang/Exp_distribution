"""Verify immutable delivered files; extra model locks and outputs are allowed."""
import hashlib
import json
from pathlib import Path

root=Path(__file__).resolve().parents[1]
manifest=json.loads((root/'MANIFEST.sha256.json').read_text())
failures=[]
for relative,expected in manifest['files'].items():
    path=root/relative
    if not path.is_file() or hashlib.sha256(path.read_bytes()).hexdigest()!=expected:
        failures.append(relative)
if failures:
    raise SystemExit('Delivery files changed or missing: '+', '.join(failures))
print(f"Delivery integrity verified: {len(manifest['files'])} files")
